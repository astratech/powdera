    <script type="text/javascript">
        //Ajax
        $(document).ready(function () {
        	
        });//end ready
    </script>
    




    <div class="container ld" >

    	<div class="row" style="margin-bottom: 200px; padding-top: 200px;">

    		<div class="col-md-12">
    			<div class="pat2" style="background-color: #239b59;">
    				<header>
    					<p>Payment History</p>
    				</header>
    				<article class="p2body">
    					<table class="table table-bordered table-condensed">

                                <thead>

                                    <tr>

                                        <th>S/N</th>

                                        <th>Payment Type</th>

                                        <th>Amount</th>

                                        <th>Date</th>

                                        

                                    </tr>

                                </thead>

                                <tbody>

                                <?php

                                    $sn = 1;

                                    $ph = $this->db->query("SELECT * FROM ph WHERE username='$this->username' ORDER BY id DESC");

                                    foreach ($ph->result() as $r) {

                                        $merge = $this->db->query("SELECT * FROM merge WHERE ph_id='$r->id' AND is_confirmed='1' ORDER BY id DESC");

                                        foreach ($merge->result() as $m){

                                            echo "<tr>";

                                            echo "<td>$sn</td>";

                                            echo "<td>Fund Donation</td>";

                                            echo "<td>₦".$m->amount."</td>";                                            

                                            echo "<td>".date('D-M-Y', strtotime($m->date_paid))."</td>";                                             

                                            echo "</tr>";

                                            $sn++;

                                        }

                                    }



                                    $gh = $this->db->query("SELECT * FROM gh WHERE username='$this->username' ORDER BY id DESC");

                                    foreach ($gh->result() as $r) {

                                        $merge = $this->db->query("SELECT * FROM merge WHERE gh_id='$r->id' AND is_confirmed='1' ORDER BY id DESC");

                                        foreach ($merge->result() as $m){

                                            echo "<tr>";

                                            echo "<td>$sn</td>";

                                            echo "<td>Fund Request</td>";

                                            echo "<td>₦".$m->amount."</td>";                                            

                                            echo "<td>".date('D-M-Y', strtotime($m->date_paid))."</td>";                                            

                                            echo "</tr>";

                                            $sn++;

                                        }

                                    }

                                ?>

                                </tbody>

                            </table>
    				</article>
    			</div>
    		</div>

    		
    	</div>


    </div>

