    <script type="text/javascript">
        //Ajax
        $(document).ready(function () {
        	$(".upload-pop").click(function(e){
        		e.preventDefault();
        		$("#merge-id").val($(this).attr('m'));
        		$("#trans-num").val($(this).attr('id'));
        		$("#pop").modal({});
        	});

        	$(".cancel-payment").click(function(e){
        		e.preventDefault();

        		$(".ld").show();

        		var ph_id = $(this).attr('id');

        		var c_url = "<?php echo $this->config->base_url().'ph' ?>";

        		var con = confirm("Are you sure?");

        		if(con){

        			$.ajax({

        				url: c_url,

        				type: 'post',

        				data: {'action': 'cancel_payment', 'ph_id': ph_id},

        				success: function (data, status) {

        					var result = String(data);

        					result = result.trim();
        					$(".ld").hide();

        					if (result == "1") {
        						alert("Successful");
        						window.location.href = "<?php echo $this->config->base_url().'ph' ?>";

        					}
        					else {

        						alert('failed');

        					}

        				},

        				error: function (xhr, desc, err) {

        					alert(err);
        					$(".ld").hide();


        				}

                    });//end ajax call

        		}
        		else{
        			$(".ld").hide();
        		}
        	});

        	$(".confirm").click(function(e){
        		e.preventDefault();

        		$(".ld").show();

        		var m_id = $(this).attr('id');
        		var t_id = $(this).attr('t');

        		var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";

        		var con = confirm("Are you sure you want to confirm this payment? \n");

        		if(con){

        			$.ajax({

        				url: c_url,

        				type: 'post',

        				data: {'action': 'confirm_payment', 'merge_id': m_id, 'time_left': t_id},

        				success: function (data, status) {

        					var result = String(data);

        					result = result.trim();
        					$(".ld").hide();

        					if (result == "1") {

        						window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

        					}

        					else {

        						alert('failed');

        					}

        				},

        				error: function (xhr, desc, err) {

        					alert(err);
        					$(".ld").hide();


        				}

                    });//end ajax call

        		}
        		else{
        			$(".ld").hide();
        		}
        	});

        	$(".report").click(function(e){
        		e.preventDefault();

        		$("#r-m").val($(this).attr('m'));
        		$("#report-modal").modal({});
                // alert($("#r-merge-id").val());
            });

        	$(".i-cant").click(function(e){
        		e.preventDefault();

        		$(".ld").show();

        		var m_id = $(this).attr('id');

        		var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";

        		var con = confirm("Are you sure you want to cancel this payment? \nYour Account will be blocked.");

        		if(con){

        			$.ajax({

        				url: c_url,

        				type: 'post',

        				data: {'action': 'cancel_payment', 'merge_id': m_id},

        				success: function (data, status) {

        					var result = String(data);

        					result = result.trim();
        					$(".ld").hide();

        					if (result == "1") {

        						window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

        					}
        					else if (result == "paid") {
        						alert("Cant cancel payment, you have paid some of the money. Please complete your transaction");
        						window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

        					}
        					else if (result == "paid") {
        						alert("Cant Purge user has already paid");
        						window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

        					}

        					else {

        						alert('failed');

        					}

        				},

        				error: function (xhr, desc, err) {

        					alert(err);
        					$(".ld").hide();


        				}

                    });//end ajax call

        		}
        		else{
        			$(".ld").hide();
        		}
        	});

        	$(".co-bonus").click(function(e){
        		e.preventDefault();
        		$(".page-wrapper").hide();
        		var m_id = $(this).attr('id');
        		var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";
        		var con = confirm("Are you sure you want to cash out your bonus? \n");
        		if(con){
        			$(".co-bonus").unbind('click').click();
        		}
        		else{
        			$(".page-wrapper").show();
        		}
        	});

            $(".make-gh").click(function(e){
                e.preventDefault();

                $(".ld").hide();

                var m_id = $(this).attr('id');

                var c_url = "<?php echo $this->config->base_url().'ph' ?>";

                var con = confirm("Are you sure you wanna GH this transaction?\nNOTE: 30% of your GH will be locked, until you recommit mininum of 20% of this PH.");

                if(con){

                    $.ajax({

                        url: c_url,

                        type: 'post',

                        data: {'action': 'make_gh', 'ph_id': m_id},

                        success: function (data, status) {

                            var result = String(data);

                            result = result.trim();
                            $(".ld").show();

                            if (result == "1") {
                                alert("Successful");
                                window.location.href = "<?php echo $this->config->base_url().'gh' ?>";

                            }

                            else {

                                alert('failed');

                            }

                        },

                        error: function (xhr, desc, err) {

                            alert(err);
                            $(".ld").show();;


                        }

                    });//end ajax call

                }
                else{
                    $(".ld").show();
                }
            });


            $(".cash-out").click(function(e){
                var ph_id = $(this).attr('id');
                $("#modal-ph_id").val(ph_id);
                $("#modal-ph").modal({});
            });
        });//end ready
    </script>
    



    <div class="main">
        <div class="content" >
            <?php 
                    if(isset($_SESSION['notification'])){
                        echo $_SESSION['notification'];
                    }
                ?>
        	<div class="content-header no-mg-top">
                

                <i class="fa fa-money"></i>
                <div class="content-header-title">Donations</div>
    		</div>
            <div class="row">
                <div class="col-md-12">
                    <div class="content-box">
                        <p>
                            <button class="btn btn-primary btn-lg" href="#donate" data-toggle="modal">Click Here to Donate</button>  
                        </p>
                        <br>
                        <br>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>SN</th>
                                        <th>Ref ID</th>
                                        <th>Amount</th>
                                        <th>Date Pledged</th>
                                        <th>Status</th>
                                        <th>Release Date</th>
                                        <th>Growth</th>
                                        <th>Request Donations</th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php

                                        $sn = 1;

                                        $ph = $this->db->query("SELECT * FROM ph WHERE username='$this->username' ORDER BY id DESC");

                                        foreach ($ph->result() as $r) {

                                            $days = $this->admin_model->get_date_diff($r->release_date, date('Y-m-d H:i:s'))->days;
                                           

                                            echo "<tr>";

                                            echo "<td>$sn</td>";
                                            echo "<td>$r->trans_num</td>";

                                            echo "<td>₦$r->amount</td>";

                                            echo "<td>$r->date_created</td>";

                                            if($r->is_confirmed == 1){
                                                echo "<td>SUCCESSFUL</td>";
                                            }
                                            elseif ($r->is_merge == 1) {
                                                echo "<td>MERGED</td>";
                                            }
                                            else{
                                                echo "<td>PENDING</td>";
                                            }

                                            echo "<td>$r->release_date</td>";

                                            echo "<td>";
                                            if($days < 0 OR $days > 8){
                                                $day = 8;
                                                $gp = $day * 12.5;
                                                $gmoney = (($gp/100) * $r->amount) + $r->amount;
                                                echo "Day $day<br>$gp%<br>₦ $gmoney";
                                            }
                                            elseif($days == 0){
                                                $day = $days + 1;
                                                $gp = $day * 12.5;
                                                $gmoney = (($gp/100) * $r->amount) + $r->amount;
                                                echo "Day $day<br>$gp%<br>₦ $gmoney";
                                            }
                                            else{
                                                $day = 8 - $days;
                                                $gp = $day * 12.5;
                                                $gmoney = (($gp/100) * $r->amount) + $r->amount;
                                                echo "Day $day<br>$gp%<br>₦ $gmoney";
                                            }
                                            
                                            echo "</td>";

                                            echo "<td>";

                                            if($r->is_gh == 1){
                                                echo "DONE";
                                            }
                                            elseif($r->is_confirmed == 1){
                                                echo "<button class='btn btn-sm btn-success cash-out' id='$r->id'><i class='fa fa-cc'></i>  Request Donation</button>";
                                            }
                                            else{
                                                echo "<button class='btn btn-default'>Donation Not Confirmed Yet</button>";
                                            }
                                            echo "</td>";
                                            if($r->is_merge == 0 OR $r->is_confirmed == 0){
                                                $ph_id = $r->id;
                                                echo "<td><button class='btn btn-danger cancel-payment' id='$ph_id' >Delete Donation</button></td>";
                                            }
                                            
                                            

                                            echo "</tr>";

                                            $sn++;   
                                        }

                                    ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- PH Modal -->
    <div id="modal-ph" class="modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg" style="margin-top: 100px;">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h3 class="modal-title"><strong>Recommitment Form</strong></h3>
                </div>
                <form action="" method="post" class="form-horizontal">
                <div class="modal-body">
                        <p>You must recommit same amount of your present Donation or Higher before your locked request is released and you will be merged to pay 50% in 0 - 24 Hours.</p>
                        <br>
                        <div class="form-group">
                            <div class="col-xs-12">
                                <label>Amount</label>
                                <select class="form-control" name="ph_amount">
                                    <option value="10000">₦10,000</option>
                                    <option value="20000">₦20,000</option>
                                    <option value="50000">₦50,000</option>
                                    <option value="100000">₦100,000</option>
                                </select>
                                <input type="hidden" name="recycle" value="0">
                                <input type="hidden" name="ph_id" class="form-control" value="" id="modal-ph_id">
                            </div>
                        </div>

                </div>
                <div class="modal-footer">
                    <input type="submit" class="btn btn-effect-ripple btn-primary" name="recommit" value="Recommit"/>
                    <button class="btn btn-effect-ripple btn-danger" data-dismiss="modal">Close</button>
                </div>
                </form>   
            </div>
        </div>
    </div>
    <!-- END PH Modal -->

    <!-- PH Modal -->
    <div id="donate" class="modal" tabindex="1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg" style="margin-top: 100px;">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h3 class="modal-title"><strong>Donation Form</strong></h3>
                </div>
                <form action="" method="post" class="form-horizontal">
                <div class="modal-body" style="font-size: 19px;">
                        <div class="form-group">
                            <div class="col-xs-12">
                                <p>Select a Package</p>
                            </div>
                            <div class="col-xs-12">
                               <select class="form-control" name="amount">
                                    <option value="10000">₦10,000</option>
                                    <option value="20000">₦20,000</option>
                                    <option value="50000">₦50,000</option>
                                    <option value="100000">₦100,000</option>
                                </select>
                                <input type="hidden" name="recycle" value="0">
                            </div>
                        </div>

                </div>
                <div class="modal-footer">
                    <input type="submit" class="btn btn-success" name="donate" value="Donate Fund"/>
                    <button class="btn btn-danger" data-dismiss="modal">Cancel</button>
                </div>
                </form>   
            </div>
        </div>
    </div>
    <!-- END PH Modal -->

