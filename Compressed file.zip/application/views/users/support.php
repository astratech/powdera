



    <!-- Main Content -->
        <div id="content" class="ui-content ui-content-aside-overlay">
                <div class="ui-content-body">
            <?php 
                    if(isset($_SESSION['notification'])){
                        echo $_SESSION['notification'];
                    }
                ?>

            <div class="row">
                <div class="col-md-12">
                    <div class="content-box">
                        <div>
                            <h3>Customer Care Line : Senator :: 09074648372 or Jones:: 07084331170</h3>
                            <h3>Support Email: </h3>
                            <p>You can always Chat us up via our live chat at the bottom of the page</p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

