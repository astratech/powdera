



    <div class="main">
        <div class="content" >
            <?php 
                    if(isset($_SESSION['notification'])){
                        echo $_SESSION['notification'];
                    }
                ?>
            <div class="content-header no-mg-top">
                

                <i class="fa fa-money"></i>
                <div class="content-header-title">Requests</div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="content-box">

                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>SN</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Accesibility</th>

                                    </tr>
                                </thead>
                                <tbody>

                                    <?php

                                        $sn = 1;

                                        $ph = $this->db->query("SELECT * FROM gh WHERE username='$this->username' ORDER BY id DESC");

                                        foreach ($ph->result() as $r) {
                                           

                                            echo "<tr>";

                                            echo "<td>$sn</td>";

                                            echo "<td>₦$r->amount</td>";

                                            if($r->is_confirmed == 1){
                                                echo "<td>SUCCESSFUL</td>";
                                            }
                                            elseif ($r->is_merge == 1) {
                                                echo "<td>MERGED</td>";
                                            }
                                            else{
                                                echo "<td>PENDING</td>";
                                            }

                                            if($r->locked == 1){
                                                echo "<td style='color: #ab0918;'><i class='fa fa-lock'></i> LOCKED</td>";
                                            }
                                            else{
                                                echo "<td>OPEN</td>";
                                            }
                                            

                                            echo "</tr>";

                                            $sn++;   
                                        }

                                    ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- PH Modal -->
    <div id="modal-ph" class="modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h3 class="modal-title"><strong>Provide Help</strong></h3>
                </div>
                <form action="" method="post" class="form-horizontal">
                <div class="modal-body">
                        <p>You must recommit before your GH is Released.</p>
                        <div class="form-group">
                            <div class="col-xs-12">
                                <p>Note: Amount Must be between ₦10,000 to ₦50,000</p>
                            </div>
                            <div class="col-xs-12">
                                <label>Amount</label>
                                <input type="number" name="ph_amount" class="form-control">
                                <input type="hidden" name="ph_id" class="form-control" value="" id="modal-ph_id">
                            </div>
                        </div>

                </div>
                <div class="modal-footer">
                    <input type="submit" class="btn btn-effect-ripple btn-primary" name="recommit" value="Recommit"/>
                    <button class="btn btn-effect-ripple btn-danger" data-dismiss="modal">Close</button>
                </div>
                </form>   
            </div>
        </div>
    </div>
    <!-- END PH Modal -->

    <!-- PH Modal -->
    <div id="donate" class="modal" tabindex="1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg" style="margin-top: 100px;">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h3 class="modal-title"><strong>Donation Form</strong></h3>
                </div>
                <form action="" method="post" class="form-horizontal">
                <div class="modal-body" style="font-size: 19px;">
                        <div class="form-group">
                            <div class="col-xs-12">
                                <p>Select a Package</p>
                            </div>
                            <div class="col-xs-12">
                               <select class="form-control" name="amount">
                                    <option value="10000">₦10,000</option>
                                    <option value="20000">₦20,000</option>
                                    <option value="50000">₦50,000</option>
                                    <option value="100000">₦100,000</option>
                                </select>
                                <input type="hidden" name="recycle" value="0">
                            </div>
                        </div>

                </div>
                <div class="modal-footer">
                    <input type="submit" class="btn btn-success" name="donate" value="Donate Fund"/>
                    <button class="btn btn-danger" data-dismiss="modal">Cancel</button>
                </div>
                </form>   
            </div>
        </div>
    </div>
    <!-- END PH Modal -->

