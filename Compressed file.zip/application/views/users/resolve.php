            <script type="text/javascript">

                //Ajax

                $(document).ready(function () {

                });//end ready

            </script>

            <div class="page-content" style="padding-top:80px;">
                <div class="block" id="features">
                    <div class="container">
                    <?php 
                        if(isset($_SESSION['notification'])){
                            echo $_SESSION['notification'];
                        }
                    ?>
                        <!-- Action Box -->
                        <div class="row">

                            <!-- Notice Board -->
                            <div class="col-md-12">
                                <div class="panel spanel panel-danger">
                                    <div class="panel-heading">
                                        <h3 class="panel-title text-white">
                                            <i class="fa fa-file-text"></i> Report by <?php echo $this->admin_model->get_report($merge_id)->username; ?>
                                        </h3>
                                    </div>
                                    <div class="panel-body">
                                        <h3><?php echo $this->admin_model->get_report($merge_id)->reason; ?></h3>
                                    </div>
                                </div>
                            </div>
                            <!-- END Notice Board -->
                        </div>
                        <!-- END Action Box -->

                        <div class="row">
                            <?php
                                $sn = 1;
                                $rp = $this->db->query("SELECT * FROM resolve WHERE report_id='$report_id' ORDER BY id ASC");
                                if($rp->num_rows() > 0){
                                    foreach ($rp->result() as $r) {
                                        echo "<div class='col-md-12'>
                                            <div class='panel spanel panel-collapse'>
                                                <div class='panel-heading'>
                                                    <h3 class='panel-title text-white'>
                                                        Message By : $r->username
                                                    </h3>
                                                </div>
                                                <div class='panel-body table-responsive'>
                                                    $r->message
                                                </div>
                                                </div>
                                            </div>";
                                    }
                                }
                                else{
                                    echo "<p>No Messages Yet</p>";
                                }
                            ?>
                            <div class='col-md-12' id='down'>
                                <div class='panel spanel panel-collapse'>
                                    <div class='panel-heading'>
                                        <h3 class='panel-title text-white'>
                                           Send a reply
                                        </h3>
                                    </div>
                                    <div class='panel-body table-responsive'>
                                        <form class="" method="POST" action="">
                                            <div class="form-group">
                                                <textarea class="form-control" name="text"></textarea>
                                                <input type="submit" class="btn btn-primary" value="Send" name="reply">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <!--/ .row-->
                    </div>
                    <!--/ .container-->
                    <div class="bg bg-color-neutral opacity-50"></div><!--/ .bg-->
                </div>
                <!--/ .block-->


                <div class="space"></div>

                <div class="container">
                    
                </div>
                <!--/ .container-->

            </div>


        </div>
    </div>