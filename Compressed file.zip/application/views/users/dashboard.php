
    <script type="text/javascript">
                //Ajax
                $(document).ready(function () {
                    $(".upload-pop").click(function(e){
                        e.preventDefault();
                        $("#merge-id").val($(this).attr('m'));
                        $("#trans-num").val($(this).attr('id'));
                        $("#pop").modal({});
                    });

                    $(".shw-r-details").click(function(e){
                        e.preventDefault();
                        var m_id = $(this).attr('mid');
                        // var ph_id = $(this).attr('phid');
                        // var gh_id = $(this).attr('ghid');

                        var c_url = "<?php echo $this->config->base_url().'getter/get_merge_receiver' ?>";

                        $.ajax({

                            url: c_url,

                            type: 'get',

                            data: {'merge_id': m_id},
                            success: function (data, status) {

                                // var result = String(data);
                                $("#modal-merge .modal-body").html(data);
                                // alert(data);

                                
                            },
                            error: function (xhr, desc, err) {
                                // alert(err+" "+desc);
                            }

                        });//end ajax call

                        $("#modal-merge").modal({});
                        // alert(m_id);
                    });

                    $(".shw-s-details").click(function(e){
                        e.preventDefault();
                        var m_id = $(this).attr('mid');
                        // var ph_id = $(this).attr('phid');
                        // var gh_id = $(this).attr('ghid');

                        var c_url = "<?php echo $this->config->base_url().'getter/get_merge_sender' ?>";

                        $.ajax({

                            url: c_url,

                            type: 'get',

                            data: {'merge_id': m_id},
                            success: function (data, status) {

                                // var result = String(data);
                                $("#modal-merge .modal-body").html(data);
                                // alert(data);

                                
                            },
                            error: function (xhr, desc, err) {
                                // alert(err+" "+desc);
                            }

                        });//end ajax call

                        $("#modal-merge").modal({});
                        // alert(m_id);
                    });

                    $(".purge").click(function(e){
                        e.preventDefault();

                        $(".ld").show();

                        var m_id = $(this).attr('id');

                        var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";

                        var con = confirm("Are you sure?");

                        if(con){

                            $.ajax({

                                url: c_url,

                                type: 'post',

                                data: {'action': 'purge', 'merge_id': m_id},

                                success: function (data, status) {

                                    var result = String(data);

                                    result = result.trim();
                                    $(".ld").hide();

                                    if (result == "1") {
                                        alert("Successful");
                                        window.location.href = "<?php echo $this->config->base_url().'transactions' ?>";

                                    }
                                    else if (result == "paid") {
                                        alert("Cant Purge user has already paid");
                                        window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

                                    }

                                    else {

                                        alert('failed');

                                    }

                                },

                                error: function (xhr, desc, err) {

                                    alert(err);
                                    $(".ld").hide();


                                }

                            });//end ajax call

                        }
                        else{
                            $(".ld").hide();
                        }
                    });

                    $(".confirm").click(function(e){
                        e.preventDefault();

                        $(".ld").show();

                        var m_id = $(this).attr('id');
                        var t_id = $(this).attr('t');

                        var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";

                        var con = confirm("Are you sure you want to confirm this payment? \n");

                        if(con){

                            $.ajax({

                                url: c_url,

                                type: 'post',

                                data: {'action': 'confirm_payment', 'merge_id': m_id, 'time_left': t_id},

                                success: function (data, status) {

                                    var result = String(data);

                                    result = result.trim();
                                    $(".ld").hide();

                                    if (result == "1") {

                                        window.location.href = "<?php echo $this->config->base_url().'transactions' ?>";

                                    }

                                    else {

                                        alert('failed');

                                    }

                                },

                                error: function (xhr, desc, err) {

                                    alert(err);
                                    $(".ld").hide();


                                }

                            });//end ajax call

                        }
                        else{
                            $(".ld").hide();
                        }
                    });

                    $(".confirm-act").click(function(e){
                        e.preventDefault();

                        $(".ld").show();

                        var username = $(this).attr('id');
                        var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";

                        var con = confirm("Are you sure you want to confirm this activation fee payment? \n");

                        if(con){

                            $.ajax({

                                url: c_url,

                                type: 'post',

                                data: {'action': 'confirm_activation', 'username': username},

                                success: function (data, status) {

                                    var result = String(data);

                                    result = result.trim();
                                    $(".ld").hide();

                                    if (result == "1") {

                                        window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

                                    }

                                    else {

                                        alert('failed');

                                    }

                                },

                                error: function (xhr, desc, err) {

                                    alert(err);
                                    $(".ld").hide();


                                }

                            });//end ajax call

                        }
                        else{
                            $(".ld").hide();
                        }
                    });

                    $(".report").click(function(e){
                        e.preventDefault();
                        
                        $("#r-m").val($(this).attr('m'));
                        $("#report-modal").modal({});
                        // alert($("#r-merge-id").val());
                    });

                    $(".i-cant").click(function(e){
                        e.preventDefault();

                        $(".ld").show();

                        var m_id = $(this).attr('id');

                        var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";

                        var con = confirm("Are you sure you want to cancel this payment? \nYour Account will be blocked.");

                        if(con){

                            $.ajax({

                                url: c_url,

                                type: 'post',

                                data: {'action': 'cancel_payment', 'merge_id': m_id},

                                success: function (data, status) {

                                    var result = String(data);

                                    result = result.trim();
                                    $(".ld").hide();

                                    if (result == "1") {

                                        window.location.href = "<?php echo $this->config->base_url().'transactions' ?>";

                                    }
                                    else if (result == "paid") {
                                        alert("Cant cancel payment, you have paid some of the money. Please complete your transaction");
                                        window.location.href = "<?php echo $this->config->base_url().'transactions' ?>";

                                    }
                                    else if (result == "paid") {
                                        alert("Cant Purge user has already paid");
                                        window.location.href = "<?php echo $this->config->base_url().'transactions' ?>";

                                    }

                                    else {

                                        alert('failed');

                                    }

                                },

                                error: function (xhr, desc, err) {

                                    alert(err);
                                    $(".ld").hide();


                                }

                            });//end ajax call

                        }
                        else{
                            $(".ld").hide();
                        }
                    });

                    $(".co-bonus").click(function(e){
                        e.preventDefault();
                        $(".page-wrapper").hide();
                        var m_id = $(this).attr('id');
                        var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";
                        var con = confirm("Are you sure you want to cash out your bonus? \n");
                        if(con){
                            $(".co-bonus").unbind('click').click();
                        }
                        else{
                            $(".page-wrapper").show();
                        }
                    });
                });//end ready
    </script>

    <section class="features text-center" id="about">
	    <div class="container" style="min-height: 1000px; padding-top: 90px; margin-top: 30px;">

	            <div class="row">
	                 
	                <!-- <div class='alert alert-callout alert-warning' role='alert'>
	                    <strong><i class="fa fa-warning"></i> WARNING : </strong>You have 12 Hours Left to make your first PH, else your account will be blocked.
	                </div> -->
	            </div>

	            
	            <div class="row">
	            	<?php 
		                if(isset($_SESSION['notification'])){
		                    echo $_SESSION['notification'];
		                }
	                ?>

	                <div class="col-md-12">
	                	<div class="board">
		                    <div class="header">
		                      <p>Notice Board</p>
		                    </div> 
		                    <article>
		                   		<p>Welcome, <?php echo $this->username; ?></p>
		                        <p><?php $this->admin_model->get_news()->content; ?></p>
		                    </article>
		                </div>
	                </div>

	                <div class="col-md-6">
	                	<a href="#donation" data-toggle="modal" style="color:#fff; font-size: 17px;">
		                	<div class="plate text-center">
			                   <p style="line-height: 5;">Provide Help</p>
			                </div>
			            </a>
	                </div>

	                <div class="col-md-6">
	                	<a href="<?php echo $this->config->base_url(); ?>transactions" style="color:#fff; font-size: 17px;">
		                	<div class="plate text-center">
			                   <p style="line-height: 5;">Get Help</p>
			                </div>
			            </a>
	                </div>

	                <div class="col-md-12">
	                	<div class="plate text-center" style="background-color: #428d56; border-color: #428d56; border-radius: 30px;">
		                   <p style="line-height: 5; color: #fff; font-size: 25px;"><i></i> Don't Pledge if you dont have money to pay. Verve Funds is here to stay.</p>
		                   <p style="line-height: 2; color: #fff; font-size: 25px;"><i></i> Your Ref Link: <?php echo $this->config->base_url()."register/?ref=".$this->username; ?></p>
		                </div>
	                </div>

	            </div>

	            <div class="row" style="margin-top: 30px;">

	           		<div class="col-md-12">
	           			<div class="board">
	           				<div class="header">
	           					<p>PH Merge List</p>
	           				</div>
	           				<article>
	           					<table class="table table-striped">
			           				<thead>
			           					<th>Name</th>
			           					<th>Amount</th>
			           					<th>Proof</th>
			           					<th>Actions</th>
			           				</thead>
			           				<tbody style="text-align: left;">
			           					<?php
						                    $sn = 1;
						                    $ph = $this->db->query("SELECT * FROM ph WHERE username='$this->username' AND is_merge='1' AND is_confirmed='0'");
						                    foreach ($ph->result() as $r) {
						                        $merge = $this->db->query("SELECT * FROM merge WHERE ph_id='$r->id' AND is_confirmed='0' AND is_blocked='0' ORDER BY id DESC");
						                        foreach ($merge->result() as $m){
						                        	$days = $m->days." hours";
					                                $time_out_date = date('Y-m-d H:i:s', strtotime($m->date_created. " + $days"));
					                                $time_out = $this->admin_model->get_date_diff($time_out_date, date("Y-m-d H:i:s"));
					                                $ph_id = $this->admin_model->get_merge($m->id)->ph_id;
					                                $gh_id = $this->admin_model->get_merge($m->id)->gh_id;

						 							echo "<tr>";
						 							echo "<td>
						           							<p>".$this->admin_model->get_user($this->admin_model->get_gh($gh_id)->username)->account_name."</p>
						           							<p><button class='btn btn-primary btn-xs shw-r-details' mid='$m->id'>View Full details</button></p>
						           							<p style='font-size: 14px; color: red;'>$time_out->hours Hrs $time_out->mins Mins Left</p>
						           						</td>";
						           					echo "<td>₦ $m->amount</td>";

						           					echo "<td>";
					                                if($m->receipt == ""){
					                                    echo "<p>No Proof Yet</p>";
					                                }
					                                else{
					                                    echo "<p><a href='".$this->config->item('assets_url')."/pop/$m->receipt' target='_blank'><img src='".$this->config->item('assets_url')."/pop/$m->receipt' class='img-thumbnail' style='height:60px; width:90px;'></a></p><br/>";
					                                    
					                                }
						           					echo "</td>";

						           					echo "<td>";
						           					echo "<p><button class='btn btn-default flat-btn upload-pop' id='$r->trans_num' m='$m->id'>Upload POP</button></br></br>";
						           					echo "<button class='btn btn-info flat-btn i-cant' id='$m->id'>I cant Pay</button></p>";
						           					echo "</td>";
						 							echo "</tr>";

						                        }
						                    }
						                ?>
						             </tbody>
						         </table>
	           				</article>
	           			</div>
	           		</div>


	           		<div class="col-md-12">
	           			<div class="board">
	           				<div class="header">
	           					<p>GH Merge List</p>
	           				</div>
	           				<article>
	           					<table class="table table-striped">
			           				<thead>
			           					<th>Name</th>
			           					<th>Amount</th>
			           					<th>Proof</th>
			           					<th>Actions</th>
			           				</thead>
			           				<tbody style="text-align: left;">
			           					<?php
						                    $sn = 1;
						                    $gh = $this->db->query("SELECT * FROM gh WHERE username='$this->username' AND is_merge='1' AND is_confirmed='0'");
						                    foreach ($gh->result() as $r) {
						                        $merge = $this->db->query("SELECT * FROM merge WHERE gh_id='$r->id' AND is_confirmed='0' AND is_blocked='0' ORDER BY id DESC");
						                        foreach ($merge->result() as $m){
						                        	$days = $m->days." hours";
					                                $time_out_date = date('Y-m-d H:i:s', strtotime($m->date_created. " + $days"));
					                                $time_out = $this->admin_model->get_date_diff($time_out_date, date("Y-m-d H:i:s"));
					                                $ph_id = $this->admin_model->get_merge($m->id)->ph_id;
					                                $gh_id = $this->admin_model->get_merge($m->id)->gh_id;

						 							echo "<tr>";
						 							echo "<td>
						           							<p>".$this->admin_model->get_user($this->admin_model->get_ph($ph_id)->username)->account_name."</p>
						           							<p><button class='btn btn-primary btn-xs shw-s-details' mid='$m->id'>View Full details</button></p>
						           							<p style='font-size: 14px; color: red;'>$time_out->hours Hrs $time_out->mins Mins Left</p>
						           						</td>";
						           					echo "<td>₦ $m->amount</td>";

						           					echo "<td>";
					                                if($m->receipt == ""){
					                                    echo "<p>No Proof Yet</p>";
					                                }
					                                else{
					                                    echo "<p><a href='".$this->config->item('assets_url')."/pop/$m->receipt' target='_blank'><img src='".$this->config->item('assets_url')."/pop/$m->receipt' class='img-thumbnail' style='height:60px; width:90px;'></a></p><br/>";
					                                    
					                                }
						           					echo "</td>";

						           					echo "<td>";
						           					echo "<p><button class='btn btn-success confirm' id='$m->id' t='$time_out->hours'>Confirm Payment</button><br/><br/>";
					                                $m_date_created = new DateTime($m->date_created);

					                                $m_time_out_date = new DateTime(date('Y-m-d H:i:s'));

					                                $p_time_out  =  $m_time_out_date->diff($m_date_created);

					                                // if($time_out->hours <= 1){
					                                    // echo "<form action='' method='POST' id='form-purge'><input type='hidden' name='merge_id' value='$m->id' /></form>";
					                                    echo "<button class='btn btn-danger flat-btn purge' id='$m->id'>Remove User</button></td>";
					                                // }
						           					echo "</td>";
						 							echo "</tr>";

						                        }
						                    }
						                ?>
						             </tbody>
						         </table>
	           				</article>
	           			</div>
	           		</div>


					<!-- gh -->
	                <?php
	                    $sn = 1;
	                    $gh = $this->db->query("SELECT * FROM gh WHERE username='$this->username' AND is_merge='1' AND is_confirmed='0'");
	                    foreach ($gh->result() as $r) {
	                        $merge = $this->db->query("SELECT * FROM merge WHERE gh_id='$r->id' AND is_confirmed='0' AND is_blocked='0' ORDER BY id DESC");
	                        foreach ($merge->result() as $m){
	                ?>
	                     <div class="col-md-3 col-sm-6">
								<div class="item" style="border: 1px solid #000; height: auto;">
									<i class="fa fa-mobile"></i>
	                            <?php

	                                $days = $m->days." hours";
	                                $time_out_date = date('Y-m-d H:i:s', strtotime($m->date_created. " + $days"));
	                                $time_out = $this->admin_model->get_date_diff($time_out_date, date("Y-m-d H:i:s"));

	                                echo "<h4>You are match to receive</h4>";
									echo "<h4>₦ $m->amount </h4>";
									echo "<p>out of</p>";
									echo "<h4>₦ $r->amount </h4>";
									echo "<div style='font-size: 18px; color: #cf355d;'>";
									echo "<div class='col-md-4'>
											$time_out->hours <br>HRS
										</div>";

									echo "<div class='col-md-4'>
											$time_out->mins<br>MINS
										</div>";

									echo "<div class='col-md-4'>
											$time_out->sec<br>SECS
										</div>
									</div>";
	                                echo "<p>Details below<p><hr>";
	                                
	                                echo "<p>".$this->admin_model->get_user($this->admin_model->get_ph($m->ph_id)->username)->mobile."</br>";
	                                echo $this->admin_model->get_user($this->admin_model->get_ph($m->ph_id)->username)->bank_name."<br/>".$this->admin_model->get_user($this->admin_model->get_ph($m->ph_id)->username)->account_name."<br/>".$this->admin_model->get_user($this->admin_model->get_ph($m->ph_id)->username)->account_number."</p>";
	                                if($m->receipt == ""){
	                                    echo "<p>Awaiting POP</p>";
	                                }
	                                else{
	                                    echo "<p><a href='".$this->config->item('assets_url')."/pop/$m->receipt' target='_blank'><img src='".$this->config->item('assets_url')."/pop/$m->receipt' class='img-thumbnail' style='height:60px; width:90px;'></a></p><br/>";
	                                }

	                                // echo "<form action='' method='POST' id='form-confirm'><input type='hidden' name='merge_id' value='$m->id' /><input type='hidden' name='time_left' value='$time_out->hours' /></form>";
	                                echo "<p><button class='btn btn-success confirm' id='$m->id' t='$time_out->hours'>Confirm Payment</button><br/><br/>";
	                                $m_date_created = new DateTime($m->date_created);

	                                $m_time_out_date = new DateTime(date('Y-m-d H:i:s'));

	                                $p_time_out  =  $m_time_out_date->diff($m_date_created);

	                                // if($time_out->hours <= 1){
	                                    // echo "<form action='' method='POST' id='form-purge'><input type='hidden' name='merge_id' value='$m->id' /></form>";
	                                    echo "<button class='btn btn-danger flat-btn purge' id='$m->id'>Remove User</button></td>";
	                                // }
	                                
	                                
	                                $sn++;
	                            ?>                 
	                        </div>         
	                    </div>
	                <?php
	                        }
	                    }
	                ?>
	                <!-- end gh -->

	                <div class="col-md-12">
	                	<div class="board">
		                    <div class="header">
		                      <p>Bonus Payment List</p>
		                    </div> 
		                    <article>
		                        <table class="table table-bordered">
	                                <thead style="font-size: 15px; text-align: left;">
	                                    <tr>
	                                        <th>S/N</th>
	                                        <th>Trans Num</th>
	                                        <th>Type</th>
	                                        <th>Amount</th>
	                                        <th>Payment</th>
	                                    </tr>
	                                </thead>
	                                <tbody style="font-size: 13px; text-align: left;">
		                                <p>
		                                    <h4>Bonus Balance: ₦<?php echo $this->admin_model->get_user_bonus_balance($this->username); ?> </h4>
		                                    <?php
		                                        if($this->admin_model->get_user_bonus_balance($this->username) >= 20000){
		                                            echo "<form action='' method='POST' id='form-bonus'></form>";
		                                            echo "<button class='btn btn-success co-bonus' type='submit' name='cashout' form='form-bonus'>Cash Out Bonus</button>";
		                                        }else{
		                                            // echo "<button class='btn btn-default disabled'>Your Bonus Balance Must be ₦20000 before you can cash out</button>";
		                                        }
		                                    ?>
		                                    
		                                </p>
		                                <!-- <h3 style="color:red;">Once Merged, Make your payment immediately. <br/>Purge Button will appear after 20mins of inactivity</h3> -->
		                                <?php
		                                    $sn = 1;
		                                    $bonus = $this->db->query("SELECT * FROM bonus WHERE username='$this->username'");
		                                    foreach ($bonus->result() as $r) {
		                                        echo "<tr>";
		                                        echo "<td>$sn</td>";
		                                        echo "<td>$r->trans_num</td>";
		                                        echo "<td>$r->type</td>";
		                                        echo "<td>₦$r->amount</td>";
		                                        if($r->is_paid == 1){
		                                            echo "<td>PAID</td>";
		                                        }
		                                        else{
		                                            echo "<td>Awaiting payment</td>";
		                                        }

		                                        $sn++;
		                                        
		                                        echo "</tr>";
		                                    }
		                                ?>
	                                </tbody>
	                            </table>
		                    </article>
		                </div>
	                </div>

	                <div class="col-md-12">
	                	<div class="board">
		                    <div class="header">
		                      <p>Referral Activation Fee List</p>
		                    </div> 
		                    <article>
		                        <table class="table table-striped">
                                        <thead style="font-size: 15px;">
                                            <tr>
                                                <th>SN</th>
                                                <th>Amount</th>
                                                <th>User Details</th>
                                                <th>Confirmation</th>
                                                <th>Date Registered</th>
                                            </tr>
                                        </thead>
                                        <tbody style="color: #000; font-size: 14px; text-align: left;">

                                            <?php

                                                $sn = 1;

                                                $ph = $this->db->query("SELECT * FROM users WHERE ref='$this->username' AND activated='0' ORDER BY id DESC");

                                                foreach ($ph->result() as $r) {                                                   

                                                    echo "<tr>";

                                                    echo "<td>$sn</td>";
                                                    echo "<td>₦1,000</td>";

                                                    echo "<td>";
                                                    echo "<p>$r->fullname</p>";
                                                    echo "<p>$r->mobile</p>";
                                                    echo "</td>";

                                                    echo "<td>";
                                                    echo "<button class='btn btn-success confirm-act' id='$r->username'>Confirm Payment</button>";
                                                    echo "</td>";


                                                    echo "<td>$r->date_created</td>";

                                                    echo "</tr>";

                                                    $sn++;   
                                                }

                                            ?>

                                        </tbody>
                                </table>
		                    </article>
		                </div>
	                </div>
	                
	            </div>

	    </div>
    </section>



    <!-- POP Modal -->
    <div class="modal fade" id="pop">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h2 class="modal-title">Upload Proof of payment</h2>
                </div>
                <div class="modal-body">
                    <p>Only JPG, JPEG, PNG images allowed<br/>10MB Maximum Upload Size</p>
                        <form class="form-horizontal" role="form" method="post" action="" enctype="multipart/form-data">
                            <div class="form-group">
                                <div class="col-xs-12">
                                    <label for="name" class="control-label">Receipt</label>
                                    <input type="file" name="receipt" class="form-control"/>
                                </div>
                            </div>
                            <input type="hidden" name="merge_id" id="merge-id" class="form-control"/>
                            <input type="hidden" name="trans_num" id="trans-num" class="form-control"/>
                            <input type="submit" class="btn btn-primary" name="reg_pop" value="Submit"/>
                            <button class="btn btn-sm btn-danger" type="button" data-dismiss="modal">Close</button>
                        </form>
                </div><!-- /.modal-body -->
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
    <!-- END POP Modal -->
    <!-- Testimony Modal -->
    <div class="modal fade" id="testimony">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h2 class="modal-title">Testimony Form</h2>
                </div>
                <div class="modal-body">
                        <form class="form-horizontal" role="form" method="post" action="" enctype="multipart/form-data">
                            <div class="form-group">
                                <div class="col-xs-12">
                                    <label for="name" class="control-label">Share your experience</label>
                                    <textarea type="text" name="text" class="form-control" style="background-color:#eee;"/></textarea>
                                </div>
                            </div>
                            <input type="submit" class="btn btn-primary flat-btn" name="reg_testimony" value="Submit"/>
                            <button class="btn btn-sm btn-danger flat-btn" type="button" data-dismiss="modal">Close</button>
                        </form>
                </div><!-- /.modal-body -->
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
    <!-- END Testimony Modal -->
    

    <!-- Donation Modal -->
    <div class="modal fade" id="donation">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h2 class="modal-title">Donation Form</h2>
                </div>
                <div class="modal-body">
                <?php
                    if($this->admin_model->get_user_total_ph($this->username) == 0){
                ?>
                    <div>
                        <form class="form-horizontal" action="" method="POST">
                            <div class="form-group">
                            </div>

                            <div class="form-group">
                                <select class="form-control" name="amount">
                                    <option value="10000">₦10,0000</option>
                                    <option value="20000">₦20,0000</option>
                                    <option value="50000">₦50,0000</option>
                                </select>
                                <input type="hidden" name="recycle" value="0">
                            </div>

                            <div class="form-group">
                                <input type="submit" value="Donate Fund" name="donate" class="btn btn-info">
                            </div>
                        </form>
                    </div>
                <?php 
                    }
                    else{
                ?>
                    <form class="form-horizontal" action="" method="POST">
                        <div class="form-group">
                        	<p>Select a Package to recycle</p>
                        </div>

                        <div class="form-group">
                            <select class="form-control" name="amount">
                                <option value="10000">₦10,0000</option>
                                <option value="20000">₦20,0000</option>
                                <option value="50000">₦50,0000</option>
                            </select>
                            <input type="hidden" name="recycle" value="0">
                        </div>

                        <div class="form-group">
                            <input type="submit" value="Recycle Fund" name="recycle" class="btn btn-info">
                        </div>
                    </form>
                <?php
                }
                ?>
                </div><!-- /.modal-body -->
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
    <!-- END donation Modal -->

    <!-- merge ph Modal -->
    <div id="modal-merge" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg" style="margin-top: 100px;">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><strong>Receiver Details </strong></h4>
                </div>
                <div class="modal-body">
                      <div style="font-size: 18px;">
                      	<p style="font-size: 30px; text-align: center">LOADING....</p>
                      </div>

                </div>
                <div class="modal-footer">
                    <button class="btn btn-effect-ripple btn-danger" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- END merge ph Modal -->



    <!-- merge gh Modal -->
    <div id="modal-merge" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg" style="margin-top: 100px;">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><strong>Sender Details </strong></h4>
                </div>
                <div class="modal-body">
                      <div style="font-size: 18px;">
                      	<p style="font-size: 30px; text-align: center">LOADING....</p>
                      </div>

                </div>
                <div class="modal-footer">
                    <button class="btn btn-effect-ripple btn-danger" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- END merge ghModal -


