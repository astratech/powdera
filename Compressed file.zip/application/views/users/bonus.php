    <script type="text/javascript">
        //Ajax
        $(document).ready(function () {
        	$(".upload-pop").click(function(e){
        		e.preventDefault();
        		$("#merge-id").val($(this).attr('m'));
        		$("#trans-num").val($(this).attr('id'));
        		$("#pop").modal({});
        	});

        	$(".purge").click(function(e){
        		e.preventDefault();

        		$(".ld").show();

        		var m_id = $(this).attr('id');

        		var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";

        		var con = confirm("Are you sure?");

        		if(con){

        			$.ajax({

        				url: c_url,

        				type: 'post',

        				data: {'action': 'purge', 'merge_id': m_id},

        				success: function (data, status) {

        					var result = String(data);

        					result = result.trim();
        					$(".ld").hide();

        					if (result == "1") {
        						alert("Successful");
        						window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

        					}
        					else if (result == "paid") {
        						alert("Cant Purge user has already paid");
        						window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

        					}

        					else {

        						alert('failed');

        					}

        				},

        				error: function (xhr, desc, err) {

        					alert(err);
        					$(".ld").hide();


        				}

                    });//end ajax call

        		}
        		else{
        			$(".ld").hide();
        		}
        	});

        	$(".confirm").click(function(e){
        		e.preventDefault();

        		$(".ld").show();

        		var m_id = $(this).attr('id');
        		var t_id = $(this).attr('t');

        		var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";

        		var con = confirm("Are you sure you want to confirm this payment? \n");

        		if(con){

        			$.ajax({

        				url: c_url,

        				type: 'post',

        				data: {'action': 'confirm_payment', 'merge_id': m_id, 'time_left': t_id},

        				success: function (data, status) {

        					var result = String(data);

        					result = result.trim();
        					$(".ld").hide();

        					if (result == "1") {

        						window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

        					}

        					else {

        						alert('failed');

        					}

        				},

        				error: function (xhr, desc, err) {

        					alert(err);
        					$(".ld").hide();


        				}

                    });//end ajax call

        		}
        		else{
        			$(".ld").hide();
        		}
        	});

        	$(".report").click(function(e){
        		e.preventDefault();

        		$("#r-m").val($(this).attr('m'));
        		$("#report-modal").modal({});
                // alert($("#r-merge-id").val());
            });

        	$(".i-cant").click(function(e){
        		e.preventDefault();

        		$(".ld").show();

        		var m_id = $(this).attr('id');

        		var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";

        		var con = confirm("Are you sure you want to cancel this payment? \nYour Account will be blocked.");

        		if(con){

        			$.ajax({

        				url: c_url,

        				type: 'post',

        				data: {'action': 'cancel_payment', 'merge_id': m_id},

        				success: function (data, status) {

        					var result = String(data);

        					result = result.trim();
        					$(".ld").hide();

        					if (result == "1") {

        						window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

        					}
        					else if (result == "paid") {
        						alert("Cant cancel payment, you have paid some of the money. Please complete your transaction");
        						window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

        					}
        					else if (result == "paid") {
        						alert("Cant Purge user has already paid");
        						window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

        					}

        					else {

        						alert('failed');

        					}

        				},

        				error: function (xhr, desc, err) {

        					alert(err);
        					$(".ld").hide();


        				}

                    });//end ajax call

        		}
        		else{
        			$(".ld").hide();
        		}
        	});

        	$(".co-bonus").click(function(e){
        		e.preventDefault();
        		$(".page-wrapper").hide();
        		var m_id = $(this).attr('id');
        		var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";
        		var con = confirm("Are you sure you want to cash out your bonus? \n");
        		if(con){
        			$(".co-bonus").unbind('click').click();
        		}
        		else{
        			$(".page-wrapper").show();
        		}
        	});
        });//end ready
    </script>
    




    <div class="container">


    	<div class="row">
    		<div class="col-sm-12">
    			<div class="section-title">
    				<h2>Welcome <?php echo $this->username; ?>
                    <br/>
                     Bonus List</h2>
    			</div>
    		</div>
    	</div>


    	<div class="row" style="margin-bottom: 200px;">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <h3>My Bonus</h3>
                    </div>
                    <div class="panel-body" style="color: #000;">
                        <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>S/N</th>
                                        <th>Trans Num</th>
                                        <th>Type</th>
                                        <th>Amount</th>
                                        <th>Payment</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <p>
                                    <h4>Bonus Balance: ₦<?php echo $this->admin_model->get_user_bonus_balance($this->username); ?> </h4>
                                    <?php
                                        if($this->admin_model->get_user_bonus_balance($this->username) >= 20000){
                                            echo "<form action='' method='POST' id='form-bonus'></form>";
                                            echo "<button class='btn btn-success co-bonus' type='submit' name='cashout' form='form-bonus'>Cash Out Bonus</button>";
                                        }else{
                                            echo "<button class='btn btn-default disabled'>Your Bonus Balance Must be ₦20000 before you can cash out</button>";
                                        }
                                    ?>
                                    
                                </p>
                                <!-- <h3 style="color:red;">Once Merged, Make your payment immediately. <br/>Purge Button will appear after 20mins of inactivity</h3> -->
                                <?php
                                    $sn = 1;
                                    $bonus = $this->db->query("SELECT * FROM bonus WHERE username='$this->username'");
                                    foreach ($bonus->result() as $r) {
                                        echo "<tr>";
                                        echo "<td>$sn</td>";
                                        echo "<td>$r->trans_num</td>";
                                        echo "<td>$r->type</td>";
                                        echo "<td>₦$r->amount</td>";
                                        if($r->is_paid == 1){
                                            echo "<td>PAID</td>";
                                        }
                                        else{
                                            echo "<td>Awaiting payment</td>";
                                        }

                                        $sn++;
                                        
                                        echo "</tr>";
                                    }
                                ?>
                                </tbody>
                            </table>
                    </div>
                </div>
            </div>
    		
    	</div>


    </div>

