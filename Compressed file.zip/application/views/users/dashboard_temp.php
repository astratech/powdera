            <script type="text/javascript">
                //Ajax
                $(document).ready(function () {
                    $(".upload-pop").click(function(e){
                        e.preventDefault();
                        $("#merge-id").val($(this).attr('m'));
                        $("#trans-num").val($(this).attr('id'));
                        $("#pop").modal({});
                    });
                    $(".purge").click(function(e){
                        e.preventDefault();
                        var id = $(this).attr('id');
                        var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";
                        $(".page-wrapper").hide();
                        var con = confirm("Are you sure you want to purge this transaction?");
                        if(con){
                            $.ajax({
                                url: c_url,
                                type: 'post',
                                data: {'action': 'cancel_payment', 'merge_id': id},
                                success: function (data, status) {
                                    var result = String(data);
                                    result = result.trim();
                                    $(".page-wrapper").show();
                                    if (result == "1") {
                                        window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";
                                    }
                                    else {
                                        alert('failed');
                                    }
                                },
                                error: function (xhr, desc, err) {
                                    alert(err);
                                }
                            });//end ajax call
                        }
                        else{
                            $(".page-wrapper").show();
                        }
                    });
                    $(".confirm").click(function(e){
                        e.preventDefault();
                        $(".page-wrapper").hide();
                        var m_id = $(this).attr('id');
                        var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";
                        var con = confirm("Are you sure you want to confirm this payment? \n");
                        if(con){
                            $.ajax({
                                url: c_url,
                                type: 'post',
                                data: {'action': 'confirm_payment', 'merge_id': m_id},
                                success: function (data, status) {
                                    var result = String(data);
                                    result = result.trim();
                                    $(".page-wrapper").show();
                                    if (result == "1") {
                                        window.location.href = "<?php echo $this->config->base_url().'transactions' ?>";
                                    }
                                    else {
                                        alert('failed');
                                    }
                                },
                                error: function (xhr, desc, err) {
                                    alert(err);
                                }
                            });//end ajax call
                        }
                        else{
                            $(".page-wrapper").show();
                        }
                    });
                    $(".report").click(function(e){
                        e.preventDefault();
                        
                        $("#r-m").val($(this).attr('m'));
                        $("#report-modal").modal({});
                        // alert($("#r-merge-id").val());
                    });
                    $(".i-cant").click(function(e){
                        e.preventDefault();
                        var id = $(this).attr('id');
                        var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";
                        var con = confirm("Are you sure you want to cancel this payment?");
                        if(con){
                            $.ajax({
                                url: c_url,
                                type: 'post',
                                data: {'action': 'cancel_payment', 'merge_id': id},
                                success: function (data, status) {
                                    var result = String(data);
                                    result = result.trim();
                                    if (result == "1") {
                                        window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";
                                    }
                                    else {
                                        alert('failed');
                                    }
                                },
                                error: function (xhr, desc, err) {
                                    alert(err);
                                }
                            });//end ajax call
                        }
                    });
                });//end ready
            </script>
    <section class="section-back-image" style="padding-top:50px; background-size:cover; background-image: url('<?php echo $this->config->item("assets_url"); ?>/img/bg/p.jpg')">
       <div class="container">
            <div class="row">
                <?php 
                        if(isset($_SESSION['notification'])){
                            echo $_SESSION['notification'];
                        }
                    ?>
                <div class="col-md-12">
                    <div class="panel panel panel-danger">
                        <div class="panel-heading">
                            <h3 class="panel-title text-white">
                                <i class="fa fa-file-text"></i> NOTICE BOARD
                            </h3>
                        </div>
                        <div class="panel-body">
                            <h3>Welcome to Givers Purse</h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="panel panel panel-info">
                        <div class="panel-heading">
                            <h3 class="panel-title text-white">
                             My Purse
                            </h3>
                        </div>
                        <div class="panel-body">
                            <div class="col-md-12">
                                <form action="" method="post" class="form-horizontal">
                                    <div class="form-group">
                                        <label>Select a Package</label>
                                        <select style="background-color:#eee;" name="amount" class="form-control">
                                            <option value="10000">₦10,000</option>
                                            <option value="20000">₦20,000</option>
                                            <option value="50000">₦50,000</option>
                                        </select>
                                        <input type="submit" class="btn btn-danger" name="donate" value="Donate">
                                    </div>
                                </form>
                                <button class="btn btn-primary btn-lg flat-btn margin-t-10 buy" href="#testimony" data-toggle="modal">Share Testimony</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="panel panel panel-warning">
                        <div class="panel-heading">
                            <h3 class="panel-title text-white">
                             PH Merge List
                            </h3>
                        </div>
                        <div class="panel-body" style="color:#000;">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>S/N</th>
                                        <th>Status</th>
                                        <th>Trans Num</th>
                                        <th>Receiver's Name</th>
                                        <th>Phone number</th>
                                        <th>Bank Details</th>
                                        <th>Amount</th>
                                        <th>Time Left</th>
                                        <th>POP</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <h3 style="color:red;">Once Merged, Make your payment immediately. <br/>Purge Button will appear at the recipent end after 20mins of inactivity.</h3>
                                <?php
                                    $sn = 1;
                                    $ph = $this->db->query("SELECT * FROM ph WHERE username='$this->username' AND is_merge='1' AND is_confirmed='0'");
                                    foreach ($ph->result() as $r) {
                                        $merge = $this->db->query("SELECT * FROM merge WHERE ph_id='$r->id' AND is_confirmed='0' AND is_blocked='0' ORDER BY id DESC");
                                        foreach ($merge->result() as $m){
                                            $days = $m->days." hours";
                                            $time_out_date = date('Y-m-d H:i:s', strtotime($m->date_created. " + $days"));
                                            $time_out = $this->admin_model->get_date_diff($time_out_date, date("Y-m-d H:i:s"));
                                            echo "<tr>";
                                            echo "<td>$sn</td>";
                                            if($m->is_confirmed == 1){
                                                echo "<td><label class='label label-success'>confirmed</label></td>";
                                            }
                                            elseif($m->receipt != ''){
                                                echo "<td><label class='label label-default'>awaiting confirmation</label></td>";
                                            }
                                            else{
                                                echo "<td><label class='label label-default'>pending</label></td>";
                                            }
                                            
                                            echo "<td>$r->trans_num</td>";
                                            echo "<td>".$this->admin_model->get_user($this->admin_model->get_gh($m->gh_id)->username)->fullname."</td>";
                                            echo "<td>".$this->admin_model->get_user($this->admin_model->get_gh($m->gh_id)->username)->mobile."</td>";
                                            echo "<td>".$this->admin_model->get_user($this->admin_model->get_gh($m->gh_id)->username)->bank_name."<br/>".$this->admin_model->get_user($this->admin_model->get_gh($m->gh_id)->username)->account_name."<br/>".$this->admin_model->get_user($this->admin_model->get_gh($m->gh_id)->username)->account_number."</td>";
                                            echo "<td>₦$m->amount</td>";
                                            echo "<td>$time_out->hours Hours</td>";
                                            if($m->receipt == ""){
                                                echo "<td>Awaiting POP</td>";
                                                echo "<td><button class='btn btn-primary flat-btn upload-pop' id='$r->trans_num' m='$m->id'>Upload POP</button><br/><br/><button class='btn btn-danger flat-btn i-cant' id='$m->id'>Cancel Payment</button></td>";
                                            }
                                            else{
                                                echo "<td><a href='".$this->config->item('assets_url')."/pop/$m->receipt' target='_blank'><img src='".$this->config->item('assets_url')."/pop/$m->receipt' class='img-thumbnail' width='100' height='100'></a></td>";
                                                echo "<td><button class='btn btn-primary flat-btn upload-pop' id='$r->trans_num' m='$m->id'>Upload POP</button><br/><br/><button class='btn btn-danger flat-btn i-cant' id='$m->id'>Cancel Payment</button></td>";
                                            }
                                            
                                            echo "</tr>";
                                            $sn++;
                                            
                                        }
                                    }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="panel panel panel-success">
                        <div class="panel-heading">
                            <h3 class="panel-title text-white">
                             GH Merge List
                            </h3>
                        </div>
                        <div class="panel-body" style="color:#000;">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>S/N</th>
                                        <th>Status</th>
                                        <th>Trans Num</th>
                                        <th>Sender's Name</th>
                                        <th>Phone number</th>
                                        <th>Bank Details</th>
                                        <th>Amount</th>
                                        <th>Time Left</th>
                                        <th>POP</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <!-- <h3 style="color:red;">Once Merged, Make your payment immediately. <br/>Purge Button will appear after 20mins of inactivity</h3> -->
                                <?php
                                    $sn = 1;
                                    $gh = $this->db->query("SELECT * FROM gh WHERE username='$this->username' AND is_merge='1' AND is_confirmed='0'");
                                    foreach ($gh->result() as $r) {
                                        $merge = $this->db->query("SELECT * FROM merge WHERE gh_id='$r->id' AND is_confirmed='0' AND is_blocked='0'");
                                        if($merge->num_rows() > 0){
                                            foreach ($merge->result() as $m){
                                                $days = $m->days." hours";
                                                $time_out_date = date('Y-m-d H:i:s', strtotime($m->date_created. " + $days"));
                                                $time_out = $this->admin_model->get_date_diff($time_out_date, date("Y-m-d H:i:s"));
                                                echo "<tr>";
                                                echo "<td>$sn</td>";
                                                echo "<td><label class='label label-default'>awaiting payment</label>";
                                                
                                                echo "<td>$r->trans_num</td>";
                                                echo "<td>".$this->admin_model->get_user($this->admin_model->get_ph($m->ph_id)->username)->fullname."</td>";
                                                echo "<td>".$this->admin_model->get_user($this->admin_model->get_ph($m->ph_id)->username)->mobile."</td>";
                                                echo "<td>".$this->admin_model->get_user($this->admin_model->get_ph($m->ph_id)->username)->bank_name."<br/>".$this->admin_model->get_user($this->admin_model->get_ph($m->ph_id)->username)->account_name."<br/>".$this->admin_model->get_user($this->admin_model->get_ph($m->ph_id)->username)->account_number."</td>";
                                                echo "<td>₦$m->amount</td>";
                                                echo "<td>$time_out->hours Hours</td>";
                                                if($m->receipt == ""){
                                                    echo "<td>Awaiting POP</td>";
                                                }
                                                else{
                                                    echo "<td><a href='".$this->config->item('assets_url')."/pop/$m->receipt' target='_blank'><img src='".$this->config->item('assets_url')."/pop/$m->receipt' class='img-thumbnail' width='100' height='100'></a></td>";
                                                }
                                                
                                                echo "<td><button class='btn btn-success confirm' id='$m->id'>Confirm Payment</button><br/><br/>";
                                                $m_date_created = new DateTime($m->date_created);

                                                $m_time_out_date = new DateTime(date('Y-m-d H:i:s'));

                                                $p_time_out  =  $m_time_out_date->diff($m_date_created);
                                                
                                                if($p_time_out->i < 20){
                                                    echo "The Purge Button will appear in ".(20 - $p_time_out->i)." Mins";
                                                }
                                                else{
                                                    echo "<button class='btn btn-danger flat-btn purge' id='$m->id'>Purge</button></td>";
                                                }
                                                
                                                echo "</tr>";
                                                $sn++;
                                                
                                            }
                                        }
                                        else{
                                           echo "<h1>Be Patient no GH merging Found.</h1>";
                                        }
                                    }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
            </div>
       </div>
    </section>
            
    <!-- POP Modal -->
    <div class="modal fade" id="pop">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h2 class="modal-title">Upload Proof of payment</h2>
                </div>
                <div class="modal-body">
                    <p>Only JPG, JPEG, PNG images allowed<br/>10MB Maximum Upload Size</p>
                        <form class="form-horizontal" role="form" method="post" action="" enctype="multipart/form-data">
                            <div class="form-group">
                                <div class="col-xs-12">
                                    <label for="name" class="control-label">Receipt</label>
                                    <input type="file" name="receipt" class="form-control"/>
                                </div>
                            </div>
                            <input type="hidden" name="merge_id" id="merge-id" class="form-control"/>
                            <input type="hidden" name="trans_num" id="trans-num" class="form-control"/>
                            <input type="submit" class="btn btn-primary" name="reg_pop" value="Submit"/>
                            <button class="btn btn-sm btn-danger" type="button" data-dismiss="modal">Close</button>
                        </form>
                </div><!-- /.modal-body -->
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
    <!-- END POP Modal -->
    <!-- Testimony Modal -->
    <div class="modal fade" id="testimony">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h2 class="modal-title">Testimony Form</h2>
                </div>
                <div class="modal-body">
                        <form class="form-horizontal" role="form" method="post" action="" enctype="multipart/form-data">
                            <div class="form-group">
                                <div class="col-xs-12">
                                    <label for="name" class="control-label">Share your experience</label>
                                    <textarea type="text" name="text" class="form-control" style="background-color:#eee;"/></textarea>
                                </div>
                            </div>
                            <input type="submit" class="btn btn-primary flat-btn" name="reg_testimony" value="Submit"/>
                            <button class="btn btn-sm btn-danger flat-btn" type="button" data-dismiss="modal">Close</button>
                        </form>
                </div><!-- /.modal-body -->
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
    <!-- END Testimony Modal -->
    <!-- Report Modal -->
    <div class="modal fade" id="report-modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h2 class="modal-title">Report Transaction Form</h2>
                </div>
                <div class="modal-body">
                        <form class="form-horizontal" role="form" method="post" action="" enctype="multipart/form-data">
                            <div class="form-group">
                                <div class="col-xs-12">
                                    <label for="name" class="control-label">State the problem in full details</label>
                                    <textarea type="text" name="reason" class="form-control"/></textarea>
                                </div>
                            </div>
                            <input type="hidden" name="merge_id" id="r-m" class="form-control">
                            <input type="submit" class="btn btn-primary flat-btn" name="reg_report" value="Submit"/>
                            <button class="btn btn-sm btn-danger flat-btn" type="button" data-dismiss="modal">Close</button>
                        </form>
                </div><!-- /.modal-body -->
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
    <!-- END Testimony Modal -->