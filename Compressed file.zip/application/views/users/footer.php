<footer class="footer ">
                <div class="container ">
                    <p class="copyright float-right ">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>
                    </p>
                </div>
            </footer>
        </div>
        
    </div>
</body>

</html>