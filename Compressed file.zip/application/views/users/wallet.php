            <script type="text/javascript">

                //Ajax

                $(document).ready(function () {

                });//end ready

            </script>

            <div class="page-content" style="padding-top:80px;">
                <div class="block" id="features">
                    <div class="container">
                    <?php 
                        if(isset($_SESSION['notification'])){
                            echo $_SESSION['notification'];
                        }
                    ?>
                        <!-- Action Box -->
                        <div class="row">

                            <!-- Notice Board -->
                            <div class="col-md-12">
                                <div class="panel spanel panel-danger">
                                    <div class="panel-heading">
                                        <h3 class="panel-title text-white">
                                            <i class="fa fa-file-text"></i> Notification
                                        </h3>
                                    </div>
                                    <div class="panel-body">
                                        <h1>Boost this community, always recycle</h1>
                                    </div>
                                </div>
                            </div>
                            <!-- END Notice Board -->
                        </div>
                        <!-- END Action Box -->

                        <div class="row">

                            <!-- Outgoing Transactions -->
                            <div class="col-md-12">
                                <div class="panel spanel panel-collapse">
                                    <div class="panel-heading">
                                        <h3 class="panel-title text-white">
                                            E-wallet
                                        </h3>
                                    </div>
                                    <div class="panel-body table-responsive">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>S/N</th>
                                                    <th>Trans Num</th>
                                                    <th>Amount</th>
                                                    <th>Action</th>
                                                    <th>Cash Out</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php

                                                $sn = 1;
                                                $ph = $this->db->query("SELECT * FROM wallet WHERE username='$this->username' AND is_recycle='0' ORDER BY id DESC");

                                                foreach ($ph->result() as $r) {
                                                        echo "<tr>";
                                                        echo "<td>$sn</td>";
                                                        echo "<td>$r->trans_num</td>";
                                                        echo "<td>₦$r->amount</td>";
                                                        echo "<form action='' method='POST' id='form-donate'><input type='hidden' name='amount' value='$r->amount' /><input type='hidden' name='trans_num' value='$r->trans_num' /></form>";
                                                        echo "<td><button type='submit' name='recycle' form='form-donate' class='btn btn-primary'>Recycle</button></td>";
                                                        if($this->admin_model->is_wallet_cashable($this->username, $r->amount)){
                                                            echo "<form action='' method='POST' id='form-cash'><input type='hidden' name='amount' value='$r->amount' /><input type='hidden' name='trans_num' value='$r->trans_num' /></form>";
                                                            echo "<td><button type='submit' name='cash_out' form='form-cash' class='btn btn-success'>Cash Out</button></td>";
                                                        }
                                                        else{
                                                            echo "<td><button class='btn btn-default'>".(5 - $this->admin_model->get_wallet_times($this->username, $r->amount))." Recycle Remaining</button></td>";
                                                        }
                                                        echo "</tr>";
                                                        $sn++;
                                                        
                                                }
                                            ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- END Outgoing Transactions -->
                        </div>
                        <!--/ .row-->
                    </div>
                    <!--/ .container-->
                    <div class="bg bg-color-neutral opacity-50"></div><!--/ .bg-->
                </div>
                <!--/ .block-->


                <div class="space"></div>

                <div class="container">
                    
                </div>
                <!--/ .container-->

            </div>


        </div>
    </div>