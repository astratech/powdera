    <script type="text/javascript">
        //Ajax
        $(document).ready(function () {
        	$(".upload-pop").click(function(e){
        		e.preventDefault();
        		$("#merge-id").val($(this).attr('m'));
        		$("#trans-num").val($(this).attr('id'));
        		$("#pop").modal({});
        	});

        	$(".purge").click(function(e){
        		e.preventDefault();

        		$(".ld").show();

        		var m_id = $(this).attr('id');

        		var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";

        		var con = confirm("Are you sure?");

        		if(con){

        			$.ajax({

        				url: c_url,

        				type: 'post',

        				data: {'action': 'purge', 'merge_id': m_id},

        				success: function (data, status) {

        					var result = String(data);

        					result = result.trim();
        					$(".ld").hide();

        					if (result == "1") {
        						alert("Successful");
        						window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

        					}
        					else if (result == "paid") {
        						alert("Cant Purge user has already paid");
        						window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

        					}

        					else {

        						alert('failed');

        					}

        				},

        				error: function (xhr, desc, err) {

        					alert(err);
        					$(".ld").hide();


        				}

                    });//end ajax call

        		}
        		else{
        			$(".ld").hide();
        		}
        	});

        	$(".confirm").click(function(e){
        		e.preventDefault();

        		$(".ld").show();

        		var m_id = $(this).attr('id');
        		var t_id = $(this).attr('t');

        		var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";

        		var con = confirm("Are you sure you want to confirm this payment? \n");

        		if(con){

        			$.ajax({

        				url: c_url,

        				type: 'post',

        				data: {'action': 'confirm_payment', 'merge_id': m_id, 'time_left': t_id},

        				success: function (data, status) {

        					var result = String(data);

        					result = result.trim();
        					$(".ld").hide();

        					if (result == "1") {

        						window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

        					}

        					else {

        						alert('failed');

        					}

        				},

        				error: function (xhr, desc, err) {

        					alert(err);
        					$(".ld").hide();


        				}

                    });//end ajax call

        		}
        		else{
        			$(".ld").hide();
        		}
        	});

        	$(".report").click(function(e){
        		e.preventDefault();

        		$("#r-m").val($(this).attr('m'));
        		$("#report-modal").modal({});
                // alert($("#r-merge-id").val());
            });

        	$(".i-cant").click(function(e){
        		e.preventDefault();

        		$(".ld").show();

        		var m_id = $(this).attr('id');

        		var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";

        		var con = confirm("Are you sure you want to cancel this payment? \nYour Account will be blocked.");

        		if(con){

        			$.ajax({

        				url: c_url,

        				type: 'post',

        				data: {'action': 'cancel_payment', 'merge_id': m_id},

        				success: function (data, status) {

        					var result = String(data);

        					result = result.trim();
        					$(".ld").hide();

        					if (result == "1") {

        						window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

        					}
        					else if (result == "paid") {
        						alert("Cant cancel payment, you have paid some of the money. Please complete your transaction");
        						window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

        					}
        					else if (result == "paid") {
        						alert("Cant Purge user has already paid");
        						window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

        					}

        					else {

        						alert('failed');

        					}

        				},

        				error: function (xhr, desc, err) {

        					alert(err);
        					$(".ld").hide();


        				}

                    });//end ajax call

        		}
        		else{
        			$(".ld").hide();
        		}
        	});

        	$(".co-bonus").click(function(e){
        		e.preventDefault();
        		$(".page-wrapper").hide();
        		var m_id = $(this).attr('id');
        		var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";
        		var con = confirm("Are you sure you want to cash out your bonus? \n");
        		if(con){
        			$(".co-bonus").unbind('click').click();
        		}
        		else{
        			$(".page-wrapper").show();
        		}
        	});
        });//end ready
    </script>
    




    <div class="container">

    	<div class="row" style="margin-bottom: 200px; margin-top: 120px;">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3>My Downlines</h3>
                    </div>
                    <div class="panel-body" style="color: #000;">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>SN</th>
                                    <th>Full Name</th>
                                    <th>Phone Number</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php

                                    $sn = 1;

                                    $ph = $this->db->query("SELECT * FROM users WHERE ref='$this->username' ORDER BY id DESC");

                                    foreach ($ph->result() as $r) {
                                       

                                        echo "<tr>";

                                        echo "<td>$sn</td>";

                                        echo "<td>$r->fullname</td>";

                                        echo "<td>$r->mobile</td>";

                                        echo "</tr>";

                                        $sn++;   
                                    }

                                ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    		
    	</div>


    </div>

