    <script type="text/javascript">
        //Ajax
        $(document).ready(function () {
        	$(".upload-pop").click(function(e){
        		e.preventDefault();
        		$("#merge-id").val($(this).attr('m'));
        		$("#trans-num").val($(this).attr('id'));
        		$("#pop").modal({});
        	});

        	$(".i-cant").click(function(e){
        		e.preventDefault();

        		$(".ld").show();

        		var m_id = $(this).attr('id');

        		var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";

        		var con = confirm("Are you sure you want to cancel this payment? \nYour Account will be blocked.");

        		if(con){

        			$.ajax({

        				url: c_url,

        				type: 'post',

        				data: {'action': 'cancel_payment', 'merge_id': m_id},

        				success: function (data, status) {

        					var result = String(data);

        					result = result.trim();
        					$(".ld").hide();

        					if (result == "1") {

        						window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

        					}
        					else if (result == "paid") {
        						alert("Cant cancel payment, you have paid some of the money. Please complete your transaction");
        						window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

        					}
        					else if (result == "paid") {
        						alert("Cant Purge user has already paid");
        						window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

        					}

        					else {

        						alert('failed');

        					}

        				},

        				error: function (xhr, desc, err) {

        					alert(err);
        					$(".ld").hide();


        				}

                    });//end ajax call

        		}
        		else{
        			$(".ld").hide();
        		}
        	});

        	$(".co-bonus").click(function(e){
        		e.preventDefault();
        		$(".page-wrapper").hide();
        		var m_id = $(this).attr('id');
        		var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";
        		var con = confirm("Are you sure you want to cash out your bonus? \n");
        		if(con){
        			$(".co-bonus").unbind('click').click();
        		}
        		else{
        			$(".page-wrapper").show();
        		}
        	});

            $(".make-gh").click(function(e){
                e.preventDefault();

                $(".ld").hide();

                var m_id = $(this).attr('id');

                var c_url = "<?php echo $this->config->base_url().'donations' ?>";

                var con = confirm("Are you sure you want to request this fund?\nNOTE: 20% of your Request will be locked, until you recommit.");

                if(con){

                    $.ajax({

                        url: c_url,

                        type: 'post',

                        data: {'action': 'make_gh', 'ph_id': m_id},

                        success: function (data, status) {

                            var result = String(data);

                            result = result.trim();
                            $(".ld").show();

                            if (result == "1") {
                                alert("Successful");
                                window.location.href = "<?php echo $this->config->base_url().'requests' ?>";

                            }

                            else {

                                alert('failed');

                            }

                        },

                        error: function (xhr, desc, err) {

                            alert(err);
                            $(".ld").show();;


                        }

                    });//end ajax call

                }
                else{
                    $(".ld").show();
                }
            });
        });//end ready
    </script>
    




    <div class="container ld" >

    	<div class="row" style="margin-bottom: 200px; padding-top: 200px;">

    		<div class="col-md-12">
                <?php 
                    if(isset($_SESSION['notification'])){
                        echo $_SESSION['notification'];
                    }

                ?>
    			<div class="pat2" style="background-color: #239b59;">
    				<header>
    					<p>Donation History</p>
    				</header>
    				<article class="p2body">
    					<table class="table table-bordered table-striped">
	                        <thead>
	                            <tr>
	                                <th>SN</th>
	                                <th>Amount</th>
	                                <th>Date</th>
                                    <th>Donation Confirmed</th>
                                    <th>Release Date</th>
	                                <th>Request Fund</th>
	                            </tr>
	                        </thead>
	                        <tbody>

	                            <?php

	                                $sn = 1;

	                                $ph = $this->db->query("SELECT * FROM ph WHERE username='$this->username' ORDER BY id DESC");

	                                foreach ($ph->result() as $r) {
	                                    $days_left = $this->admin_model->get_date_diff($r->release_date, date('Y-m-d H:i:s'))->days;

	                                    echo "<tr>";

	                                    echo "<td>$sn</td>";

	                                    echo "<td>₦$r->amount</td>";

	                                    echo "<td>$r->date_created</td>";

	                                    if($r->is_confirmed == 1){
	                                        echo "<td>YES</td>";
	                                    }
	                                    else{
	                                        echo "<td>NO</td>";
	                                    }

                                        echo "<td>$r->release_date";
                                        if($days_left > 0){
                                            echo "<br><span style='color:red; font-weight: bold;'>$days_left Days Left</span>";
                                        }else{
                                             
                                        }

                                        echo "</td>";
                                        
                                        echo "<td>";

                                        if($r->is_gh == 1){
                                            echo "DONE";
                                        }
                                        // elseif($r->is_confirmed == 1 AND $days_left > 1 AND $days_left < 7){
                                        //     echo "<button class='btn btn-sm btn-default' style='color:#000;'><i class='fa fa-cc'></i> Button appears in $days_left Days</button>";
                                        // }
                                        elseif($r->is_confirmed == 1){
                                            echo "<button class='btn btn-sm btn-success make-gh' id='$r->id'><i class='fa fa-cc'></i>  Request Fund</button>";
                                        }
                                        else{
                                            echo "<button class='btn btn-default' style='color:#000;'>Payment Not Confirmed Yet</button>";
                                        }
                                        echo "</td>";
	                                    

	                                    echo "</tr>";

	                                    $sn++;   
	                                }

	                            ?>

	                        </tbody>
	                    </table>
    				</article>
    			</div>
    		</div>

    		
    	</div>


    </div>

