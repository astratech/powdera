    <script type="text/javascript">
        //Ajax
        $(document).ready(function () {
        	$(".co-bonus").click(function(e){
        		e.preventDefault();
        		$(".page-wrapper").hide();
        		var m_id = $(this).attr('id');
        		var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";
        		var con = confirm("Are you sure you want to cash out your bonus? \n");
        		if(con){
        			$(".co-bonus").unbind('click').click();
        		}
        		else{
        			$(".page-wrapper").show();
        		}
        	});
        });//end ready
    </script>
    




    <div class="container">


    	<div class="row" style="margin-bottom: 200px; padding-top: 200px;">
            <div class="col-md-12">
                <?php 
                    if(isset($_SESSION['notification'])){
                        echo $_SESSION['notification'];
                    }

                ?>
                <div class="pat2" style="background-color: #239b59;">
                    <header>
                        <p>Request History</p>
                    </header>
                    <div class="p2body" style="color: #000;">
                        <p>NOTICE: You must recommit to have access to the Locked GH.</p>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>SN</th>
                                    <th>Amount Expected</th>
                                    <th>Date</th>
                                    <th>Payment Received</th>
                                    <th>Payment Access</th>

                                </tr>
                            </thead>
                            <tbody>

                                <?php

                                    $sn = 1;

                                    $ph = $this->db->query("SELECT * FROM gh WHERE username='$this->username' ORDER BY id DESC");

                                    foreach ($ph->result() as $r) {
                                       

                                        echo "<tr>";

                                        echo "<td>$sn</td>";

                                        echo "<td>₦$r->amount</td>";

                                        echo "<td>$r->date_created</td>";

                                        if($r->is_confirmed == 1){
                                            echo "<td>YES</td>";
                                        }
                                        else{
                                            echo "<td>NO</td>";
                                        }

                                        if($r->locked == 1){
                                            echo "<td style='color: #ab0918;'><i class='fa fa-lock'></i> LOCKED</td>";
                                        }
                                        else{
                                            echo "<td>AVAILABLE</td>";
                                        }
                                        

                                        echo "</tr>";

                                        $sn++;   
                                    }

                                ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    		
    	</div>


    </div>

