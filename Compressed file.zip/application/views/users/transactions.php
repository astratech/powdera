        <script type="text/javascript">
            //Ajax
            $(document).ready(function () {
                $(".upload-pop").click(function(e){
                    e.preventDefault();
                    $("#merge-id").val($(this).attr('m'));
                    $("#trans-num").val($(this).attr('id'));
                    $("#pop").modal({});
                });

                $(".cancel-payment").click(function(e){
                    e.preventDefault();

                    $(".ld").show();

                    var ph_id = $(this).attr('id');

                    var c_url = "<?php echo $this->config->base_url().'ph' ?>";

                    var con = confirm("Are you sure?");

                    if(con){

                        $.ajax({

                            url: c_url,

                            type: 'post',

                            data: {'action': 'cancel_payment', 'ph_id': ph_id},

                            success: function (data, status) {

                                var result = String(data);

                                result = result.trim();
                                $(".ld").hide();

                                if (result == "1") {
                                    alert("Successful");
                                    window.location.href = "<?php echo $this->config->base_url().'ph' ?>";

                                }
                                else {

                                    alert('failed');

                                }

                            },

                            error: function (xhr, desc, err) {

                                alert(err);
                                $(".ld").hide();


                            }

                        });//end ajax call

                    }
                    else{
                        $(".ld").hide();
                    }
                });

                $(".confirm").click(function(e){
                    e.preventDefault();

                    $(".ld").show();

                    var m_id = $(this).attr('id');
                    var t_id = $(this).attr('t');

                    var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";

                    var con = confirm("Are you sure you want to confirm this payment? \n");

                    if(con){

                        $.ajax({

                            url: c_url,

                            type: 'post',

                            data: {'action': 'confirm_payment', 'merge_id': m_id, 'time_left': t_id},

                            success: function (data, status) {

                                var result = String(data);

                                result = result.trim();
                                $(".ld").hide();

                                if (result == "1") {

                                    window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

                                }

                                else {

                                    alert('failed');

                                }

                            },

                            error: function (xhr, desc, err) {

                                alert(err);
                                $(".ld").hide();


                            }

                        });//end ajax call

                    }
                    else{
                        $(".ld").hide();
                    }
                });

                $(".report").click(function(e){
                    e.preventDefault();

                    $("#r-m").val($(this).attr('m'));
                    $("#report-modal").modal({});
                    // alert($("#r-merge-id").val());
                });

                $(".i-cant").click(function(e){
                    e.preventDefault();

                    $(".ld").show();

                    var m_id = $(this).attr('id');

                    var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";

                    var con = confirm("Are you sure you want to cancel this payment? \nYour Account will be blocked.");

                    if(con){

                        $.ajax({

                            url: c_url,

                            type: 'post',

                            data: {'action': 'cancel_payment', 'merge_id': m_id},

                            success: function (data, status) {

                                var result = String(data);

                                result = result.trim();
                                $(".ld").hide();

                                if (result == "1") {

                                    window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

                                }
                                else if (result == "paid") {
                                    alert("Cant cancel payment, you have paid some of the money. Please complete your transaction");
                                    window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

                                }
                                else if (result == "paid") {
                                    alert("Cant Purge user has already paid");
                                    window.location.href = "<?php echo $this->config->base_url().'dashboard' ?>";

                                }

                                else {

                                    alert('failed');

                                }

                            },

                            error: function (xhr, desc, err) {

                                alert(err);
                                $(".ld").hide();


                            }

                        });//end ajax call

                    }
                    else{
                        $(".ld").hide();
                    }
                });

                $(".co-bonus").click(function(e){
                    e.preventDefault();
                    $(".page-wrapper").hide();
                    var m_id = $(this).attr('id');
                    var c_url = "<?php echo $this->config->base_url().'dashboard' ?>";
                    var con = confirm("Are you sure you want to cash out your bonus? \n");
                    if(con){
                        $(".co-bonus").unbind('click').click();
                    }
                    else{
                        $(".page-wrapper").show();
                    }
                });

                $(".make-gh").click(function(e){
                    e.preventDefault();

                    $(".ld").hide();

                    var m_id = $(this).attr('id');

                    var c_url = "<?php echo $this->config->base_url().'ph' ?>";

                    var con = confirm("Are you sure you wanna GH this transaction?\nNOTE: 30% of your GH will be locked, until you recommit mininum of 20% of this PH.");

                    if(con){

                        $.ajax({

                            url: c_url,

                            type: 'post',

                            data: {'action': 'make_gh', 'ph_id': m_id},

                            success: function (data, status) {

                                var result = String(data);

                                result = result.trim();
                                $(".ld").show();

                                if (result == "1") {
                                    alert("Successful");
                                    window.location.href = "<?php echo $this->config->base_url().'gh' ?>";

                                }

                                else {

                                    alert('failed');

                                }

                            },

                            error: function (xhr, desc, err) {

                                alert(err);
                                $(".ld").show();;


                            }

                        });//end ajax call

                    }
                    else{
                        $(".ld").show();
                    }
                });


                $(".cash-out").click(function(e){
                    var ph_id = $(this).attr('id');
                    $("#modal-ph_id").val(ph_id);
                    $("#modal-ph").modal({});
                });
            });//end ready
        </script>


        <!-- Main Content -->
        <section class="features text-center" id="about" style="min-height: 1000px; padding-top: 90px; margin-top: 30px;">
            <div class="container">
    
                <div class="row">
                    <?php 
                    if(isset($_SESSION['notification'])){
                        echo $_SESSION['notification'];
                    }
                ?>
                    <div class="col-md-12">
                        <div class="board">
                            <div class="header">
                                <p>PH History</p>
                            </div>
                            <article class="table-responsive">
                                <table class="table table-striped">
                                        <thead style="font-size: 15px;">
                                            <tr>
                                                <th>SN</th>
                                                <th>Ref ID</th>
                                                <th>Amount</th>
                                                <th>Date Created</th>
                                                <th>Status</th>
                                                <th>Expected Return</th>
                                                <!-- <th>Release Date</th> -->
                                                <th>Request GH</th>
                                                <!-- <th>Delete</th> -->
                                            </tr>
                                        </thead>
                                        <tbody style="color: #000; font-size: 14px;">

                                            <?php

                                                $sn = 1;

                                                $ph = $this->db->query("SELECT * FROM ph WHERE username='$this->username' ORDER BY id DESC");

                                                foreach ($ph->result() as $r) {

                                                    $days = $this->admin_model->get_date_diff($r->release_date, date('Y-m-d H:i:s'))->days;
                                                   

                                                    echo "<tr>";

                                                    echo "<td>$sn</td>";
                                                    echo "<td>$r->trans_num</td>";

                                                    echo "<td>₦$r->amount</td>";

                                                    echo "<td>$r->date_created</td>";

                                                    if($r->is_confirmed == 1){
                                                        echo "<td>SUCCESSFUL</td>";
                                                    }
                                                    elseif ($r->is_merge == 1) {
                                                        echo "<td>MERGED</td>";
                                                    }
                                                    else{
                                                        echo "<td>PENDING</td>";
                                                    }

                                                    echo "<td>₦$r->returns</td>";
                                                    // echo "<td>$r->release_date</td>";


                                                    echo "<td>";
                                                    if($r->is_gh == 1){
                                                        echo "DONE";
                                                    }
                                                    elseif($r->is_confirmed){
                                                        $gh_time = $this->admin_model->get_option("gh_time")->value;
                                                        $d1 =  date('Y-m-d H:i:s', strtotime($r->date_confirmed. " + $gh_time hours"));
                                                        $d2 = $this->admin_model->get_date_diff($d1, date('Y-m-d H:i:s'))->hours;
                                                        echo $d2;
                                                        if($d2 > 0){
                                                            echo "<button class='btn btn-sm btn-defaul'> $d2 Hours left</button>";
                                                        }
                                                        else{
                                                            echo "<button class='btn btn-sm btn-success cash-out' id='$r->id'><i class='fa fa-cc'></i>  Request Donation</button>";
                                                        }

                                                        echo "<button class='btn btn-sm btn-success cash-out' id='$r->id'><i class='fa fa-cc'></i>  Request Donation</button>";
                                                        
                                                    }
                                                    else{
                                                        echo "<button class='btn btn-default'>Donation Not Confirmed Yet</button>";
                                                    }
                                                    
                                                    echo "</td>";

                                                    // if($r->is_merge == 0){
                                                    //     $ph_id = $r->id;
                                                    //     echo "<td><button class='btn btn-danger cancel-payment' id='$ph_id' >Delete Donation</button></td>";
                                                    // }

                                                    echo "</tr>";

                                                    $sn++;   
                                                }

                                            ?>

                                        </tbody>
                                </table>
                            </article>
                        </div>
                    </div>  


                    <div class="col-md-12">
                        <div class="board">
                            <div class="header">
                                <p>GH History</p>
                            </div>
                            <article class="table-responsive">
                                <table class="table table-striped" style="color: #000; font-size: 15px;">
                                        <thead style="text-align: center;">
                                            <tr>
                                                <th>SN</th>
                                                <th>Amount</th>
                                                <th>Status</th>
                                                <!-- <th>Lockage</th> -->
                                            </tr>
                                        </thead>
                                        <tbody style="font-size: 14px; text-align: left;">

                                            <?php

                                                $sn = 1;

                                                $ph = $this->db->query("SELECT * FROM gh WHERE username='$this->username' ORDER BY id DESC");

                                                foreach ($ph->result() as $r) {
                                                   

                                                    echo "<tr>";

                                                    echo "<td>$sn</td>";

                                                    echo "<td>₦$r->amount</td>";

                                                    if($r->is_confirmed == 1){
                                                        echo "<td>SUCCESSFUL</td>";
                                                    }
                                                    elseif ($r->is_merge == 1) {
                                                        echo "<td>MERGED</td>";
                                                    }
                                                    else{
                                                        echo "<td>PENDING</td>";
                                                    }

                                                    // if($r->locked == 1){
                                                    //     echo "<td style='color: #ab0918;'><i class='fa fa-lock'></i> LOCKED</td>";
                                                    // }
                                                    // else{
                                                    //     echo "<td>OPEN</td>";
                                                    // }
                                                    

                                                    echo "</tr>";

                                                    $sn++;   
                                                }

                                            ?>

                                        </tbody>
                                    </table>
                            </article>
                        </div>
                    </div>             


                    <div class="col-md-12">
                        <div class="board">
                            <div class="header">
                                <p>All Transactions History</p>
                            </div>
                            <article class="panel-body table-responsive">
                                <table class="table table-striped table-condensed">

                                    <thead style="font-size: 15px; text-align: left;">

                                        <tr>

                                            <th>S/N</th>

                                            <th>Transaction Type</th>

                                            <th>Transaction Ref ID</th>

                                            <th>Amount</th>

                                            <th>Date</th>

                                            

                                        </tr>

                                    </thead>

                                    <tbody style="font-size: 13px; text-align: left;">

                                    <?php

                                        $sn = 1;

                                        $ph = $this->db->query("SELECT * FROM ph WHERE username='$this->username' ORDER BY id DESC");

                                        foreach ($ph->result() as $r) {

                                            $merge = $this->db->query("SELECT * FROM merge WHERE ph_id='$r->id' AND is_confirmed='1' ORDER BY id DESC");

                                            foreach ($merge->result() as $m){

                                                echo "<tr>";

                                                echo "<td>$sn</td>";

                                                echo "<td>PH</td>";
                                                echo "<td>".$this->admin_model->get_ph($m->ph_id)->trans_num."</td>";

                                                echo "<td>₦".$m->amount."</td>";                                            

                                                echo "<td>".date('d/M/Y', strtotime($m->date_paid))."</td>";                                             

                                                echo "</tr>";

                                                $sn++;

                                            }

                                        }



                                        $gh = $this->db->query("SELECT * FROM gh WHERE username='$this->username' ORDER BY id DESC");

                                        foreach ($gh->result() as $r) {

                                            $merge = $this->db->query("SELECT * FROM merge WHERE gh_id='$r->id' AND is_confirmed='1' ORDER BY id DESC");

                                            foreach ($merge->result() as $m){

                                                echo "<tr>";

                                                echo "<td>$sn</td>";

                                                echo "<td>GH</td>";

                                                echo "<td>₦".$m->amount."</td>";                                            

                                                echo "<td>".date('D-M-Y', strtotime($m->date_paid))."</td>";                                            

                                                echo "</tr>";

                                                $sn++;

                                            }

                                        }

                                    ?>

                                    </tbody>

                                </table>
                            </article>
                        </div>
                    </div>
                </div>

            </div>
        </section>

    <!-- PH Modal -->
    <div id="modal-ph" class="modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg" style="margin-top: 100px;">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h3 class="modal-title"><strong>Request my donation</strong></h3>
                </div>
                <form action="" method="post" class="form-horizontal">
                <div class="modal-body">
                        <p>Remember to recycle when you get your Full GH</p>
                        <br>
                            <div class="form-group">

                                <div class="col-xs-12">
                                   
                                    <!-- <select class="form-control" name="amount">
                                        <option value="10000">₦10,0000</option>
                                        <option value="20000">₦20,0000</option>
                                        <option value="50000">₦50,0000</option>
                                    </select> -->

                                    <!-- <input type="hidden" name="recycle" value="1"> -->
                                    <input type="hidden" name="ph_id" class="form-control" value="" id="modal-ph_id">
                                </div>
                            </div>

                </div>
                <div class="modal-footer">
                    <input type="submit" class="btn btn-effect-ripple btn-primary" name="cash_gh" value="Continue"/>
                    <button class="btn btn-effect-ripple btn-danger" data-dismiss="modal">Close</button>
                </div>
                </form>   
            </div>
        </div>
    </div>
    <!-- END PH Modal -->
           