<!-- Begin Page Content -->
        <main id="page-content">

            <!-- 
                Main content of the app is stored inside #page-content
            -->
        
            <!-- Begin Page Title -->
            <div class="page-title">
                <h3>Testimony</h3>
            </div>

            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                    <!-- BEgin Panel -->
                    <div class="panel-x panel-transparent" style="background-color: #fff;">
                        <!-- Begin Panel Body -->
                        <div class="panel-body">
                            <p class="header text-uppercase">Testimony</p>
                            <p></p>
                            

                            <!-- Begin Table Responsive -->
                            <div class="table-responsive">
                                <!-- Begin Table Bordered -->
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Testimony</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                   
                                    <tbody>
                                    <?php
                                        $sn = 1;
                                        $gh = $this->db->query("SELECT * FROM testimony ORDER BY id DESC");

                                        foreach ($gh->result() as $r) {

                                                echo "<tr>";

                                                echo "<td>$sn</td>";

                                                echo "<td>".$this->admin_model->get_user($r->username)->fullname."</td>";

                                                echo "<td>$r->text</td>";

                                                echo "<td>$r->date_created</td>";
                                         
                                                echo "</tr>";

                                                $sn++;
                                                
                                        }
                                    ?>
                                    </tbody>
                                </table>
                                <!-- End Table Bordered -->
                            </div>
                            <!-- End Table Responsive -->
                        </div>
                        <!-- End Panel Body -->
                    </div>
                    <!-- End Panel -->
                </div>
                </div>
            </div>

        </main>