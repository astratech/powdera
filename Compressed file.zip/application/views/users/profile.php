
<div class="page-content-wrapper animated fadeInRight">
<div class="page-content" style="padding-top:100px;">

                <div class="block" id="features">

                    <div class="container">

                    <?php 

                        if(isset($_SESSION['notification'])){

                            echo $_SESSION['notification'];

                        }

                    ?>

                        <div class="row">

                            <div class="col-md-6">

                                <div class="panel spanel panel-primary">

                                    <div class="panel-heading">

                                        <h3 class="panel-title text-white">

                                           Personal Details

                                        </h3>

                                    </div>

                                    <div class="panel-body table-responsive">

                                        <form class="form-horizontal push-5-t" action="" method="post">

                                    

                                            <div class="form-group">

                                                <label class="col-xs-12">Fullname</label>

                                                <div class="col-xs-12"> 

                                                    <input class="form-control" type="text" name="fullname" value="<?php echo $this->admin_model->get_user($this->username)->fullname; ?>" disabled>

                                                </div>

                                            </div>

                                            <div class="form-group">

                                                <label class="col-xs-12">Username</label>

                                                <div class="col-xs-12">

                                                    <input class="form-control"  type="text" name="username" value="<?php echo $this->username; ?>" disabled>

                                                </div>

                                            </div>

                                            <div class="form-group">

                                                <label class="col-xs-12">Email</label>

                                                <div class="col-xs-12">

                                                    <input class="form-control" type="email" name="email" value="<?php echo $this->admin_model->get_user($this->username)->email; ?>" disabled>

                                                </div>

                                            </div>

                                            <div class="form-group">

                                                <label class="col-xs-12">Mobile</label>

                                                <div class="col-xs-12">

                                                    <input class="form-control" type="text" name="mobile" value="<?php echo $this->admin_model->get_user($this->username)->mobile; ?>" disabled>

                                                </div>

                                            </div>

                                            

                                            <div class="form-group">

                                                <label class="col-xs-12">City</label>

                                                <div class="col-xs-12">

                                                    <input class="form-control" type="text" name="city" value="<?php echo $this->admin_model->get_user($this->username)->city; ?>" disabled>

                                                </div>

                                            </div>

                                           

                                            <div class="form-group">

                                                <div class="col-xs-12">

                                                    <!-- <input type="submit" id="sub-btn" class="btn btn-effect-ripple btn-success" name="reg_user" value="Update Profile"/> -->

                                                </div>

                                            </div>

                                         

                                        </form>

                                    </div>

                                </div>

                            </div>



                            <div class="col-md-6">

                                <div class="panel spanel panel-primary">

                                    <div class="panel-heading">

                                        <h3 class="panel-title text-white">

                                           Bank Details

                                        </h3>

                                    </div>

                                    <div class="panel-body table-responsive">

                                        <form class="form-horizontal push-5-t" action="" method="post">



                                            <div class="form-group">

                                                <P>NOTE: If you have pending transaction you can't edit your bank information.</P>

                                                <label class="col-xs-12">Bank</label>

                                                <div class="col-xs-12">

                                                    <select id="select1" name="bank_id" class="form-control" <?php echo $this->admin_model->does_user_have_pending_ph($this->username) ? 'disabled' : '' ?>>

                                                        <option value="<?php echo $this->admin_model->get_user($this->username)->bank_id; ?>"><?php echo $this->admin_model->get_user($this->username)->bank_name; ?></option>

                                                        <option value="">-------------------------------------------</option>

                                                        <?php 

                                                            foreach ($this->admin_model->get_banks()->result() as $r) {

                                                                echo "<option value='$r->id'>$r->name</option>";

                                                            }

                                                        ?>

                                                    </select>

                                                </div>

                                            </div> 



                                            <div class="form-group">

                                                <label class="col-xs-12">Account Type</label>

                                                <div class="col-xs-12">

                                                    <select name="account_type" class="form-control" style="" <?php echo $this->admin_model->does_user_have_pending_ph($this->username) ? 'disabled' : '' ?>>

                                                        <option value="<?php echo $this->admin_model->get_user($this->username)->account_type; ?>"><?php echo $this->admin_model->get_user($this->username)->account_type; ?></option>

                                                        <option value="">------------------</option>

                                                        <option value="savings">Savings</option>

                                                        <option value="current">Current</option>

                                                    </select>

                                                </div>

                                            </div> 

                                            <div class="form-group">

                                                <label class="col-xs-12">Account Name</label>

                                                <div class="col-xs-12">

                                                    <input class="form-control" type="text" name="account_name" value="<?php echo $this->admin_model->get_user($this->username)->account_name; ?>" style=""<?php echo $this->admin_model->does_user_have_pending_ph($this->username) ? 'disabled' : '' ?>>

                                                </div>

                                            </div>

                                            <div class="form-group">

                                                <label class="col-xs-12">Account Number</label>

                                                <div class="col-xs-12">

                                                    <input class="form-control" type="text" name="account_number" value="<?php echo $this->admin_model->get_user($this->username)->account_number; ?>" style="" <?php echo $this->admin_model->does_user_have_pending_ph($this->username) ? 'disabled' : '' ?>>

                                                </div>

                                            </div>

                                            <div class="form-group">

                                                <div class="col-xs-12">

                                                    <input type="submit" id="sub-btn" class="btn btn-effect-ripple btn-success" name="edit_bank" value="Update Bank Details" <?php echo $this->admin_model->does_user_have_pending_ph($this->username) ? 'disabled' : '' ?>/>

                                                </div>

                                            </div>

                                                 

                                        </form>

                                    </div>

                                </div>

                            </div>



                            <div class="col-md-6">

                                <div class="panel spanel panel-primary">

                                    <div class="panel-heading">

                                        <h3 class="panel-title text-white">

                                           Change Password

                                        </h3>

                                    </div>

                                    <div class="panel-body table-responsive">

                                        <form class="form-horizontal push-5-t" action="" method="post">

                                            <div class="form-group">

                                                <label class="col-xs-12">New Password</label>

                                                <div class="col-xs-12">

                                                    <input style="" class="form-control" type="password" id="password" name="password">

                                                </div>

                                            </div>

                                            <div class="form-group">

                                                <label class="col-xs-12">Retype New Password</label>

                                                <div class="col-xs-12">

                                                    <input style="" class="form-control" type="password" id="rpassword" name="rpassword">

                                                </div>

                                            </div>

                                            <div class="form-group">

                                                <div class="col-xs-12">

                                                    <input type="submit" id="sub-btn" class="btn btn-effect-ripple btn-success" name="edit_password" value="Change Password"/>

                                                </div>

                                            </div>

                                                 

                                        </form>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                    <!--/ .container-->

                    <div class="bg bg-color-neutral opacity-50"></div><!--/ .bg-->

                </div>

                <!--/ .block-->





                <div class="space"></div>



                <div class="container">

                    

                </div>

                <!--/ .container-->





            </div>
            </div>