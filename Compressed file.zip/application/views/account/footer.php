    
            <!--footer start-->
            <div id="footer" class="ui-footer">
                2017 &copy; 
            </div>
            <!--footer end-->

        </div>
        <!-- inject:js -->
        
        <script src="<?php echo $this->config->item('assets_url'); ?>/bower_components/jquery.nicescroll/dist/jquery.nicescroll.min.js"></script>
        <script src="<?php echo $this->config->item('assets_url'); ?>/bower_components/autosize/dist/autosize.min.js"></script>
        <!-- endinject -->

        <!--highcharts-->
        <script src="<?php echo $this->config->item('assets_url'); ?>/bower_components/highcharts/highcharts.js"></script>
        <script src="<?php echo $this->config->item('assets_url'); ?>/bower_components/highcharts/highcharts-more.js"></script>
        <script src="<?php echo $this->config->item('assets_url'); ?>/bower_components/highcharts/modules/exporting.js"></script>


        <!--sparkline-->
        <script src="<?php echo $this->config->item('assets_url'); ?>/bower_components/bower-jquery-sparkline/dist/jquery.sparkline.retina.js"></script>
        <script src="<?php echo $this->config->item('assets_url'); ?>/assets/js/init-sparkline.js"></script>


        <!--echarts-->
        <script type="text/javascript" src="<?php echo $this->config->item('assets_url'); ?>/assets/js/echarts/echarts-all-3.js"></script>

        <!--easypiechart-->
        <script src="<?php echo $this->config->item('assets_url'); ?>/assets/js/jquery-easy-pie-chart/jquery.easypiechart.js"></script>



        <!--horizontal-timeline-->
        <script src="<?php echo $this->config->item('assets_url'); ?>/assets/js/horizontal-timeline/js/jquery.mobile.custom.min.js"></script>
        <script src="<?php echo $this->config->item('assets_url'); ?>/assets/js/horizontal-timeline/js/main.js"></script>

        <!-- FOR TABLE -->
         <!--Data Table-->
        <script src="<?php echo $this->config->item('assets_url'); ?>/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo $this->config->item('assets_url'); ?>/bower_components/datatables-tabletools/js/dataTables.tableTools.js"></script>
        <script src="<?php echo $this->config->item('assets_url'); ?>/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
        <script src="<?php echo $this->config->item('assets_url'); ?>/bower_components/datatables-colvis/js/dataTables.colVis.js"></script>
        <script src="<?php echo $this->config->item('assets_url'); ?>/bower_components/datatables-responsive/js/dataTables.responsive.js"></script>
        <script src="<?php echo $this->config->item('assets_url'); ?>/bower_components/datatables-scroller/js/dataTables.scroller.js"></script>

        <!--init data tables-->
        <script src="<?php echo $this->config->item('assets_url'); ?>/assets/js/init-datatables.js"></script>

        

        <!-- Common Script   -->
        <script src="<?php echo $this->config->item('assets_url'); ?>/dist/js/main.js"></script>


        <script src="<?php echo $this->config->item('assets_url'); ?>/assets/js/modernizr-custom.js"></script>

    </body>
</html>
