<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Testimony extends CI_Controller {

    public function __construct(){

        parent::__construct();

        $url = $this->config->base_url();

        if(!isset($_SESSION['vervefunds_admin_logged'])){

            header("Location: $url"."admin/login");

            exit();

        }

    }



    public function index(){

        $url = $this->config->base_url();

        if(isset($_POST['search'])){

            $s = $_POST['search'];

            header("Location: $url"."admin/testimony?search=$s");

            exit();

        }



        //Ajax

        if($this->input->is_ajax_request()){

            if (isset($_POST['action']) AND $_POST['action'] == "delete"){

                $id = $_POST['id'];

                if($this->db->query("DELETE FROM testimony WHERE id='$id'")){

                    echo "1";

                    exit();

                }

                else{

                    echo "0";

                    exit();

                }

            }

            if (isset($_POST['action']) AND $_POST['action'] == "publish"){

                $id = $_POST['id'];

                if($this->db->query("UPDATE testimony SET is_published='1' WHERE id='$id'")){

                    echo "1";

                    exit();

                }
                else{

                    echo "0";

                    exit();

                }

            }

            if (isset($_POST['action']) AND $_POST['action'] == "unpublish"){

                $id = $_POST['id'];

                if($this->db->query("UPDATE testimony SET is_published='0' WHERE id='$id'")){

                    echo "1";

                    exit();

                }

                else{

                    echo "0";

                    exit();

                }

            }

        }

        $h_data['page_title'] = "admin testimony";

        $c_data = [];

        if(isset($_GET['search'])){

            $s = $_GET['search'];

            $c_data['list'] = $this->db->query("SELECT * FROM testimony WHERE (text LIKE '%$s%') OR (username LIKE '%$s%') OR (is_published LIKE '%$s%') ORDER BY id DESC");

        }

        else{

            $c_data['list'] = $this->db->query("SELECT * FROM testimony ORDER BY id DESC");

        }

        $this->load->view('admin/header', $h_data);

        $this->load->view('admin/testimony', $c_data);

        unset($_SESSION['notification']);

    }



    public function resolve($id=NULL){

        $url = $this->config->base_url();

        if(is_null($id)){

            header("Location: $url"."admin/report");

            exit();

        }



        $merge_id = $c_data['merge_id'] = $id;

        $report_id = $c_data['report_id'] = $this->admin_model->get_report($id)->id;



        if(isset($_POST['admin_send'])){

            $text = $this->input->post('text');



            if(empty($text)){

                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>

                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

                    <strong>ERROR: </strong> Fill thse empty fields

                  </div>";



                header("Location: $url"."admin/report/resolve/$merge_id");

                exit();

            }   



            if($this->db->insert('resolve', ['username'=>'admin', 'message'=>$text, 'report_id'=>$report_id])){

                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>

                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

                    <strong>SUCCESS: </strong> Message sent

                  </div>";



                header("Location: $url"."admin/report/resolve/$merge_id");

                exit();

            }

            else{

                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>

                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

                    <strong>ERROR: </strong>Unable to send

                  </div>";



                header("Location: $url"."admin/report/resolve/$merge_id");

                exit();

            }

        }

        

        $url = $this->config->base_url();   



        $h_data['page_title'] = 'Resolve';



        $c_data['list'] = $this->db->query("SELECT * FROM resolve WHERE report_id='$report_id' ORDER BY id DESC");

        $this->load->view('admin/header',$h_data);

        $this->load->view('admin/resolve',$c_data);

        unset($_SESSION['notification']);

    }

}

