<?php



defined('BASEPATH') OR exit('No direct script access allowed');







class Report extends CI_Controller {







	public function __construct(){



        parent::__construct();



        $url = $this->config->base_url();







        if(!isset($_SESSION['vervefunds_admin_logged'])){



       	 	header("Location: $url"."admin/login");



        	exit();



		}



   	}







	public function index(){



		$url = $this->config->base_url();







        if(isset($_POST['search'])){



            $s = $_POST['search'];







            header("Location: $url"."admin/bonus?search=$s");



            exit();



        }







        //Ajax



        if($this->input->is_ajax_request()){



            if (isset($_POST['action']) AND $_POST['action'] == "delete_report"){



                $id = $_POST['id'];



                if($this->db->query("DELETE FROM reports WHERE id='$id'")){



                    echo "1";



                    exit();



                }



                else{



                    echo "0";



                    exit();



                }



            }







            if (isset($_POST['action']) AND $_POST['action'] == "treat"){



                $id = $_POST['id'];



                if($this->db->query("UPDATE reports SET is_treated='1' WHERE id='$id'")){



                    echo "1";



                    exit();



                }



                else{



                    echo "0";



                    exit();



                }



            }



            if (isset($_POST['action']) AND $_POST['action'] == "untreat"){



                $id = $_POST['id'];



                if($this->db->query("UPDATE reports SET is_treated='0' WHERE id='$id'")){



                    echo "1";



                    exit();



                }



                else{



                    echo "0";



                    exit();



                }



            }



        }







		$h_data['page_title'] = "admin Report";







        $c_data = [];







        if(isset($_GET['search'])){



            $s = $_GET['search'];



            $c_data['list'] = $this->db->query("SELECT * FROM reports WHERE (merge_id LIKE '%$s%') OR (username LIKE '%$s%') ORDER BY id DESC");



        }



        else{



            $c_data['list'] = $this->db->query("SELECT * FROM reports ORDER BY id DESC");



        }







        $this->load->view('admin/header', $h_data);



		$this->load->view('admin/report', $c_data);







		unset($_SESSION['notification']);



	}



}



