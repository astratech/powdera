<?php

defined('BASEPATH') OR exit('No direct script access allowed');



class Xmerge extends CI_Controller {



	/**

	 * Index Page for this controller.

	 *

	 * Maps to the following URL

	 * 		http://example.com/index.php/welcome

	 *	- or -

	 * 		http://example.com/index.php/welcome/index

	 *	- or -

	 * Since this controller is set as the default controller in

	 * config/routes.php, it's displayed at http://example.com/

	 *

	 * So any other public methods not prefixed with an underscore will

	 * map to /index.php/welcome/<method_name>

	 * @see https://codeigniter.com/user_guide/general/urls.html

	 */

	public function index()

	{
		echo "";

	}



	public function all()

	{

		$this->load->view('users/header');

		$this->load->view('users/content');

		$this->load->view('users/sidebar');

		$this->load->view('users/footer');

	}


	public function up(){
		$q = $this->db->query("SELECT * FROM ph WHERE merged_20='1' ORDER BY id ASC");
		$t = 0;
		if($q->num_rows() > 0){
			foreach ($q->result() as $ph) {
				// update gh merged
			    // $this->db->query("UPDATE ph SET merged_20_date='2017-08-01 10:00:00' WHERE id='$ph->id'");
			    $t++;
			}
		}

		echo $t;
	}

	public function tin(){
		$q = $this->db->query("SELECT * FROM gh WHERE type='internal' ORDER BY id ASC");
		$t = 0;
		if($q->num_rows() > 0){
			foreach ($q->result() as $gh) {
				$q1 = $this->db->query("SELECT * FROM merge WHERE gh_id='$gh->id' AND is_confirmed='1' ORDER BY id ASC");
				foreach ($q->result() as $m) {
					$m1 = $m->amount;
				}

				$t = $m1 + $t;
					echo "$gh->username == $m->amount <br>";
			}
		}

		echo $t;
	}

	public function force20(){
		// if($this->admin_model->get_option("auto_merge")->value == 1){
			$q = $this->db->query("SELECT * FROM gh WHERE is_confirmed='0' AND hidden='0' AND locked='0' ORDER BY id ASC");
		    if($q->num_rows() > 0){
		        foreach ($q->result() as $gh) {
		            $gh_merge_amount = $this->admin_model->get_unpaid_gh_amount($gh->amount, $gh->id);
		            // echo "$gh->trans_num == $gh_merge_amount <br>";

		            if($gh_merge_amount > 0){

		            	do{
				            // get match
				            $sender_ph_id = $this->admin_model->get_sender_20($gh_merge_amount, $gh->username);
				            $date = date("Y-m-d H:i:s");

				            // echo $sender_ph_id;
				            // exit();
				            //if there is a merge
				            if(!is_null($sender_ph_id)){

				                //get  info
				                $ph_id =  $sender_ph_id;
				                $gh_id = $gh->id;

				                $ph_amount = $this->admin_model->get_ph($sender_ph_id)->amount;
				                $ph_merge_amount= $this->admin_model->get_unpaid_ph_amount($ph_amount, $ph_id);

				                // $gh_merge_amount = $this->admin_model->get_unpaid_gh_amount($gh->amount, $gh->id);

				                if($gh_merge_amount > 0 || $ph_merge_amount > 0){
				                    $ph_user = $this->admin_model->get_ph($ph_id)->username;
				                    $ph_trans = $this->admin_model->get_ph($ph_id)->trans_num;

				                    $gh_user = $this->admin_model->get_gh($gh_id)->username;
				                    $gh_trans = $this->admin_model->get_gh($gh_id)->trans_num;

				                    // echo "$ph_user / $ph_trans / $ph_merge_amount == $gh_user / $gh_trans / $gh_merge_amount<br/>";
				                    	$real_amount = (20/100) * $ph_amount;
				                        if($gh_merge_amount > $real_amount){

				                            if($ph_merge_amount > 1 && $gh_merge_amount > 1){
				                            	
				                                echo "$ph_user / $ph_trans / $real_amount == $gh_user / $gh_trans / $gh_merge_amount<br/>";
				                                // merge them
				                                $this->db->insert('merge', ["ph_id"=>$ph_id, "gh_id"=>$gh_id, "amount"=>$real_amount, "days"=>"24", "date_created"=>$date]);

				                                // update gh merged
				                                $this->db->query("UPDATE gh SET is_merge='1' WHERE id='$gh_id'");

				                                //update ph merged
				                                $this->db->query("UPDATE ph SET is_merge='1',merged_20='1',merged_20_date='$date' WHERE id='$ph_id'");

				                                $ph_number = $this->admin_model->get_user($this->admin_model->get_ph($ph_id)->username)->mobile;
				                                $gh_number = $this->admin_model->get_user($this->admin_model->get_gh($gh_id)->username)->mobile;

				                                $ph_msg = "Hello $ph_user, you have been merged to pay.";
				                                $gh_msg = "Hello you have been merged to get help. Please check ur dashboard.";

											  	// $this->admin_model->send_sms($ph_msg, $ph_number);
												// $this->admin_model->send_sms($gh_msg, $gh_number);
				                            }
				                            
				                        }
				                        else{
				                            
				                            
				                        }
				                    
				                }                
				            }
				            else{
				            	break;
				            }

				            $gh_merge_amount = $this->admin_model->get_unpaid_gh_amount($gh->amount, $gh->id);
				        }
				        while($gh_merge_amount > 0);
			        }
		            
		        }
				// echo "no more ph";
		    }
		    else{
		        echo "no more gh";
		        // $this->admin_model->send_sms("no more gh", "08117113634");
		        exit();
		    }
		// }

	    // $this->admin_model->send_sms("20% done", "08117113634"); 
	}

	public function force80(){
		// $this->admin_model->send_sms("80% done", "08117113634");
		// if($this->admin_model->get_option("auto_merge")->value == 1){
			$q = $this->db->query("SELECT * FROM gh WHERE is_confirmed='0' AND hidden='0' AND locked='0' ORDER BY id ASC");
		    if($q->num_rows() > 0){
		        foreach ($q->result() as $gh) {
		            $gh_merge_amount = $this->admin_model->get_unpaid_gh_amount($gh->amount, $gh->id);
		            // echo "$gh_merge_amount<br>";

		           	if($gh_merge_amount > 0){
		           		do{
				            // get match
				            $sender_ph_id = $this->admin_model->get_sender_80($gh_merge_amount, $gh->username);
				            $date = date("Y-m-d H:i:s");

				            //if there is a merge
				            if(!is_null($sender_ph_id)){

				                //get  info
				                $ph_id =  $sender_ph_id;
				                $gh_id = $gh->id;

				                $ph_amount = $this->admin_model->get_ph($sender_ph_id)->amount;
				                $ph_merge_amount= $this->admin_model->get_unpaid_ph_amount($ph_amount, $ph_id);

				                // $gh_merge_amount = $this->admin_model->get_unpaid_gh_amount($gh->amount, $gh->id);

				                if($gh_merge_amount > 0 || $ph_merge_amount > 0){
				                    $ph_user = $this->admin_model->get_ph($ph_id)->username;
				                    $ph_trans = $this->admin_model->get_ph($ph_id)->trans_num;

				                    $gh_user = $this->admin_model->get_gh($gh_id)->username;
				                    $gh_trans = $this->admin_model->get_gh($gh_id)->trans_num;

				                    // echo "$ph_user / $ph_trans / $ph_merge_amount == $gh_user / $gh_trans / $gh_merge_amount<br/>";
				                        if($gh_merge_amount > $ph_merge_amount ){
				                            if($ph_merge_amount > 1 && $gh_merge_amount > 1){
				                                echo "$ph_user / $ph_trans / $ph_merge_amount == $gh_user / $gh_trans / $gh_merge_amount<br/>";
				                                // merge them
				                                $this->db->insert('merge', ["ph_id"=>$ph_id, "gh_id"=>$gh_id, "amount"=>$ph_merge_amount, "days"=>"24", "date_created"=>$date]);

				                                // update gh merged
				                                $this->db->query("UPDATE gh SET is_merge='1' WHERE id='$gh_id'");

				                                //update ph merged
				                                $this->db->query("UPDATE ph SET is_merge='1',merged_20='1' WHERE id='$ph_id'");

				                                $ph_number = $this->admin_model->get_user($this->admin_model->get_ph($ph_id)->username)->mobile;
				                                $gh_number = $this->admin_model->get_user($this->admin_model->get_gh($gh_id)->username)->mobile;

				                                $ph_msg = "Hello $ph_user, you have been merged to pay.";
				                                $gh_msg = "Hello you have been merged to get help. Please check ur dashboard.";

											  	// $this->admin_model->send_sms($ph_msg, $ph_number);
												// $this->admin_model->send_sms($gh_msg, $gh_number);
				                            }
				                            
				                        }
				                        else{
				                            if($ph_merge_amount > 1 && $gh_merge_amount > 1){
				                                echo "$ph_user / $ph_trans / $ph_merge_amount == $gh_user / $gh_trans / $gh_merge_amount<br/>";
				                                $this->db->insert('merge', ["ph_id"=>$ph_id, "gh_id"=>$gh_id, "amount"=>$gh_merge_amount, "days"=>"24", "date_created"=>$date]);

				                                // update gh merged
				                                $this->db->query("UPDATE gh SET is_merge='1' WHERE id='$gh_id'");

				                                //update ph merged
				                                $this->db->query("UPDATE ph SET is_merge='1',merged_20='1' WHERE id='$ph_id'");

				                                $ph_number = $this->admin_model->get_user($this->admin_model->get_ph($ph_id)->username)->mobile;
				                                $gh_number = $this->admin_model->get_user($this->admin_model->get_gh($gh_id)->username)->mobile;

				                                $ph_msg = "Hello $ph_user, you have been merged to pay.";
				                                $gh_msg = "Hello you have been merged to get help. Please check ur dashboard.";

												// $this->admin_model->send_sms($ph_msg, $ph_number);
					                            // $this->admin_model->send_sms($gh_msg, $gh_number);
				                            }
				                            
				                        }
				                    
				                }                
				            }
				            else{
				            	break;
				            }

				            $gh_merge_amount = $this->admin_model->get_unpaid_gh_amount($gh->amount, $gh->id);
				        }
				        while($gh_merge_amount > 0);
			        }
		        }
		        echo "no more PH";;
		        exit();
		    }
		    else{
		        echo "no more gh";
		        exit();
		    }
		// }

	    
	}

	public function force_recycle(){
		// $this->admin_model->send_sms("80% done", "08117113634");
		// if($this->admin_model->get_option("auto_merge")->value == 1){
			$q = $this->db->query("SELECT * FROM gh WHERE is_confirmed='0' AND hidden='0' AND locked='0' ORDER BY id ASC");
		    if($q->num_rows() > 0){
		        foreach ($q->result() as $gh) {
		            $gh_merge_amount = $this->admin_model->get_unpaid_gh_amount($gh->amount, $gh->id);
		            // echo "$gh_merge_amount<br>";

		           	if($gh_merge_amount > 0){

			            // get match
			            $sender_ph_id = $this->admin_model->get_sender_recycle($gh_merge_amount, $gh->username);
			            $date = date("Y-m-d H:i:s");

			            //if there is a merge
			            if(!is_null($sender_ph_id)){

			                //get  info
			                $ph_id =  $sender_ph_id;
			                $gh_id = $gh->id;

			                $ph_amount = $this->admin_model->get_ph($sender_ph_id)->amount;
			                $ph_merge_amount= $this->admin_model->get_unpaid_ph_amount($ph_amount, $ph_id);

			                // $gh_merge_amount = $this->admin_model->get_unpaid_gh_amount($gh->amount, $gh->id);

			                if($gh_merge_amount > 0 || $ph_merge_amount > 0){
			                    $ph_user = $this->admin_model->get_ph($ph_id)->username;
			                    $ph_trans = $this->admin_model->get_ph($ph_id)->trans_num;

			                    $gh_user = $this->admin_model->get_gh($gh_id)->username;
			                    $gh_trans = $this->admin_model->get_gh($gh_id)->trans_num;

			                    // echo "$ph_user / $ph_trans / $ph_merge_amount == $gh_user / $gh_trans / $gh_merge_amount<br/>";
			                        if($gh_merge_amount > $ph_merge_amount ){
			                            if($ph_merge_amount > 1 && $gh_merge_amount > 1){
			                                echo "$ph_user / $ph_trans / $ph_merge_amount == $gh_user / $gh_trans / $gh_merge_amount<br/>";
			                                // merge them
			                                $this->db->insert('merge', ["ph_id"=>$ph_id, "gh_id"=>$gh_id, "amount"=>$ph_merge_amount, "days"=>"24", "date_created"=>$date]);

			                                // update gh merged
			                                $this->db->query("UPDATE gh SET is_merge='1' WHERE id='$gh_id'");

			                                //update ph merged
			                                $this->db->query("UPDATE ph SET is_merge='1',merged_20='1' WHERE id='$ph_id'");

			                                $ph_number = $this->admin_model->get_user($this->admin_model->get_ph($ph_id)->username)->mobile;
			                                $gh_number = $this->admin_model->get_user($this->admin_model->get_gh($gh_id)->username)->mobile;

			                                $ph_msg = "Hello $ph_user, you have been merged to pay your recycle.";
			                                $gh_msg = "Hello you have been merged to get help. Please check ur dashboard.";

										  	$this->admin_model->send_sms($ph_msg, $ph_number);
											$this->admin_model->send_sms($gh_msg, $gh_number);
			                            }
			                            
			                        }
			                        else{
			                            if($ph_merge_amount > 1 && $gh_merge_amount > 1){
			                                echo "$ph_user / $ph_trans / $ph_merge_amount == $gh_user / $gh_trans / $gh_merge_amount<br/>";
			                                $this->db->insert('merge', ["ph_id"=>$ph_id, "gh_id"=>$gh_id, "amount"=>$gh_merge_amount, "days"=>"24", "date_created"=>$date]);

			                                // update gh merged
			                                $this->db->query("UPDATE gh SET is_merge='1' WHERE id='$gh_id'");

			                                //update ph merged
			                                $this->db->query("UPDATE ph SET is_merge='1',merged_20='1' WHERE id='$ph_id'");

			                                $ph_number = $this->admin_model->get_user($this->admin_model->get_ph($ph_id)->username)->mobile;
			                                $gh_number = $this->admin_model->get_user($this->admin_model->get_gh($gh_id)->username)->mobile;

			                                $ph_msg = "Hello $ph_user, you have been merged to pay your recycle.";
			                                $gh_msg = "Hello you have been merged to get help. Please check ur dashboard.";

											$this->admin_model->send_sms($ph_msg, $ph_number);
				                            $this->admin_model->send_sms($gh_msg, $gh_number);
			                            }
			                            
			                        }
			                    
			                }                
			            }
			        }
		        }
		        echo "no more PH";;
		        exit();
		    }
		    else{
		        echo "no more gh";
		        exit();
		    }
		// }

	    
	}

	public function force_normal(){
		if($this->admin_model->get_option("auto_merge")->value == 1){
			$q = $this->db->query("SELECT * FROM gh WHERE is_confirmed='0' AND hidden='0' AND locked='0' ORDER BY id ASC");
		    if($q->num_rows() > 0){
		        foreach ($q->result() as $gh) {
		            $gh_merge_amount = $this->admin_model->get_unpaid_gh_amount($gh->amount, $gh->id);
		            $gh_amount = $gh->amount;
		            // echo "$gh_merge_amount<br>";

		           	if($gh_merge_amount > 0){

		           		do{
				            // get match
				            $sender_ph_id = $this->admin_model->get_sender_normal($gh_merge_amount, $gh->username);
				            $date = date("Y-m-d H:i:s");

				            //if there is a merge
				            if(!is_null($sender_ph_id)){

				                //get  info
				                $ph_id =  $sender_ph_id;
				                $gh_id = $gh->id;

				                $ph_amount = $this->admin_model->get_ph($sender_ph_id)->amount;
				                $ph_merge_amount= $this->admin_model->get_unpaid_ph_amount($ph_amount, $ph_id);

				                // $gh_merge_amount = $this->admin_model->get_unpaid_gh_amount($gh->amount, $gh->id);

				                if($gh_merge_amount > 0 || $ph_merge_amount > 0){
				                    $ph_user = $this->admin_model->get_ph($ph_id)->username;
				                    $ph_trans = $this->admin_model->get_ph($ph_id)->trans_num;

				                    $gh_user = $this->admin_model->get_gh($gh_id)->username;
				                    $gh_trans = $this->admin_model->get_gh($gh_id)->trans_num;

				                    // echo "$ph_user / $ph_trans / $ph_merge_amount == $gh_user / $gh_trans / $gh_merge_amount<br/>";
				                        if($gh_merge_amount > $ph_merge_amount ){
				                            if($ph_merge_amount > 1 && $gh_merge_amount > 1){
				                                echo "$ph_user / $ph_amount / $ph_trans / $ph_merge_amount == $gh_user / $gh_amount / $gh_trans / $gh_merge_amount<br/>";
				                                // merge them
				                                $this->db->insert('merge', ["ph_id"=>$ph_id, "gh_id"=>$gh_id, "amount"=>$ph_merge_amount, "days"=>"2", "date_created"=>$date]);

				                                // update gh merged
				                                $this->db->query("UPDATE gh SET is_merge='1' WHERE id='$gh_id'");

				                                //update ph merged
				                                $this->db->query("UPDATE ph SET is_merge='1',merged_20='1' WHERE id='$ph_id'");

				                                $ph_number = $this->admin_model->get_user($this->admin_model->get_ph($ph_id)->username)->mobile;
				                                $gh_number = $this->admin_model->get_user($this->admin_model->get_gh($gh_id)->username)->mobile;

				                                $ph_msg = "Hello $ph_user, you have been merged to pay $ph_merge_amount on VerveFunds.";
				                                $gh_msg = "Hello you have been merged to receive $ph_merge_amount on VerveFunds.";

											  	$this->admin_model->send_sms($ph_msg, $ph_number);
												$this->admin_model->send_sms($gh_msg, $gh_number);
				                            }
				                            
				                        }
				                        else{
				                            if($ph_merge_amount > 1 && $gh_merge_amount > 1){
				                                echo "$ph_user / $ph_amount / $ph_trans / $ph_merge_amount == $gh_user / $gh_amount / $gh_trans / $gh_merge_amount<br/>";
				                                $this->db->insert('merge', ["ph_id"=>$ph_id, "gh_id"=>$gh_id, "amount"=>$gh_merge_amount, "days"=>"2", "date_created"=>$date]);

				                                // update gh merged
				                                $this->db->query("UPDATE gh SET is_merge='1' WHERE id='$gh_id'");

				                                //update ph merged
				                                $this->db->query("UPDATE ph SET is_merge='1',merged_20='1' WHERE id='$ph_id'");

				                                $ph_number = $this->admin_model->get_user($this->admin_model->get_ph($ph_id)->username)->mobile;
				                                $gh_number = $this->admin_model->get_user($this->admin_model->get_gh($gh_id)->username)->mobile;

				                                $ph_msg = "Hello $ph_user, you have been merged to pay $ph_merge_amount on VerveFunds.";
				                                $gh_msg = "Hello you have been merged to receive $ph_merge_amount on VerveFunds.";

												$this->admin_model->send_sms($ph_msg, $ph_number);
					                            $this->admin_model->send_sms($gh_msg, $gh_number);
				                            }
				                            
				                        }
				                    
				                }                
				            }
				            else{
				            	break;
				            }

				            $gh_merge_amount = $this->admin_model->get_unpaid_gh_amount($gh->amount, $gh->id);
				        }
				        while($gh_merge_amount > 0);
			        }
		        }
		        echo "no more PH";;
		        exit();
		    }
		    else{
		        echo "no more gh";
		        exit();
		    }
		}
		else{
			echo "auto_merge is off";
		}
	}


	public function force_normal_test(){

		$q = $this->db->query("SELECT * FROM gh WHERE is_confirmed='0' AND hidden='0' AND locked='0' ORDER BY id ASC");
	    if($q->num_rows() > 0){
	        foreach ($q->result() as $gh) {
	            $gh_merge_amount = $this->admin_model->get_unpaid_gh_amount($gh->amount, $gh->id);
	            $gh_amount = $gh->amount;
	            // echo "$gh_merge_amount<br>";

	           	if($gh_merge_amount > 0){

	           		do{
			            // get match
			            $sender_ph_id = $this->admin_model->get_sender_normal($gh_merge_amount, $gh->username);
			            $date = date("Y-m-d H:i:s");

			            //if there is a merge
			            if(!is_null($sender_ph_id)){

			                //get  info
			                $ph_id =  $sender_ph_id;
			                $gh_id = $gh->id;

			                $ph_amount = $this->admin_model->get_ph($sender_ph_id)->amount;
			                $ph_merge_amount= $this->admin_model->get_unpaid_ph_amount($ph_amount, $ph_id);

			                // $gh_merge_amount = $this->admin_model->get_unpaid_gh_amount($gh->amount, $gh->id);

			                if($gh_merge_amount > 0 || $ph_merge_amount > 0){
			                    $ph_user = $this->admin_model->get_ph($ph_id)->username;
			                    $ph_trans = $this->admin_model->get_ph($ph_id)->trans_num;

			                    $gh_user = $this->admin_model->get_gh($gh_id)->username;
			                    $gh_trans = $this->admin_model->get_gh($gh_id)->trans_num;

			                    // echo "$ph_user / $ph_trans / $ph_merge_amount == $gh_user / $gh_trans / $gh_merge_amount<br/>";
			                        if($gh_merge_amount > $ph_merge_amount ){
			                            if($ph_merge_amount > 1 && $gh_merge_amount > 1){
			                                echo "$ph_user / $ph_amount / $ph_trans / $ph_merge_amount == $gh_user / $gh_amount / $gh_trans / $gh_merge_amount<br/>";
			                                // merge them
			                                $this->db->insert('merge', ["ph_id"=>$ph_id, "gh_id"=>$gh_id, "amount"=>$ph_merge_amount, "days"=>"12", "date_created"=>$date]);

			                                // update gh merged
			                                $this->db->query("UPDATE gh SET is_merge='1' WHERE id='$gh_id'");

			                                //update ph merged
			                                $this->db->query("UPDATE ph SET is_merge='1',merged_20='1' WHERE id='$ph_id'");

			                                $ph_number = $this->admin_model->get_user($this->admin_model->get_ph($ph_id)->username)->mobile;
			                                $gh_number = $this->admin_model->get_user($this->admin_model->get_gh($gh_id)->username)->mobile;

			                                $ph_msg = "Hello $ph_user, you have been merged to pay.";
			                                $gh_msg = "Hello you have been merged to get help. Please check ur dashboard.";

										 //  	$this->admin_model->send_sms($ph_msg, $ph_number);
											// $this->admin_model->send_sms($gh_msg, $gh_number);
			                            }
			                            
			                        }
			                        else{
			                            if($ph_merge_amount > 1 && $gh_merge_amount > 1){
			                                echo "$ph_user / $ph_amount / $ph_trans / $ph_merge_amount == $gh_user / $gh_amount / $gh_trans / $gh_merge_amount<br/>";
			                                $this->db->insert('merge', ["ph_id"=>$ph_id, "gh_id"=>$gh_id, "amount"=>$gh_merge_amount, "days"=>"12", "date_created"=>$date]);

			                                // update gh merged
			                                $this->db->query("UPDATE gh SET is_merge='1' WHERE id='$gh_id'");

			                                //update ph merged
			                                $this->db->query("UPDATE ph SET is_merge='1',merged_20='1' WHERE id='$ph_id'");

			                                $ph_number = $this->admin_model->get_user($this->admin_model->get_ph($ph_id)->username)->mobile;
			                                $gh_number = $this->admin_model->get_user($this->admin_model->get_gh($gh_id)->username)->mobile;

			                                $ph_msg = "Hello $ph_user, you have been merged to pay.";
			                                $gh_msg = "Hello you have been merged to get help. Please check ur dashboard.";

											// $this->admin_model->send_sms($ph_msg, $ph_number);
				       //                      $this->admin_model->send_sms($gh_msg, $gh_number);
			                            }
			                            
			                        }
			                    
			                }                
			            }
			            $gh_merge_amount = $this->admin_model->get_unpaid_gh_amount($gh->amount, $gh->id);
			        }
			        while($gh_merge_amount > 0);
		        }
	        }
	        echo "no more PH";;
	        exit();
	    }
	    else{
	        echo "no more gh";
	        exit();
	    }
	}

	public function ph_80(){
		$q = $this->db->query("SELECT * FROM ph WHERE is_confirmed='0' AND hidden='0' AND is_recycle='0' AND merged_20='1' AND blocked='0' ORDER BY id ASC");
		$t= 0;
        if($q->num_rows() > 0){
            $recipent_id = null;
            foreach ($q->result() as $r) {

                if($this->admin_model->is_20_confirmed($r->id)){
                	
                    $a_left = $this->admin_model->get_unpaid_ph_amount($r->amount, $r->id);
                    // echo "$day_20 -- $r->trans_num == $a_left<br>";
                    $d1 =  date('Y-m-d H:i:s', strtotime($r->merged_20_date. ' + 2 days'));
                    $d2 = $this->admin_model->get_date_diff($d1, date('Y-m-d H:i:s'))->hours;

                    
                    if($a_left > 0){
                    	echo "$d2 == $r->trans_num == $a_left<br>";
                    	$t = $t + $a_left;
                    }
                    
                    // if($d2 <= 39){
                    // 	$t = $t + $a_left;
                    
	                   //  if($a_left > 0){
	                   //      echo "$d2 == $r->trans_num == $a_left<br>";
	                   //  }
                    // }
                    // else{
                    // 	// echo $d2;
                    // }
                    
                }
                
            }
        }

        echo "total = $t";
        
	}

	public function ph_20(){
		$q = $this->db->query("SELECT * FROM ph WHERE is_confirmed='0' AND is_merge='0' AND hidden='0' AND is_recycle='0' AND merged_20='0' ORDER BY id ASC");
		$t = 0;
        if($q->num_rows() > 0){
            $recipent_id = null;
            foreach ($q->result() as $r) {
                $a_left = (20/100) * $r->amount;
                echo "$r->trans_num == $a_left <br>";
                $t = $t + $a_left;

                $t++;
                
            }
        }
 
        echo "total = $t";
	}


	public function list_gh_left(){
		$q = $this->db->query("SELECT * FROM gh WHERE is_confirmed='0' AND hidden='0' AND locked='0' ORDER BY id ASC");
		$t= 0;
        if($q->num_rows() > 0){
            $recipent_id = null;
            foreach ($q->result() as $r) {
            	$a_left = $this->admin_model->get_unpaid_gh_amount($r->amount, $r->id);
                if($a_left > 0){
                	
                    
                    echo "$r->id :: $r->trans_num == $r->amount == $a_left<br>";
                    $t = $a_left + $t;
                }
                
            }
        }

        echo "total = $t";
        
	}

	public function list_ph_left(){
		$q = $this->db->query("SELECT * FROM ph WHERE is_confirmed='0' AND hidden='0' ORDER BY id ASC");
		$t= 0;
        if($q->num_rows() > 0){
            $recipent_id = null;
            foreach ($q->result() as $r) {
            		$a_left = $this->admin_model->get_unpaid_ph_amount($r->amount, $r->id);
                	if($a_left > 0){
                		
	                    echo "$r->id :: $r->trans_num == $r->amount == $a_left<br>";
	                    $t = $a_left + $t;
                	}
                    
                
            }
        }

        echo "total = $t";
        
	}


}
