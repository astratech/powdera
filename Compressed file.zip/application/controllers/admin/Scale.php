<?php



defined('BASEPATH') OR exit('No direct script access allowed');







class Scale extends CI_Controller {







	public function __construct(){



        parent::__construct();



        $url = $this->config->base_url();







        if(!isset($_SESSION['vervefunds_admin_logged'])){



       	 	header("Location: $url"."admin/login");



        	exit();



		}



   	}







	public function ph(){



		$url = $this->config->base_url();







        if(isset($_POST['scale'])){







            $ph_trans_num = $this->input->post("ph_trans_num");







            if(empty($ph_trans_num)){



                //set notification session



                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>



                  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>



                  <strong>ERROR: </strong> Fill the empty fields



                </div>";







                header("Location: $url"."admin/scale/ph");



                exit();



            }







            header("Location: $url"."admin/scale/ph?trans_num=$ph_trans_num");



            exit();







        } 







        //Ajax



        if($this->input->is_ajax_request()){



        }







		$h_data['page_title'] = "PH Scale - admin";







        $c_data = [];







        if(isset($_GET['trans_num'])){



            $t = $_GET['trans_num'];



            $c_data['ph_id'] = $ph_id = $this->admin_model->get_ph_id_by_trans_num($t);



            $c_data['list'] = $this->db->query("SELECT * FROM merge WHERE ph_id='$ph_id'");



            $c_data['list_err'] = ""; 



        }



        else{



            $c_data['ph_id'] = "";



            $c_data['list_err'] = "yes"; 



        }







        $this->load->view('admin/header', $h_data);



		$this->load->view('admin/ph_scale', $c_data);







		unset($_SESSION['notification']);



	}



    public function gh(){



        $url = $this->config->base_url();







        if(isset($_POST['scale'])){







            $gh_trans_num = $this->input->post("gh_trans_num");







            if(empty($gh_trans_num)){



                //set notification session



                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>



                  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>



                  <strong>ERROR: </strong> Fill the empty fields



                </div>";







                header("Location: $url"."admin/scale/gh");



                exit();



            }







            header("Location: $url"."admin/scale/gh?trans_num=$gh_trans_num");



            exit();







        } 







        //Ajax



        if($this->input->is_ajax_request()){



        }







        $h_data['page_title'] = "GH Scale - admin";



        $c_data = [];





        if(isset($_GET['trans_num'])){



            $t = $_GET['trans_num'];



            $c_data['gh_id'] = $gh_id = $this->admin_model->get_gh_id_by_trans_num($t);



            $c_data['list'] = $this->db->query("SELECT * FROM merge WHERE gh_id='$gh_id'");



            $c_data['list_err'] = ""; 



        }



        else{



            $c_data['gh_id'] = "";



            $c_data['list_err'] = "yes"; 



        }







        $this->load->view('admin/header', $h_data);



        $this->load->view('admin/gh_scale', $c_data);







        unset($_SESSION['notification']);



    }



}



