<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Gh extends CI_Controller {

	public function __construct(){

        parent::__construct();

        $url = $this->config->base_url();

        if(!isset($_SESSION['vervefunds_admin_logged'])){

       	 	header("Location: $url"."admin/login");

        	exit();

		}

   	}

	public function index(){

		$url = $this->config->base_url();

        if(isset($_POST['search'])){

            $s = $_POST['search'];

            header("Location: $url"."admin/gh?search=$s");

            exit();

        }



        if(isset($_POST['reg_gh'])){

            $username = $this->input->post('username');

            $plan = "normal";

            $amount = $this->input->post('amount');

            $ph_id = "0";


            $trans_num = strtoupper($this->admin_model->gen_token());
            $date = date("Y-m-d H:m:i");

            if($this->db->insert('gh', ['plan'=>$plan, 'username'=>$username, 'amount'=>$amount, 'ph_id'=>$ph_id, 'trans_num'=>$trans_num, 'type'=>'internal', 'date_created'=>$date])){

                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>

                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

                                <strong>SUCCESS: </strong> Operation successfull

                            </div>";

                    header("Location: $url"."admin/gh");

                    exit();

            }

            else{

                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>

                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

                                <strong></strong> Error

                            </div>";

                    header("Location: $url"."admin/gh");

                    exit();

            }

        }



        if(isset($_POST['reset_gh'])){

            $username = $this->input->post('username');

            $amount = $this->input->post('amount');

            if($this->db->query("UPDATE gh SET counter='0' WHERE username='$username' AND amount='$amount'")){

                 $_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>

                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

                                <strong></strong> Counter Reset

                            </div>";

            }

            else{

                 $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>

                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

                                <strong></strong> Error : cant reset

                            </div>";

            }

        }



        //Ajax

        if($this->input->is_ajax_request()){

            if (isset($_POST['action']) AND $_POST['action'] == "delete_gh"){

                $id = $_POST['gh_id'];

                if($this->db->query("DELETE FROM gh WHERE id='$id'")){

                    echo "1";

                    exit();

                }

                else{

                    echo "0";

                    exit();

                }

            }

            if (isset($_POST['action']) AND $_POST['action'] == "confirm_gh"){

                $id = $_POST['gh_id'];

                if($this->db->query("UPDATE gh SET is_confirmed='1' WHERE id='$id'")){

                    echo "1";

                    exit();

                }

                else{

                    echo "0";

                    exit();

                }

            }



            if (isset($_POST['action']) AND $_POST['action'] == "unconfirm_gh"){

                $id = $_POST['gh_id'];

                if($this->db->query("UPDATE gh SET is_confirmed='0' WHERE id='$id'")){

                    echo "1";

                    exit();

                }

                else{

                    echo "0";

                    exit();

                }

            }



            if (isset($_POST['action']) AND $_POST['action'] == "lock_gh"){

                $id = $_POST['gh_id'];

                if($this->db->query("UPDATE gh SET locked='1' WHERE id='$id'")){

                    echo "1";

                    exit();

                }

                else{

                    echo "0";

                    exit();

                }

            }



            if (isset($_POST['action']) AND $_POST['action'] == "unlock_gh"){

                $id = $_POST['gh_id'];

                if($this->db->query("UPDATE gh SET locked='0' WHERE id='$id'")){

                    echo "1";

                    exit();

                }

                else{

                    echo "0";

                    exit();

                }

            }



            if (isset($_POST['action']) AND $_POST['action'] == "merge_gh"){

                $id = $_POST['gh_id'];

                if($this->db->query("UPDATE gh SET is_merge='1' WHERE id='$id'")){

                    echo "1";

                    exit();

                }

                else{

                    echo "0";

                    exit();

                }

            }



            if (isset($_POST['action']) AND $_POST['action'] == "unmerge_gh"){

                $id = $_POST['gh_id'];

                if($this->db->query("UPDATE gh SET is_merge='0' WHERE id='$id'")){

                    echo "1";

                    exit();

                }

                else{

                    echo "0";

                    exit();

                }

            }

        }

        

		$h_data['page_title'] = "admin GH";

        $c_data = [];

        if(isset($_GET['search'])){

            $s = $_GET['search'];

            $c_data['list'] = $this->db->query("SELECT * FROM gh WHERE ((trans_num LIKE '%$s%') OR (username LIKE '%$s%') OR (amount LIKE '%$s%') OR (type LIKE '%$s%')) AND hidden='0' ORDER BY id DESC");

        }

        else{

            $c_data['list'] = $this->db->query("SELECT * FROM gh WHERE hidden='0' ORDER BY id DESC");

        }

        $this->load->view('admin/header', $h_data);

		$this->load->view('admin/gh', $c_data);

		unset($_SESSION['notification']);

	}

}

