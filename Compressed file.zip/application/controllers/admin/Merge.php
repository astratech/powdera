<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Merge extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $url = $this->config->base_url();

        if(!isset($_SESSION['vervefunds_admin_logged'])){
            header("Location: $url"."admin/login");
            exit();
        }
    }

    public function index(){
        $url = $this->config->base_url();


        if(isset($_POST['search'])){
            $s = $_POST['search'];

            header("Location: $url"."admin/merge?search=$s");
            exit();
        }

        if(isset($_POST['reg_merge'])){

            $amount = $this->input->post("amount");
            $ph_id = $this->input->post("ph_id");
            $gh_id = $this->input->post("gh_id");
            $days = $this->input->post("days");
            $date = date("Y-m-d H:m:i");

            if(empty($amount) || empty($ph_id) || empty($gh_id) || empty($days)){
                //set notification session
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Fill the empty fields
                            </div>";

                //redirect to avoid form resubmission
                $url = $this->config->base_url();
                header("Location: $url"."admin/merge");
                exit();
            }

            if($this->db->insert('merge', ['ph_id'=>$ph_id, 'gh_id'=>$gh_id, 'amount'=>$amount, 'days'=>$days, 'date_created'=>$date])){
                $this->db->query("UPDATE ph SET is_merge='1' WHERE id='$ph_id'");
                $this->db->query("UPDATE gh SET is_merge='1' WHERE id='$gh_id'");

                $ph_number = $this->admin_model->get_user($this->admin_model->get_ph($ph_id)->username)->mobile;
                $gh_number = $this->admin_model->get_user($this->admin_model->get_gh($gh_id)->username)->mobile;

                $ph_username = $this->admin_model->get_ph($ph_id)->username;
                $gh_username = $this->admin_model->get_gh($gh_id)->username;

                $ph_msg = "Hello $ph_username, you have been merged to pay. Please check ur dashboard. ";
                $gh_msg = "Hello $gh_username, you have been merged to receive. Please check ur dashboard. ";

                $this->admin_model->send_sms($ph_msg, $ph_number);
                $this->admin_model->send_sms($gh_msg, $gh_number);

                $_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
                            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                            <strong>SUCCESS: </strong> Request Processed
                        </div>";

                $url = $this->config->base_url();
                header("Location: $url"."admin/merge");
                exit();
            }
            else{
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Request Failed, Try Again.
                            </div>";

                //redirect to avoid form resubmission
                $url = $this->config->base_url();
                header("Location: $url"."admin/merge");
                exit();

            }
        }

        //Ajax
        if($this->input->is_ajax_request()){

            if (isset($_POST['action']) AND $_POST['action'] == "delete_merge") {
                $id = $_POST['merge_id'];
                $ph_id = $_POST['ph_id'];
                $gh_id = $_POST['gh_id'];

                $this->db->trans_begin();

                // delete merge
                $this->db->query("DELETE FROM merge WHERE id='$id'");

                //update gh is_merge
                // $this->db->query("UPDATE gh SET is_merge='0' WHERE id='$gh_id'");

                if ($this->db->trans_status() === FALSE){
                    $this->db->trans_rollback();
                    echo "0";
                    exit();
                }
                else{
                    $this->db->trans_commit();
                    echo "1";
                    exit();
                }
                  
            }

            elseif (isset($_POST['action']) AND $_POST['action'] == "confirm_merge") {
                $id = $_POST['merge_id'];

                $this->db->trans_begin();

                //update gh is_merge
                $this->db->query("UPDATE merge SET is_confirmed='1' WHERE id='$id'");

                if ($this->db->trans_status() === FALSE){
                    $this->db->trans_rollback();
                    echo "0";
                    exit();
                }
                else{
                    $this->db->trans_commit();
                    echo "1";
                    exit();
                }
                  
            }

            elseif (isset($_POST['action']) AND $_POST['action'] == "unconfirm_merge") {
                $id = $_POST['merge_id'];
                
                $this->db->trans_begin();

                //update gh is_merge
                $this->db->query("UPDATE merge SET is_confirmed='0' WHERE id='$id'");

                if ($this->db->trans_status() === FALSE){
                    $this->db->trans_rollback();
                    echo "0";
                    exit();
                }
                else{
                    $this->db->trans_commit();
                    echo "1";
                    exit();
                }
                  
            }

            elseif (isset($_POST['action']) AND $_POST['action'] == "block_merge") {
                $id = $_POST['merge_id'];
                
                $this->db->trans_begin();

                //update merge
                $this->db->query("UPDATE merge SET is_blocked='1' WHERE id='$id'");

                if ($this->db->trans_status() === FALSE){
                    $this->db->trans_rollback();
                    echo "0";
                    exit();
                }
                else{
                    $this->db->trans_commit();
                    echo "1";
                    exit();
                }
                  
            }

            elseif (isset($_POST['action']) AND $_POST['action'] == "unblock_merge") {
                $id = $_POST['merge_id'];
                
                $this->db->trans_begin();

                //update gh is_merge
                $this->db->query("UPDATE merge SET is_blocked='0' WHERE id='$id'");

                if ($this->db->trans_status() === FALSE){
                    $this->db->trans_rollback();
                    echo "0";
                    exit();
                }
                else{
                    $this->db->trans_commit();
                    echo "1";
                    exit();
                }
                  
            }

            elseif (isset($_POST['action']) AND $_POST['action'] == "onauto"){
                if($this->db->query("UPDATE options SET value='1' WHERE name='auto_merge'")){
                    echo "1";
                    exit();
                }
                    else{
                    echo "0";
                    exit();
                }
            }

            elseif (isset($_POST['action']) AND $_POST['action'] == "offauto"){
                if($this->db->query("UPDATE options SET value='0' WHERE name='auto_merge'")){
                    echo "1";
                    exit();
                }
                    else{
                    echo "0";
                    exit();
                }
            }

            elseif (isset($_POST['action']) AND $_POST['action'] == "force_merge"){
		        $q = $this->db->query("SELECT * FROM gh WHERE is_confirmed='0' AND hidden='0' AND locked='0' ORDER BY id ASC");
		        if($q->num_rows() > 0){
		            foreach ($q->result() as $gh) {
		                $gh_merge_amount = $this->admin_model->get_unpaid_gh_amount($gh->amount, $gh->id);

		                // get match
		                $sender_ph_id = $this->admin_model->get_sender($gh_merge_amount, $gh->username);
		                $date = date("Y-m-d H:i:s");

		                //if there is a merge
		                if(!is_null($sender_ph_id)){

		                    //get  info
		                    $ph_id =  $sender_ph_id;
		                    $gh_id = $gh->id;

		                    $ph_amount = $this->admin_model->get_ph($sender_ph_id)->amount;
		                    $ph_merge_amount= $this->admin_model->get_unpaid_ph_amount($ph_amount, $ph_id);

		                    $gh_merge_amount = $this->admin_model->get_unpaid_gh_amount($gh->amount, $gh->id);

		                    if($gh_merge_amount > 1 || $ph_merge_amount > 1){
		                        $ph_user = $this->admin_model->get_ph($ph_id)->username;
		                        $ph_trans = $this->admin_model->get_ph($ph_id)->trans_num;

		                        $gh_user = $this->admin_model->get_gh($gh_id)->username;
		                        $gh_trans = $this->admin_model->get_gh($gh_id)->trans_num;

		                        // echo "$ph_user / $ph_trans / $ph_merge_amount == $gh_user / $gh_trans / $gh_merge_amount<br/>";
		                            if($gh_merge_amount > $ph_merge_amount ){
		                                if($ph_merge_amount > 1 && $gh_merge_amount > 1){
		                                    //echo "$ph_user / $ph_trans / $ph_merge_amount == $gh_user / $gh_trans / $gh_merge_amount<br/>";
		                                    // merge them
		                                    $this->db->insert('merge', ["ph_id"=>$ph_id, "gh_id"=>$gh_id, "amount"=>$ph_merge_amount, "days"=>"12", "date_created"=>$date]);

		                                    // update gh merged
		                                    $this->db->query("UPDATE gh SET is_merge='1' WHERE id='$gh_id'");

		                                    //update ph merged
		                                    $this->db->query("UPDATE ph SET is_merge='1' WHERE id='$ph_id'");

		                                    $ph_number = $this->admin_model->get_user($this->admin_model->get_ph($ph_id)->username)->mobile;
		                                    $gh_number = $this->admin_model->get_user($this->admin_model->get_gh($gh_id)->username)->mobile;

		                                    $ph_msg = "You have been merged to pay N$ph_merge_amount . Login and Redeem your pledge. Happy Earnings";
		                                    $gh_msg = "You have been merged to receive N$ph_merge_amount . Login and call your downliner. Happy Earnings";

		                                    $this->admin_model->send_sms($ph_msg, $ph_number);
		                                    $this->admin_model->send_sms($gh_msg, $gh_number);
		                                }
		                                
		                            }
		                            else{
		                                if($ph_merge_amount > 1 && $gh_merge_amount > 1){
		                                    //echo "$ph_user / $ph_trans / $ph_merge_amount == $gh_user / $gh_trans / $gh_merge_amount<br/>";
		                                    $this->db->insert('merge', ["ph_id"=>$ph_id, "gh_id"=>$gh_id, "amount"=>$gh_merge_amount, "days"=>"12", "date_created"=>$date]);

		                                    // update gh merged
		                                    $this->db->query("UPDATE gh SET is_merge='1' WHERE id='$gh_id'");

		                                    //update ph merged
		                                    $this->db->query("UPDATE ph SET is_merge='1' WHERE id='$ph_id'");

		                                    $ph_number = $this->admin_model->get_user($this->admin_model->get_ph($ph_id)->username)->mobile;
		                                    $gh_number = $this->admin_model->get_user($this->admin_model->get_gh($gh_id)->username)->mobile;

		                                    $ph_msg = "You have been merged to pay N$gh_merge_amount . Login and Redeem your pledge. Happy Earnings";
		                                    $gh_msg = "You have been merged to receive N$gh_merge_amount . Login and call your downliner. Happy Earnings";

		                                    $this->admin_model->send_sms($ph_msg, $ph_number);
		                                    $this->admin_model->send_sms($gh_msg, $gh_number);
		                                }
		                                
		                            }
		                        
		                    }                
		                }
		            }
		            echo "1";
		            exit();
		        }
		        else{
		            echo "no_gh";
		            exit();
		        }
                
            }

            elseif (isset($_POST['action']) AND $_POST['action'] == "purge"){
                $merge_id = $_POST['merge_id'];
                $ph_id = $this->admin_model->get_merge($merge_id)->ph_id;
                $gh_id = $this->admin_model->get_merge($merge_id)->gh_id;
                $ph_username = $this->admin_model->get_ph($ph_id)->username;

                // if user has paid
                $q = $this->db->query("SELECT * FROM merge WHERE ph_id='$ph_id' AND is_confirmed='1'");
                if($q->num_rows() > 0){
                    echo "paid";
                    exit(); 
                }


                if($this->admin_model->is_ph_in_merge_list($ph_id)){
                    //delete ph
                    $this->db->query("DELETE FROM ph WHERE id='$ph_id'");
                }

                //get all gh merged to that ph
                $q = $this->db->query("SELECT * FROM merge WHERE ph_id='$ph_id' AND is_confirmed='0'");
                if($q->num_rows() > 0){
                    foreach ($q->result() as $m) {

                        $q1 = $this->db->query("SELECT * FROM merge WHERE gh_id='$m->gh_id'");
                        if($q1->num_rows() == 1){
                            // update gh
                            $this->db->query("UPDATE gh SET is_merge='0' WHERE id='$m->gh_id'");
                        }

                        //delete merge
                        $this->db->query("DELETE FROM merge WHERE id='$m->id'");
                    }
                }
                
                echo "1";
                exit(); 
                
            } 
            elseif (isset($_POST['action']) AND $_POST['action'] == "delete_all_merge") {
               $this->db->query("TRUNCATE TABLE merge");
               echo '1';
            }
            else{
                echo "0";
                exit();
            }
        }

        $h_data['page_title'] = "Merge - admin";

        $c_data = [];

        if(isset($_GET['search'])){
            $s = $_GET['search'];
            $c_data['list'] = $this->db->query("SELECT * FROM merge WHERE ((ph_id LIKE '%$s%') OR (gh_id LIKE '%$s%') OR (amount LIKE '%$s%')) AND hidden='0' ORDER BY id DESC");
        }
        else{
            $c_data['list'] = $this->db->query("SELECT * FROM merge WHERE hidden='0' ORDER BY id DESC");
        }

        $this->load->view('admin/header', $h_data);
        $this->load->view('admin/merge', $c_data);

        unset($_SESSION['notification']);
    }
}
