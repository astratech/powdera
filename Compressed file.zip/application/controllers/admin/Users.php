<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Users extends CI_Controller {
	public function __construct(){
        parent::__construct();
        $url = $this->config->base_url();
        if(!isset($_SESSION['vervefunds_admin_logged'])){
       	 	header("Location: $url"."admin/login");
        	exit();
		}
   	}

	public function index(){
		$url = $this->config->base_url();
        if(isset($_POST['search'])){
            $s = $_POST['search'];
            header("Location: $url"."admin/users?search=$s");
            exit();
        }

        //Ajax
        if($this->input->is_ajax_request()){
            if (isset($_POST['action']) AND $_POST['action'] == "delete_user"){
                $id = $_POST['user_id'];
                if($this->db->query("DELETE FROM users WHERE id='$id'")){
                    echo "1";
                    exit();
                }
                else{
                    echo "0";
                    exit();
                }
            }
            if (isset($_POST['action']) AND $_POST['action'] == "block_user"){
                $id = $_POST['user_id'];
                if($this->db->query("UPDATE users SET is_blocked='1' WHERE id='$id'")){
                    echo "1";
                    exit();
                }
                else{
                    echo "0";
                    exit();
                }
            }

            if (isset($_POST['action']) AND $_POST['action'] == "unblock_user"){
                $id = $_POST['user_id'];
                if($this->db->query("UPDATE users SET is_blocked='0' WHERE id='$id'")){
                    echo "1";
                    exit();
                }
                else{
                    echo "0";
                    exit();
                }
            }

            if (isset($_POST['action']) AND $_POST['action'] == "do_internal"){
                $id = $_POST['user_id'];
                if($this->db->query("UPDATE users SET type='internal' WHERE id='$id'")){
                    echo "1";
                    exit();
                }
                else{
                    echo "0";
                    exit();
                }
            }
            
            if (isset($_POST['action']) AND $_POST['action'] == "undo_internal"){
                $id = $_POST['user_id'];
                if($this->db->query("UPDATE users SET type='normal' WHERE id='$id'")){
                    echo "1";
                    exit();
                }
                else{
                    echo "0";
                    exit();
                }
            }

            if (isset($_POST['action']) AND $_POST['action'] == "do_verify"){
                $id = $_POST['user_id'];
                if($this->db->query("UPDATE users SET is_verified='1' WHERE id='$id'")){
                    echo "1";
                    exit();
                }
                else{
                    echo "0";
                    exit();
                }
            }
            
            if (isset($_POST['action']) AND $_POST['action'] == "undo_verify"){
                $id = $_POST['user_id'];
                if($this->db->query("UPDATE users SET is_verified='0' WHERE id='$id'")){
                    echo "1";
                    exit();
                }
                else{
                    echo "0";
                    exit();
                }
            }


        }

		$h_data['page_title'] = "admin Users";
        $c_data = [];
        if(isset($_GET['search'])){
            $s = $_GET['search'];
            $c_data['list'] = $this->db->query("SELECT * FROM users WHERE ((username LIKE '%$s%') OR (fullname LIKE '%$s%')) AND hidden='0' ORDER BY id DESC");
        }
        else{
            $c_data['list'] = $this->db->query("SELECT * FROM users WHERE hidden='0' ORDER BY id DESC");
        }
        $this->load->view('admin/header', $h_data);
		$this->load->view('admin/users', $c_data);
		unset($_SESSION['notification']);
	}
}
