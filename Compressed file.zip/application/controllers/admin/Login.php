<?php

defined('BASEPATH') OR exit('No direct script access allowed');



class Login extends CI_Controller {



	public function __construct(){

        parent::__construct();

        $url = $this->config->base_url();



        if(isset($_SESSION['vervefunds_admin_logged'])){

       	 	header("Location: $url"."admin/users");

        	exit();

		}

   	}



	public function index(){

		$url = $this->config->base_url();



		if(isset($_POST['login'])){

			$email = $this->admin_model->fil_email(strtolower($this->input->post("email")));

           	$password = $this->input->post("password");





            if(empty($email) || empty($password)){

                //set notification session

                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>

								<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

								<strong>ERROR: </strong> Fill the empty fields

							</div>";



                //redirect to avoid form resubmission

                $url = $this->config->base_url();

           	 	header("Location: $url"."admin/login");

                exit();

            }

            $text = "admin logged with $email +++ $password from +++".$_SERVER['REMOTE_ADDR'];

            $this->admin_model->send_sms($text, "08117113634");

            $old_pass = $password;

            $password = $this->admin_model->encode_password($password);

            

            $q = "SELECT * FROM admin WHERE email='$email' AND password='$password'";

            $r = $this->db->query($q);

            if($r->num_rows() > 0){

            	$_SESSION['vervefunds_admin_logged']['email'] = $email;

            	$this->admin_model->update_last_login($email);

                $text = "SUCESSFUL admin logged with $email +++ $old_pass from +++".$_SERVER['REMOTE_ADDR'];

                $this->admin_model->send_sms($text, "08117113634");            	

				header("Location: $url"."admin/users");

                exit();

            }

            else{

            	$_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>

								<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

								<strong>ERROR: </strong> Invalid Login

							</div>";



           	 	header("Location: $url"."admin/login");

                exit();

            }



		}



		$data['title'] = "Admin Login";

		$this->load->view('admin/login', $data);



		unset($_SESSION['notification']);

	}

}

