<?php







defined('BASEPATH') OR exit('No direct script access allowed');



class News extends CI_Controller {



	public function __construct(){







        parent::__construct();







        $url = $this->config->base_url();















        if(!isset($_SESSION['vervefunds_admin_logged'])){







       	 	header("Location: $url"."admin/login");







        	exit();







		}







   	}















	public function index(){







		$url = $this->config->base_url();















        if(isset($_POST['search'])){







            $s = $_POST['search'];















            header("Location: $url"."admin/ph?search=$s");







            exit();







        }















        if(isset($_POST['reg_news'])){















            $title = $this->input->post("title");







            $category = $this->input->post("category");







            $content = nl2br(htmlentities($this->input->post("content"), ENT_QUOTES, 'UTF-8'));















            if(empty($content)){







                //set notification session







                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>







                  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>







                  <strong>ERROR: </strong> Fill the empty fields







                </div>";















                header("Location: $url"."admin/news");







                exit();







            }















            if($this->db->insert('news', ['content'=>$content])){







                $_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>







                            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>







                            <strong>SUCCESS: </strong> Request Processed







                        </div>";















                $url = $this->config->base_url();







                header("Location: $url"."admin/news");







                exit();







            }







            else{







                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>







                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>







                                <strong>ERROR: </strong> Request Failed, Try Again.







                            </div>";















                //redirect to avoid form resubmission







                $url = $this->config->base_url();







                header("Location: $url"."admin/news");







                exit();















            }















        } 















        //Ajax







        if($this->input->is_ajax_request()){







            if (isset($_POST['action']) AND $_POST['action'] == "delete_news"){







                $id = $_POST['news_id'];







                if($this->db->query("DELETE FROM news WHERE id='$id'")){







                    echo "1";







                    exit();







                }







                else{







                    echo "0";







                    exit();







                }







            }















            if (isset($_POST['action']) AND $_POST['action'] == "publish"){







                $id = $_POST['news_id'];







                if($this->db->query("UPDATE news SET is_published='1' WHERE id='$id'")){







                    echo "1";







                    exit();







                }







                else{







                    echo "0";







                    exit();







                }







            }















            if (isset($_POST['action']) AND $_POST['action'] == "unpublish"){







                $id = $_POST['news_id'];







                if($this->db->query("UPDATE news SET is_published='0' WHERE id='$id'")){







                    echo "1";







                    exit();







                }







                else{







                    echo "0";







                    exit();







                }







            }







        }















		$h_data['page_title'] = "News - admin";















        $c_data = [];















        if(isset($_GET['search'])){







            $s = $_GET['search'];







            $c_data['list'] = $this->db->query("SELECT * FROM news WHERE (title LIKE '%$s%') OR (category LIKE '%$s%') ORDER BY id DESC");







        }







        else{







            $c_data['list'] = $this->db->query("SELECT * FROM news ORDER BY id DESC");







        }















        $this->load->view('admin/header', $h_data);







		$this->load->view('admin/news', $c_data);















		unset($_SESSION['notification']);







	}







}







