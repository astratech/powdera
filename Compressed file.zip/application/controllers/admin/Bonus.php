<?php



defined('BASEPATH') OR exit('No direct script access allowed');







class Bonus extends CI_Controller {







	public function __construct(){



        parent::__construct();



        $url = $this->config->base_url();







        if(!isset($_SESSION['vervefunds_admin_logged'])){



       	 	header("Location: $url"."admin/login");



        	exit();



		}



   	}







	public function index(){



		$url = $this->config->base_url();







        if(isset($_POST['search'])){



            $s = $_POST['search'];







            header("Location: $url"."admin/bonus?search=$s");



            exit();



        }







        //Ajax



        if($this->input->is_ajax_request()){



            if (isset($_POST['action']) AND $_POST['action'] == "delete_bonus"){



                $id = $_POST['gh_id'];



                if($this->db->query("DELETE FROM bonus WHERE id='$id'")){



                    echo "1";



                    exit();



                }



                else{



                    echo "0";



                    exit();



                }



            }







            if (isset($_POST['action']) AND $_POST['action'] == "confirm_gh"){



                $id = $_POST['gh_id'];



                if($this->db->query("UPDATE gh SET is_confirmed='1' WHERE id='$id'")){



                    echo "1";



                    exit();



                }



                else{



                    echo "0";



                    exit();



                }



            }



        }







		$h_data['page_title'] = "admin Bonus";







        $c_data = [];







        if(isset($_GET['search'])){



            $s = $_GET['search'];



            $c_data['list'] = $this->db->query("SELECT * FROM bonus WHERE (trans_num LIKE '%$s%') OR (username LIKE '%$s%') OR (amount LIKE '%$s%') ORDER BY id DESC");



        }



        else{



            $c_data['list'] = $this->db->query("SELECT * FROM bonus ORDER BY id DESC");



        }







        $this->load->view('admin/header', $h_data);



		$this->load->view('admin/bonus', $c_data);







		unset($_SESSION['notification']);



	}



}



