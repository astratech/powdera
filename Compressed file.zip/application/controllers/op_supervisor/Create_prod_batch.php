<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Create_prod_batch extends CI_Controller {
	public function __construct(){
        parent::__construct();
        $url = $this->config->base_url();

        if(!isset($_SESSION['powdera_logged'])){
            header("Location: $url"."login");
            exit();
        } 

        $this->mod_dir = $this->site_model->get_dept($_SESSION['powdera_logged']['dept_id'])->url;
        $this->full_url = $this->config->base_url()."".$this->mod_dir;
        $this->staff_id = $_SESSION['powdera_logged']['staff_id'];
        $this->module = "Operations Supervisor";
   	}

	public function index(){

        if(isset($_POST['create_prod'])){

            $business_line_id =  $this->site_model->fil_string($this->input->post("business_line_id"));
            $uq_id =  $this->site_model->gen_uq_id("PRD");

            if(empty($business_line_id)) {
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                            <strong>ERROR: </strong> Fill the empty fields
                        </div>";
                header("Location: $url".$mod_dir."create_prod_batch");
                exit();
            }   

            $current_ass_process_id =  $this->site_model->get_biz_first_process("$business_line_id")->id;

            $r = $this->db->query("SELECT * FROM prod_batch WHERE uq_id='$uq_id'");
            if($r->num_rows() > 0){
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Code already exist. 
                            </div>";

                    header("Location: $url".$mod_dir."create_prod_batch");
                    exit();
            }

            $date = date("Y-m-d H:i:s");

            $this->db->insert('prod_batch', ['business_line_id'=>$business_line_id, 
                    'uq_id'=>$uq_id, 
                    'current_ass_process_id'=>$current_ass_process_id, 
                    'date_created'=>$date]);

            $prod_batch_id = $this->site_model->get_last_inserted("prod_batch")->id;

            $_SESSION['cache_form_prod_batch']['id'] = $prod_batch_id;

            $_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                    <strong>Operation Successful </strong> 
                  </div>";
            header("Location: $url".$mod_dir."create_prod_batch");
            exit();
            
        }


        if(isset($_POST['reg_process'])){

            $prod_batch_id =  $this->site_model->fil_string($this->input->post("prod_batch_id"));
            $assigned_process_id =  $this->site_model->fil_string($this->input->post("assigned_process_id"));
            $num_of_output =  $this->site_model->fil_num($this->input->post("num_of_output"));
            $num_of_input =  $this->site_model->fil_string($this->input->post("num_of_input"));

            if(empty($prod_batch_id) OR empty($assigned_process_id) OR empty($num_of_input) OR empty($num_of_output)) {
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                            <strong>ERROR: </strong> Fill the empty fields
                        </div>";
                header("Location: $url".$mod_dir."create_prod_batch");
                exit();
            }   

            $r = $this->db->query("SELECT * FROM prod_batch_process WHERE prod_batch_id='$prod_batch_id' AND $assigned_process_id='$assigned_process_id'");
            if($r->num_rows() > 0){
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Operation Failed
                            </div>";

                    header("Location: $url".$mod_dir."create_prod_batch");
                    exit();
            }

            $date = date("Y-m-d H:i:s");

            $this->db->insert('prod_batch_process', ['prod_batch_id'=>$prod_batch_id, 
                    'assigned_process_id'=>$assigned_process_id, 
                    'num_of_output'=>$num_of_output, 
                    'num_of_input'=>$num_of_input, 
                    'date_created'=>$date]);

            $last_prod_batch_process_id = $this->site_model->get_last_inserted("prod_batch_process")->id;

            $_SESSION['cache_form_prod_batch']['last_prod_batch_process_id'] = $last_prod_batch_process_id;

            $_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                    <strong>Operation Successful </strong> 
                  </div>";
            header("Location: $url".$mod_dir."create_prod_batch");
            exit();
            
        }

        if(isset($_POST['reg_items'])){

            // print "<pre>";
            // print_r($_POST);
            // print "</pre>";
            // exit();
            $prod_batch_process_id = $_SESSION['cache_form_prod_batch']['last_prod_batch_process_id'];
            $prod_batch_id = $_SESSION['cache_form_prod_batch']['id'];

            foreach ($_POST['item_id'] as $key => $val) {
                if (empty($val)) {

                    $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Please Select an Item.
                            </div>";
                    header("Location: $url".$mod_dir."create_prod_batch");
                    exit();
                }
            }

            foreach ($_POST['quantity'] as $key => $val) {
                if (empty($val)) {
                    $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Please Input quantity.
                            </div>";
                    header("Location: $url".$mod_dir."create_prod_batch");
                    exit();
                }
            }  

            // echo count($_POST['sn']);
            // exit();

            $count = count($this->input->post("sn"));
            $date = date("Y-m-d H:i:s");
            $this->db->trans_begin();

            // insert items
            for ($i=0; $i<$count; $i++) { 
                $item_id = $_POST['item_id']["$i"];
                $quantity = $_POST['quantity']["$i"];

                if(empty($item_id) OR $quantity <= 0){
                    $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                            <strong>Operation Failed. </strong> 
                          </div>";
                    header("Location: $this->full_url"."create_prod_batch");
                    exit();
                }

                $this->db->insert('prod_input_items', ['prod_batch_id'=>$prod_batch_id, 
                    'prod_batch_process_id'=>$prod_batch_process_id, 
                    'quantity'=>$quantity, 
                    'store_item_id'=>$item_id, 
                    'staff_id' => $this->staff_id, 
                    'date_created'=>$date]);
            }

            // update batch process status
            $this->db->query("UPDATE prod_batch_process SET status='awaiting',num_of_input='$count' WHERE id='$prod_batch_process_id'");

            if($this->db->trans_status() === FALSE){
                $this->db->trans_rollback();
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                    <strong>Operation Failed. </strong> 
                  </div>";
                header("Location: $url".$mod_dir."create_prod_batch");
                exit();
            }
            else{
                $this->db->trans_commit();
                $_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                    <strong>Operation Successful, Item Added Awaiting Approval. </strong> 
                  </div>";
                header("Location: $url".$mod_dir."create_prod_batch");
                exit();
            } 
            
        }

        if(isset($_POST['reg_output_items'])){

            // print "<pre>";
            // print_r($_POST);
            // print "</pre>";
            // exit();
            $prod_batch_process_id = $_SESSION['cache_form_prod_batch']['last_prod_batch_process_id'];
            $prod_batch_id = $_SESSION['cache_form_prod_batch']['id'];

            foreach ($_POST['item'] as $key => $val) {
                if (empty($val)) {

                    $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Please Select an Item.
                            </div>";
                    header("Location: $url".$mod_dir."create_prod_batch");
                    exit();
                }
            }

            foreach ($_POST['quantity'] as $key => $val) {
                if (empty($val)) {
                    $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Please Input quantity.
                            </div>";
                    header("Location: $url".$mod_dir."create_prod_batch");
                    exit();
                }
            }  

            foreach ($_POST['unit'] as $key => $val) {
                if (empty($val)) {

                    $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Please Select an Item.
                            </div>";
                    header("Location: $url".$mod_dir."create_prod_batch");
                    exit();
                }
            }

            // echo count($_POST['sn']);
            // exit();

            $count = count($this->input->post("sn"));
            $date = date("Y-m-d H:i:s");
            $this->db->trans_begin();

            // insert items
            for ($i=0; $i<$count; $i++) { 
                $item_id = $_POST['item_id']["$i"];
                $quantity = $_POST['quantity']["$i"];

                if(empty($item_id) OR $quantity <= 0){
                    $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                            <strong>Operation Failed. </strong> 
                          </div>";
                    header("Location: $this->full_url"."create_prod_batch");
                    exit();
                }

                $this->db->insert('prod_input_items', ['prod_batch_id'=>$prod_batch_id, 
                    'prod_batch_process_id'=>$prod_batch_process_id, 
                    'quantity'=>$quantity, 
                    'store_item_id'=>$item_id, 
                    'staff_id' => $this->staff_id, 
                    'date_created'=>$date]);
            }

            // update batch process status
            $this->db->query("UPDATE prod_batch_process SET status='awaiting',num_of_input='$count' WHERE id='$prod_batch_process_id'");

            if($this->db->trans_status() === FALSE){
                $this->db->trans_rollback();
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                    <strong>Operation Failed. </strong> 
                  </div>";
                header("Location: $url".$mod_dir."create_prod_batch");
                exit();
            }
            else{
                $this->db->trans_commit();
                $_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                    <strong>Operation Successful, Item Added Awaiting Approval. </strong> 
                  </div>";
                header("Location: $url".$mod_dir."create_prod_batch");
                exit();
            } 
            
        }

        if(isset($_POST['update_supplier'])){ 
            
            $name =  $this->site_model->fil_string($this->input->post("name"));
            $uq_id =  $this->site_model->fil_string($this->input->post("uq_id"));
            $supplier_id =  $this->site_model->fil_string($this->input->post("supplier_id"));


            //check for empty fields
            foreach ($_POST as $key => $val) {
                if (empty($val) OR empty($supplier_id)) {

                    $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Fill the empty fields
                            </div>";
                    header("Location: $url".$mod_dir."suppliers");
                    exit();
                }

            } 


            $r = $this->db->query("SELECT * FROM customers WHERE (name='$name' OR uq_id='$uq_id') AND id!='$supplier_id'");
            if($r->num_rows() > 0){
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Supplier already exist. 
                            </div>";

                    header("Location: $url".$mod_dir."suppliers");
                    exit();
            }

            $date = date("Y-m-d H:i:s");

            $up_data = ['name'=>$name];

            $where = "id = $supplier_id";

            $str = $this->db->update_string('suppliers', $up_data, $where);


            $this->db->query("$str");

            $_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                    <strong>Operation Successful </strong> 
                  </div>";
            header("Location: $url".$mod_dir."suppliers");
            exit();
            
        }

        if(isset($_POST['delete_supplier'])){

            $supplier_id =  $this->site_model->fil_num($this->input->post("supplier_id"));
            
            if(empty($supplier_id)){
                  $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Operation Failed
                            </div>";

                    header("Location: $url".$mod_dir."suppliers");
                    exit();
            }

            $date = date("Y-m-d H:i:s");

            $this->db->query("DELETE FROM suppliers WHERE id='$supplier_id'");

            $_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                    <strong>Operation Successful </strong> 
                  </div>";
            header("Location: $url".$mod_dir."suppliers");
            exit();
            
        }

        $data['page_title'] = "Create Production Batch";

        $this->load->view("$this->mod_dir"."header",$data);
        $this->load->view("$this->mod_dir"."create_prod_batch",$data);
        // $this->load->view("$this->mod_dir"."footer",$data);
        unset($_SESSION['notification']);
	}
}
