<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Getter extends CI_Controller {

	public function __construct(){
        parent::__construct(); 
        $url = $this->config->base_url();
        
        if($this->admin_model->get_option("repair")->value == 1){
        	header("Location: $url"."maintenance");
        	exit();
        }
		
   	}

	public function index(){
		echo "This is getter man";
		//Ajax
	    if($this->input->is_ajax_request()){
			if(isset($_POST['action']) AND $_POST['action'] == "confirm_payment") {
	          	$merge_id = $_POST['merge_id'];
		        $time_left = $_POST['time_left'];
		        $ph_id = $this->admin_model->get_merge($merge_id)->ph_id;
		        $gh_id = $this->admin_model->get_merge($merge_id)->gh_id;

		        $ph_amount = $this->admin_model->get_ph($ph_id)->amount;
		        $ph_returns = $this->admin_model->get_ph($ph_id)->returns;
		        $ph_username = $this->admin_model->get_ph($ph_id)->username;
		        $ph_trans_num = $this->admin_model->get_ph($ph_id)->trans_num;
		        $ph_is_gh = $this->admin_model->get_ph($ph_id)->is_gh;

		        $gh_amount = $this->admin_model->get_gh($gh_id)->amount;
		        $gh_username = $this->admin_model->get_gh($gh_id)->username;
		        $gh_trans_num = $this->admin_model->get_gh($gh_id)->trans_num;

		        $ph_merge_amount = 0;
		        $gh_merge_amount = 0;
		        $date = date("Y-m-d H:m:i");

		        //update merge
		        $this->db->query("UPDATE merge SET is_confirmed='1',date_paid='$date' WHERE id='$merge_id'");


	            //get total ph merge amount confirmed
	            $q = $this->db->query("SELECT * FROM merge WHERE ph_id='$ph_id' AND is_confirmed='1'");

		        if($q->num_rows() > 0){
		            foreach ($q->result() as $r) {
		                $ph_merge_amount = $ph_merge_amount + $r->amount;
		            }
		        }


		        //get total gh merge amount confirmed
	            $q1 = $this->db->query("SELECT * FROM merge WHERE gh_id='$gh_id' AND is_confirmed='1'");
		        if($q1->num_rows() > 0){
		            foreach ($q1->result() as $r) {
		                $gh_merge_amount = $gh_merge_amount + $r->amount;
		            }
		        }

		        $ph_20_percent = (30/100) * $ph_amount;
		        if($ph_20_percent >= $ph_merge_amount){
		        	// unlock all GH
		        	$this->db->query("UPDATE gh SET locked='0' WHERE username='$ph_username'");	
		        }
	        

		        // check ph amount
		        if($ph_merge_amount >= $ph_amount){
		        	$this->db->query("UPDATE ph SET is_confirmed='1', date_confirmed='$date' WHERE id='$ph_id'");

		        	// unlock all GH
		        	$this->db->query("UPDATE gh SET locked='0' WHERE username='$ph_username'");
		        	
		        	// give ref bonus
			        if($this->admin_model->is_user_ph_first_time($ph_username)){
			        	$ref = $this->admin_model->get_user($ph_username)->ref;
			        	$b_amount  = (10/100) * $ph_amount;

			        	$trans_num = $this->admin_model->gen_token();

		         		   	// insert ref bonus
		         		   	$this->db->insert('bonus', ['username'=>$ref, 'amount'=>$b_amount, 'trans_num'=>$trans_num, 'type'=>'ref bonus', 'date_created'=>$date]);

			        }
							
		        	$date = date("Y-m-d H:i:s");

	        		// insert gh capital
	            	// $trans_num = strtoupper($this->admin_model->gen_token());
	            	// $this->db->insert('gh', ['username'=>$ph_username, 'amount'=>$ph_returns, 'trans_num'=>$trans_num, 'ph_id'=>$ph_id, 'date_created'=>$date]);
		
		        }

		        // check gh amount
		        if($gh_merge_amount >= $gh_amount){
		        	
		        	//update gh confirmed
	            	$this->db->query("UPDATE gh SET is_confirmed='1' WHERE id='$gh_id'");

	            	

	            	// update ph is_paid
	            	$this->db->query("UPDATE ph SET is_paid='1' WHERE trans_num='$gh_trans_num'");

						

		        }

                echo "1";
				exit();
	        }
	        elseif(isset($_POST['action']) AND $_POST['action'] == "cancel_payment") {
	            $merge_id = $_POST['merge_id'];
		        $ph_id = $this->admin_model->get_merge($merge_id)->ph_id;
		        $gh_id = $this->admin_model->get_merge($merge_id)->gh_id;
		        $ph_amount = $this->admin_model->get_ph($ph_id)->amount;
		        $ph_username = $this->admin_model->get_ph($ph_id)->username;
		        $ph_trans_num = $this->admin_model->get_ph($ph_id)->trans_num;
		        $ph_recycle = $this->admin_model->get_ph($ph_id)->is_recycle;

		        // if user has paid
	            $q = $this->db->query("SELECT * FROM merge WHERE gh_id='$gh_id' AND is_confirmed='1'");
		        if($q->num_rows() > 0){
		           
                	// delete merge
			        $this->db->query("DELETE FROM merge WHERE ph_id='$ph_id'");

			         // delete PH
			        $this->db->query("DELETE FROM ph WHERE id='$ph_id'");

			        // update gh
			       	$this->db->query("UPDATE gh SET is_merge='0' WHERE id='$m->gh_id'");

			        // block user
			        $this->db->query("UPDATE users SET is_blocked='1',cause_of_blockage='user cancel payment' WHERE username='$ph_username'");
	                echo "1";
	                exit();	 
		        }
		        else{
		        	 //get all merge and delete dem
		            $q = $this->db->query("SELECT * FROM merge WHERE ph_id='$ph_id' AND is_confirmed='0'");
			        if($q->num_rows() > 0){
			            foreach ($q->result() as $m) {

			            	$q1 = $this->db->query("SELECT * FROM merge WHERE gh_id='$m->gh_id'");
			        		if($q1->num_rows() == 1){
			            		// update gh
			       				$this->db->query("UPDATE gh SET is_merge='0' WHERE id='$m->gh_id'");
			       			}

			            	// delete the merge
			        		$this->db->query("DELETE FROM merge WHERE id='$m->id'");

			            }
			        }

			        // delete PH
			        $this->db->query("DELETE FROM ph WHERE id='$ph_id'");

			        // block user
			        $this->db->query("UPDATE users SET is_blocked='1',cause_of_blockage='User cancel payment' WHERE username='$ph_username'");
	                echo "1";
	                exit();	
	               }    
           
	        }
	        elseif(isset($_POST['action']) AND $_POST['action'] == "have_paid") {
	            $merge_id = $_POST['merge_id'];
		        $ph_id = $this->admin_model->get_merge($merge_id)->ph_id;
		        $gh_id = $this->admin_model->get_merge($merge_id)->gh_id;
		        $ph_amount = $this->admin_model->get_ph($ph_id)->amount;
		        $ph_username = $this->admin_model->get_ph($ph_id)->username;
		        $ph_trans_num = $this->admin_model->get_ph($ph_id)->trans_num;
		        $ph_recycle = $this->admin_model->get_ph($ph_id)->is_recycle;

		        // block user
		        $this->db->query("UPDATE merge SET have_paid='1' WHERE id='$merge_id'");
                echo "1";
                exit();	                
	        }
	        elseif(isset($_POST['action']) AND $_POST['action'] == "purge") {
	           	$merge_id = $_POST['merge_id'];
		        $ph_id = $this->admin_model->get_merge($merge_id)->ph_id;
		        $gh_id = $this->admin_model->get_merge($merge_id)->gh_id;
		        $ph_amount = $this->admin_model->get_ph($ph_id)->amount;
		        $ph_username = $this->admin_model->get_ph($ph_id)->username;
		        $ph_trans_num = $this->admin_model->get_ph($ph_id)->trans_num;
		        $ph_recycle = $this->admin_model->get_ph($ph_id)->is_recycle;

		        // if user has paid
	            $q = $this->db->query("SELECT * FROM merge WHERE gh_id='$gh_id' AND is_confirmed='1'");
		        if($q->num_rows() > 0){
		           
                	// delete merge
			        $this->db->query("DELETE FROM merge WHERE ph_id='$ph_id'");

			        // delete PH
			        $this->db->query("DELETE FROM ph WHERE id='$ph_id'");

			        // update gh
			       	$this->db->query("UPDATE gh SET is_merge='0' WHERE id='$m->gh_id'");

			        // block user
			        $this->db->query("UPDATE users SET is_blocked='1',cause_of_blockage='User Purged' WHERE username='$ph_username'");
	                echo "1";
	                exit();	 
		        }
		        else{
		        	 //get all merge and delete dem
		            $q = $this->db->query("SELECT * FROM merge WHERE ph_id='$ph_id' AND is_confirmed='0'");
			        if($q->num_rows() > 0){
			            foreach ($q->result() as $m) {

			            	$q1 = $this->db->query("SELECT * FROM merge WHERE gh_id='$m->gh_id'");
			        		if($q1->num_rows() == 1){
			            		// update gh
			       				$this->db->query("UPDATE gh SET is_merge='0' WHERE id='$m->gh_id'");
			       			}

			            	// delete the merge
			        		$this->db->query("DELETE FROM merge WHERE id='$m->id'");

			            }
			        }

			        // delete PH
			        $this->db->query("DELETE FROM ph WHERE id='$ph_id'");

			        // block user
			        $this->db->query("UPDATE users SET is_blocked='1',cause_of_blockage='User Purged' WHERE username='$ph_username'");
	                echo "1";
	                exit();	
	            }    
	        }
	        elseif(isset($_POST['action']) AND $_POST['action'] == "cashout_bonus") {
	            $amount = "10000";
	            $trans_num = $this->admin_model->gen_trans_num();

	            // insert gh
                $this->db->insert('gh', ['username'=>$this->username, 'amount'=>$amount, 'ph_id'=>"0", 'trans_num'=>$trans_num, 'type'=>'bonus']);

	            // update bonus
	            $this->db->query("UPDATE bonus SET is_paid='1' WHERE username='$this->username'");
	            
                echo "1";
				exit();
	        }
	        else{
	        	echo "0";
	        	exit();
	        }
	    }

		
		$h_data['page_title'] = "";
		$c_data = [];
    
	}

	public function get_merge_receiver(){
		if(!isset($_GET['merge_id'])){
			exit();
		}

		$merge_id = $this->admin_model->fil_num($_GET['merge_id']);
		$ph_id = $this->admin_model->get_merge($merge_id)->ph_id;
		$gh_id = $this->admin_model->get_merge($merge_id)->gh_id;
		$amount = $this->admin_model->get_merge($merge_id)->amount;
		$ph_fullname = $this->admin_model->get_user($this->admin_model->get_gh($gh_id)->username)->account_name;
		$ph_mobile = $this->admin_model->get_user($this->admin_model->get_gh($gh_id)->username)->mobile;
		$bank_name = $this->admin_model->get_user($this->admin_model->get_gh($gh_id)->username)->bank_name;
		$account_number = $this->admin_model->get_user($this->admin_model->get_gh($gh_id)->username)->account_number;
		$account_type = $this->admin_model->get_user($this->admin_model->get_gh($gh_id)->username)->account_type;

		echo "<div style='font-size: 18px;'>
				<p>Receiver Name: <span id='rn'>$ph_fullname</span></p>
              	<p>Receiver Phone Number: <span id='rm'>$ph_mobile</span></p>
              	<p>Bank Name: <span id='rb'>$bank_name</span></p>
              	<p>Account Number: <span id='ra'>$account_number</span></p>
              	<p>Account Type: <span id='rt'>$account_type</span></p>
              	<p style='font-size:30px; text-align: center;'>₦ $amount</p>
              </div>";
              	exit();
	}

	public function get_merge_sender(){
		if(!isset($_GET['merge_id'])){
			exit();
		}
		
		$merge_id = $this->admin_model->fil_num($_GET['merge_id']);
		$ph_id = $this->admin_model->get_merge($merge_id)->ph_id;
		$gh_id = $this->admin_model->get_merge($merge_id)->gh_id;
		$amount = $this->admin_model->get_merge($merge_id)->amount;
		$ph_fullname = $this->admin_model->get_user($this->admin_model->get_ph($ph_id)->username)->account_name;
		$ph_mobile = $this->admin_model->get_user($this->admin_model->get_ph($ph_id)->username)->mobile;
		$bank_name = $this->admin_model->get_user($this->admin_model->get_ph($ph_id)->username)->bank_name;
		$account_number = $this->admin_model->get_user($this->admin_model->get_ph($ph_id)->username)->account_number;
		$account_type = $this->admin_model->get_user($this->admin_model->get_ph($ph_id)->username)->account_type;

		echo "<div style='font-size: 18px;'>
				<p>Receiver Name: <span id='rn'>$ph_fullname</span></p>
              	<p>Receiver Phone Number: <span id='rm'>$ph_mobile</span></p>
              	<p>Bank Name: <span id='rb'>$bank_name</span></p>
              	<p>Account Number: <span id='ra'>$account_number</span></p>
              	<p>Account Type: <span id='rt'>$account_type</span></p>
              	<p style='font-size:30px; text-align: center;'>₦ $amount</p>
              </div>";
              	exit();
	}
}
