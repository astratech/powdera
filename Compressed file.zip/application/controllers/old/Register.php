<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Register extends CI_Controller {
    public function __construct(){
        parent::__construct(); 
    }
    public function index(){
        $url = $this->config->base_url();
        // header("Location: $url"."login");
        // exit();
        
        if(isset($_POST['reg_user'])){
            $fullname = strtolower($this->admin_model->fil_string($this->input->post("fullname")));
            $email = strtolower($this->admin_model->fil_email($this->input->post("email")));
            $mobile = strtolower($this->admin_model->fil_num($this->input->post("mobile")));
            // $ref = "gazfunds";
            $ref = strtolower($this->admin_model->fil_string($this->input->post("ref")));
            // $city = strtolower($this->admin_model->fil_string($this->input->post("city")));
            $username = strtolower($this->admin_model->fil_string($this->input->post("username")));
            $password = $this->admin_model->fil_string($this->input->post("password"));
            $r_password = $this->admin_model->fil_string($this->input->post("rpassword"));
            $bank_id = $this->input->post("bank");
            $account_type = $this->input->post("account_type");
            $account_number = $this->admin_model->fil_num($this->input->post("account_number"));
            // $capt_text = $this->admin_model->fil_num($this->input->post("capt_text"));
            // $capt_ans = $this->admin_model->fil_num($this->input->post("capt_ans"));
            $package = "10000";
            
            $account_name = $this->admin_model->fil_string($this->input->post("account_name"));
            $date = date("Y-m-d H:i:s");
            $ver_code = rand(100000,999999);

            // if($capt_ans != $capt_text){
            //     //set notification session
            //     $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
            //                     <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
            //                     <strong>ERROR: </strong>Invalid Captcha.
            //                 </div>";
            //     header("Location: $url"."register");
            //     exit();
            // }

            //check for empty fields
            foreach ($_POST as $key => $val) {
                $_SESSION['reg_form'][$key] = $val;
                if (empty($val)) {
                    // echo "$key";
                    // exit();
                    $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Fill the empty fields
                            </div>";
                    header("Location: $url"."register?ref=$ref");
                    exit();
                }
            }

            //check ref
            if(!$this->admin_model->username_exist($ref)){
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong>Referral $ref does not Exist, Try another One
                            </div>";
                header("Location: $url"."register?ref=$ref");
                exit();
            }
            
            //check password
            if($password != $r_password){
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Password Mismatch
                            </div>";
                header("Location: $url"."register?ref=$ref");
                exit();
            }

            //check email
            if($this->admin_model->email_exist($email)){
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Email Already Exist, Try another One
                            </div>";
                header("Location: $url"."register?ref=$ref");
                exit();
            }

            //check mobile
            if($this->admin_model->mobile_exist($mobile)){
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Phone Number Already Exist, Try another One
                            </div>";
                header("Location: $url"."register?ref=$ref");
                exit();
            }

            //check username
            if($this->admin_model->username_exist($username)){
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Username Already Exist, Try another One
                            </div>";
                header("Location: $url"."register?ref=$ref");
                exit();
            }

            

            //check account number
            if($this->admin_model->account_number_exist($account_number)){
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Account Number Already Used, Try another One
                            </div>";
                header("Location: $url"."register?ref=$ref");
                exit();
            }

            //validate account number
            if(strlen($account_number) != 10){
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Invalid Account number
                            </div>";
                header("Location: $url"."register?ref=$ref");
                exit();
            }

            if(strlen($mobile) != 11){
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Invalid phone number
                            </div>";
                header("Location: $url"."register?ref=$ref");
                exit();
            }

            // validate mobile
            if(!$this->admin_model->validate_mobile($mobile)){
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Your Phone Number $mobile is not active, try another one.
                            </div>";
                header("Location: $url"."register?ref=$ref");
                exit();
            }

            $password = $this->admin_model->encode_password($password);

            if($this->db->insert('users', ['fullname'=>$fullname, 'username'=>$username, 'email'=>$email, 'mobile'=>$mobile, 'password'=>$password, 'bank_id'=>$bank_id, 'account_name'=>$account_name, 'account_number'=>$account_number, 'account_type'=>$account_type, 'last_login'=>$date,'verification_code'=>$ver_code, 'date_created'=>$date, 'ref'=>$ref])){

                // $ver_msg = "Hello $username, your verification code is $ver_code";
                // $this->admin_model->send_sms($ver_msg, $mobile);

                unset($_SESSION['reg_form']);
                
                $_SESSION['vervefunds_logged']['username'] = $username;
                $_SESSION['vervefunds_logged']['email'] = $email;

                header("Location: $url"."dashboard");
                exit();
               
            }
            else{
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Registration Failed. Try Again
                            </div>";
                unset($_SESSION['reg_form']);
                $url = $this->config->base_url();
                header("Location: $url"."register?ref=$ref");
                exit();
            }
        }
        $data['page_title'] = "Register";
        $this->load->view('header',$data);
        $this->load->view('register',$data);
        $this->load->view('footer',$data); 
        unset($_SESSION['notification']);
    }
}
