<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Security extends CI_Controller {

    public function __construct(){

        parent::__construct(); 

    }



    public function index(){

        $url = $this->config->base_url();

        

        if(isset($_POST['sub_secure'])){

            

            $r = $this->input->post("g-recaptcha-response");



            if(empty($r)){

                //set notification session

                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>

                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

                                <strong>ERROR: </strong> No Captcha.

                            </div>";

                header("Location: $url"."register");

                exit();

            }



            $g_url = "https://www.google.com/recaptcha/api/siteverify?secret=6LekTCAUAAAAAJ0m2lS5Ik3xJX8_QlmUi-esXMR4&response=".$r;

            $send = file_get_contents($g_url);

            $send = json_decode($send);





            if($send->success != 1){

                //set notification session

                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>

                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

                                <strong>ERROR: </strong>Invalid Captcha.

                            </div>";

                header("Location: $url");

                exit();

            }

            else{

                header("Location: $url"."login");

                exit();

            }



        }

        $data['page_title'] = "Kashout";

        // $this->load->view('header',$data);

        $this->load->view('secured',$data);

        // $this->load->view('footer',$data);

        unset($_SESSION['notification']);

    }

}

