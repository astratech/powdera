<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct(){
        parent::__construct(); 
   	}

	public function index(){
		$url = $this->config->base_url();	


		if(isset($_POST['login'])){
			$username = $this->input->post("username");
	        $password = $this->input->post("password");

	        if(empty($username) || empty($password)){
	            //set notification session
	            $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
	                            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
	                            <strong>ERROR: </strong> Fill the empty fields
	                        </div>";

	            header("Location: $url"."#login");
	            exit();
	        }

	        $password = $this->admin_model->encode_password($password);

	        
	        $q = "SELECT * FROM users WHERE username='$username' AND password='$password'";

	        $r = $this->db->query($q);

	        if($r->num_rows() > 0){

	            $url = $this->config->base_url();



	            foreach ($r->result() as $row) {

	                $_SESSION['sharp_logged']['username'] = $username;

	            }


	            $d = date("Y-m-d H:i:s");

	            $this->db->query("UPDATE users SET last_login='$d' WHERE username='$username'");

	            
	            header("Location: $url"."dashboard ");
	            exit();

	        }

	        else{

	            

	            $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>

	                            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

	                            <strong>ERROR: </strong> Invalid Login

	                        </div>";


	            header("Location: $url"."#login");
	            exit();

	        }
		}


		$this->load->view('header');
		$this->load->view('home');
		$this->load->view('footer');
		unset($_SESSION['notification']);
	}

}
