<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct(){
        parent::__construct(); 
        $url = $this->config->base_url();
        
        if($this->admin_model->get_option("repair")->value == 1){
        	header("Location: $url"."maintenance");
        	exit();
        }
		if(!isset($_SESSION['vervefunds_logged'])){
       	 	header("Location: $url");
            exit();
		}
		else{
			$this->username = $_SESSION['vervefunds_logged']['username'];
			//is user verified
			if(!$this->admin_model->is_user_verified($this->username)){
				header("Location: $url"."verify");
            	exit();
			}

			if(!$this->admin_model->is_user_activated($this->username)){

                header("Location: $url"."activate");

                exit();

            }
            
			//is user blocked
			if($this->admin_model->is_user_blocked($this->username)){
				$_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ACCOUNT BLOCKED: </strong> Hello $this->username, you account is blocked, contact the support team.
                            </div>";
           	 	header("Location: $url"."login");
            	exit();
			}
		}
   	}

	public function index(){

		
		//Ajax
	    if($this->input->is_ajax_request()){
			if(isset($_POST['action']) AND $_POST['action'] == "confirm_payment") {
	          	$merge_id = $_POST['merge_id'];
		        $time_left = $_POST['time_left'];
		        $ph_id = $this->admin_model->get_merge($merge_id)->ph_id;
		        $gh_id = $this->admin_model->get_merge($merge_id)->gh_id;

		        $ph_amount = $this->admin_model->get_ph($ph_id)->amount;
		        $ph_returns = $this->admin_model->get_ph($ph_id)->returns;
		        $ph_username = $this->admin_model->get_ph($ph_id)->username;
		        $ph_trans_num = $this->admin_model->get_ph($ph_id)->trans_num;
		        $ph_is_gh = $this->admin_model->get_ph($ph_id)->is_gh;

		        $gh_amount = $this->admin_model->get_gh($gh_id)->amount;
		        $gh_username = $this->admin_model->get_gh($gh_id)->username;
		        $gh_trans_num = $this->admin_model->get_gh($gh_id)->trans_num;

		        $ph_merge_amount = 0;
		        $gh_merge_amount = 0;
		        $date = date("Y-m-d H:m:i");

		        //update merge
		        $this->db->query("UPDATE merge SET is_confirmed='1',date_paid='$date' WHERE id='$merge_id'");


	            //get total ph merge amount confirmed
	            $q = $this->db->query("SELECT * FROM merge WHERE ph_id='$ph_id' AND is_confirmed='1'");

		        if($q->num_rows() > 0){
		            foreach ($q->result() as $r) {
		                $ph_merge_amount = $ph_merge_amount + $r->amount;
		            }
		        }


		        //get total gh merge amount confirmed
	            $q1 = $this->db->query("SELECT * FROM merge WHERE gh_id='$gh_id' AND is_confirmed='1'");
		        if($q1->num_rows() > 0){
		            foreach ($q1->result() as $r) {
		                $gh_merge_amount = $gh_merge_amount + $r->amount;
		            }
		        }

		        $ph_20_percent = (30/100) * $ph_amount;
		        if($ph_20_percent >= $ph_merge_amount){
		        	// unlock all GH
		        	$this->db->query("UPDATE gh SET locked='0' WHERE username='$ph_username'");	
		        }
	        

		        // check ph amount
		        if($ph_merge_amount >= $ph_amount){
		        	$this->db->query("UPDATE ph SET is_confirmed='1', date_confirmed='$date' WHERE id='$ph_id'");

		        	// unlock all GH
		        	$this->db->query("UPDATE gh SET locked='0' WHERE username='$ph_username'");
		        	
		        	// give ref bonus
			        if($this->admin_model->is_user_ph_first_time($ph_username)){
			        	$ref = $this->admin_model->get_user($ph_username)->ref;
			        	$b_amount  = (10/100) * $ph_amount;

			        	$trans_num = $this->admin_model->gen_token();

		         		   	// insert ref bonus
		         		   	$this->db->insert('bonus', ['username'=>$ref, 'amount'=>$b_amount, 'trans_num'=>$trans_num, 'type'=>'ref bonus', 'date_created'=>$date]);

			        }
							
		        	$date = date("Y-m-d H:i:s");

	        		// insert gh capital
	            	// $trans_num = strtoupper($this->admin_model->gen_token());
	            	// $this->db->insert('gh', ['username'=>$ph_username, 'amount'=>$ph_returns, 'trans_num'=>$trans_num, 'ph_id'=>$ph_id, 'date_created'=>$date]);
		
		        }

		        // check gh amount
		        if($gh_merge_amount >= $gh_amount){
		        	
		        	//update gh confirmed
	            	$this->db->query("UPDATE gh SET is_confirmed='1' WHERE id='$gh_id'");

	            	

	            	// update ph is_paid
	            	$this->db->query("UPDATE ph SET is_paid='1' WHERE trans_num='$gh_trans_num'");

						

		        }

                echo "1";
				exit();
	        }
	        elseif(isset($_POST['action']) AND $_POST['action'] == "confirm_activation") {
	          	$username = $_POST['username'];
		       	$this->db->query("UPDATE users SET activated='1' WHERE username='$username'");
	            echo "1";
	            exit();	 
		    }
	        elseif(isset($_POST['action']) AND $_POST['action'] == "cancel_payment") {
	            $merge_id = $_POST['merge_id'];
		        $ph_id = $this->admin_model->get_merge($merge_id)->ph_id;
		        $gh_id = $this->admin_model->get_merge($merge_id)->gh_id;
		        $ph_amount = $this->admin_model->get_ph($ph_id)->amount;
		        $ph_username = $this->admin_model->get_ph($ph_id)->username;
		        $ph_trans_num = $this->admin_model->get_ph($ph_id)->trans_num;
		        $ph_recycle = $this->admin_model->get_ph($ph_id)->is_recycle;

		        // if user has paid
	            $q = $this->db->query("SELECT * FROM merge WHERE gh_id='$gh_id' AND is_confirmed='1'");
		        if($q->num_rows() > 0){
		           
                	// delete merge
			        $this->db->query("DELETE FROM merge WHERE ph_id='$ph_id'");

			         // delete PH
			        $this->db->query("DELETE FROM ph WHERE id='$ph_id'");

			        // update gh
			       	$this->db->query("UPDATE gh SET is_merge='0' WHERE id='$m->gh_id'");

			        // block user
			        $this->db->query("UPDATE users SET is_blocked='1',cause_of_blockage='user cancel payment' WHERE username='$ph_username'");
	                echo "1";
	                exit();	 
		        }
		        else{
		        	 //get all merge and delete dem
		            $q = $this->db->query("SELECT * FROM merge WHERE ph_id='$ph_id' AND is_confirmed='0'");
			        if($q->num_rows() > 0){
			            foreach ($q->result() as $m) {

			            	$q1 = $this->db->query("SELECT * FROM merge WHERE gh_id='$m->gh_id'");
			        		if($q1->num_rows() == 1){
			            		// update gh
			       				$this->db->query("UPDATE gh SET is_merge='0' WHERE id='$m->gh_id'");
			       			}

			            	// delete the merge
			        		$this->db->query("DELETE FROM merge WHERE id='$m->id'");

			            }
			        }

			        // delete PH
			        $this->db->query("DELETE FROM ph WHERE id='$ph_id'");

			        // block user
			        $this->db->query("UPDATE users SET is_blocked='1',cause_of_blockage='User cancel payment' WHERE username='$ph_username'");
	                echo "1";
	                exit();	
	               }    
           
	        }
	        elseif(isset($_POST['action']) AND $_POST['action'] == "have_paid") {
	            $merge_id = $_POST['merge_id'];
		        $ph_id = $this->admin_model->get_merge($merge_id)->ph_id;
		        $gh_id = $this->admin_model->get_merge($merge_id)->gh_id;
		        $ph_amount = $this->admin_model->get_ph($ph_id)->amount;
		        $ph_username = $this->admin_model->get_ph($ph_id)->username;
		        $ph_trans_num = $this->admin_model->get_ph($ph_id)->trans_num;
		        $ph_recycle = $this->admin_model->get_ph($ph_id)->is_recycle;

		        // block user
		        $this->db->query("UPDATE merge SET have_paid='1' WHERE id='$merge_id'");
                echo "1";
                exit();	                
	        }
	        elseif(isset($_POST['action']) AND $_POST['action'] == "purge") {
	           	$merge_id = $_POST['merge_id'];
		        $ph_id = $this->admin_model->get_merge($merge_id)->ph_id;
		        $gh_id = $this->admin_model->get_merge($merge_id)->gh_id;
		        $ph_amount = $this->admin_model->get_ph($ph_id)->amount;
		        $ph_username = $this->admin_model->get_ph($ph_id)->username;
		        $ph_trans_num = $this->admin_model->get_ph($ph_id)->trans_num;
		        $ph_recycle = $this->admin_model->get_ph($ph_id)->is_recycle;

		        // if user has paid
	            $q = $this->db->query("SELECT * FROM merge WHERE gh_id='$gh_id' AND is_confirmed='1'");
		        if($q->num_rows() > 0){
		           
                	// delete merge
			        $this->db->query("DELETE FROM merge WHERE ph_id='$ph_id'");

			        // delete PH
			        $this->db->query("DELETE FROM ph WHERE id='$ph_id'");

			        // update gh
			       	$this->db->query("UPDATE gh SET is_merge='0' WHERE id='$m->gh_id'");

			        // block user
			        $this->db->query("UPDATE users SET is_blocked='1',cause_of_blockage='User Purged' WHERE username='$ph_username'");
	                echo "1";
	                exit();	 
		        }
		        else{
		        	 //get all merge and delete dem
		            $q = $this->db->query("SELECT * FROM merge WHERE ph_id='$ph_id' AND is_confirmed='0'");
			        if($q->num_rows() > 0){
			            foreach ($q->result() as $m) {

			            	$q1 = $this->db->query("SELECT * FROM merge WHERE gh_id='$m->gh_id'");
			        		if($q1->num_rows() == 1){
			            		// update gh
			       				$this->db->query("UPDATE gh SET is_merge='0' WHERE id='$m->gh_id'");
			       			}

			            	// delete the merge
			        		$this->db->query("DELETE FROM merge WHERE id='$m->id'");

			            }
			        }

			        // delete PH
			        $this->db->query("DELETE FROM ph WHERE id='$ph_id'");

			        // block user
			        $this->db->query("UPDATE users SET is_blocked='1',cause_of_blockage='User Purged' WHERE username='$ph_username'");
	                echo "1";
	                exit();	
	            }    
	        }
	        elseif(isset($_POST['action']) AND $_POST['action'] == "cashout_bonus") {
	            $amount = "10000";
	            $trans_num = $this->admin_model->gen_trans_num();

	            // insert gh
                $this->db->insert('gh', ['username'=>$this->username, 'amount'=>$amount, 'ph_id'=>"0", 'trans_num'=>$trans_num, 'type'=>'bonus']);

	            // update bonus
	            $this->db->query("UPDATE bonus SET is_paid='1' WHERE username='$this->username'");
	            
                echo "1";
				exit();
	        }
	        else{
	        	echo "0";
	        	exit();
	        }
	    }

		if(isset($_POST['cancel_payment'])){
	        $merge_id = $this->input->post('merge_id');
	        $ph_id = $this->admin_model->get_merge($merge_id)->ph_id;
	        $gh_id = $this->admin_model->get_merge($merge_id)->gh_id;
	        $ph_amount = $this->admin_model->get_ph($ph_id)->amount;
	        $ph_username = $this->admin_model->get_ph($ph_id)->username;
	        $ph_trans_num = $this->admin_model->get_ph($ph_id)->trans_num;
	        $ph_recycle = $this->admin_model->get_ph($ph_id)->is_recycle;

	        // update gh
	        $this->db->query("UPDATE gh SET is_merge='0' WHERE id='$gh_id'");

	        // update merge
	        $this->db->query("DELETE FROM merge WHERE id='$merge_id'");

	        // delete PH
	        $this->db->query("DELETE FROM ph WHERE id='$ph_id'");

	        // block user
	        $this->db->query("UPDATE users SET is_blocked='1' WHERE username='$ph_username'");

			$_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
					    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
					    <strong>SUCCESS: </strong> Transaction Cancelled
					  </div>";
	    	header("Location: $url"."dashboard");
	      	exit();
		}

		if(isset($_POST['purge'])){
	        $merge_id = $_POST['merge_id'];
            $ph_id = $this->admin_model->get_merge($merge_id)->ph_id;
            $gh_id = $this->admin_model->get_merge($merge_id)->gh_id;
            $ph_username = $this->admin_model->get_ph($ph_id)->username;

            //delete merge
	        $this->db->query("DELETE FROM merge WHERE id='$merge_id'");

	        if(!$this->admin_model->is_ph_in_merge_list($ph_id)){
	        	//delete ph
	            $this->db->query("DELETE FROM ph WHERE id='$ph->id'");
	        }

	        if(!$this->admin_model->is_gh_in_merge_list($gh_id)){
	        	//unmerge gh
	            $this->db->query("UPDATE gh SET is_merge='0' WHERE id='$m->gh_id'");
	        }

        	$_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
				    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
				    <strong>PURGE SUCCESSFUL: </strong> 
				  </div>";
	    	header("Location: $url"."dashboard");
	      	exit();

        }

		if(isset($_POST['cashout'])){
// 			if(!$this->admin_model->does_user_have_pending_ph($this->username)){
// 				$_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
// 					    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
// 					    <strong>Cash out Failed: </strong> You must have active PH before you can cash out.
// 					  </div>";
// 		    	header("Location: $url"."dashboard");
// 		      	exit();
// 			}

			$amount = $this->input->post('amount');
            $trans_num = $this->admin_model->gen_token();
            $date = date("Y-m-d H:m:i");

            // insert gh
            $this->db->insert('gh', ['username'=>$this->username, 'amount'=>$amount, 'ph_id'=>"0", 'trans_num'=>$trans_num, 'type'=>'bonus', 'date_created'=>$date]);

            // update bonus
            $this->db->query("UPDATE bonus SET is_paid='1' WHERE username='$this->username'");

			$_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
					    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
					    <strong>SUCCESS: </strong> Bonus Cash Out.
					  </div>";
	    	header("Location: $url"."dashboard");
	      	exit();
		}

		if(isset($_POST['cashout_gh'])){

			$amount = $this->input->post('amount');
			$ph_id = $this->input->post('ph_id');
            $trans_num = $this->admin_model->gen_token();
            $date = date("Y-m-d H:m:i");

            // insert gh
            $this->db->insert('gh', ['username'=>$this->username, 'amount'=>$amount, 'ph_id'=>$ph_id, 'trans_num'=>$trans_num, 'date_created'=>$date]);

            // update bonus
            $this->db->query("UPDATE ph SET is_gh='1' WHERE id='$ph_id'");

			$_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
					    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
					    Cash out Successful.
					  </div>";
	    	header("Location: $url"."dashboard");
	      	exit();
		}


	    if(isset($_POST['donate'])){

            $amount = $this->admin_model->fil_num($this->input->post("amount"));

            // $recycle = $this->input->post("recycle");
            $recycle = "0";

            // echo $amount;
            // exit();
            
            $date = date("Y-m-d H:i:s");
            $release_date = date('Y-m-d H:i:s', strtotime($date. ' + 5 days'));
            $returns = ((60/100) * $amount) + $amount;

            // check empty
            if(empty($amount)){
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                        <strong>ERROR: </strong> Fill the empty fields.
                    </div>";
                    header("Location: $url"."dashboard");
                    exit();
            }

            // check range
            // if($amount < 20000 OR $amount > 200000){
            //     $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
            //             <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
            //             <strong>ERROR: </strong> Amount must be between 20,000 and 200,000
            //         </div>";
            //         header("Location: $url"."dashboard");
            //         exit();
            // }

            // check pending transactions
            if($this->admin_model->does_user_have_pending_ph($this->username)){
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                        <strong>ERROR: </strong> Unable to donate, you have pending transactions
                    </div>";
                    header("Location: $url"."dashboard");
                    exit();
            }

            if($recycle == "1"){
            	$lst = $this->admin_model->get_user($this->username)->package;
	            if($amount < $lst){
	                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
	                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
	                        <strong>ERROR: </strong> Unable to donate, your recycle is lower than your last donation.
	                    </div>";
	                    header("Location: $url"."dashboard");
	                    exit();
	            }
            }
            // increase ph counter
            $ph_counter = $this->admin_model->get_user($this->username)->ph_count + 1;
            $this->db->query("UPDATE users SET ph_count='$ph_counter', package='$amount' WHERE username='$this->username'");

            // insert PH
            $trans_num = strtoupper($this->admin_model->gen_token());
            $this->db->insert('ph', ['username'=>$this->username, 'amount'=>$amount, 'returns'=>$returns, 'trans_num'=>$trans_num, 'is_recycle'=>$recycle, 'date_created'=>$date, 'release_date'=>$release_date]);


            $_SESSION['notification'] = "<div class='alert alert-callout alert-info alert-dismissable' role='alert'>
                            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                            <strong>You have successfully made a pledge of (₦ $amount) wait patiently to be assigned a sponsor.</strong>.
                        </div>";
                header("Location: $url"."dashboard");
                exit();

            
        }

        if(isset($_POST['recycle'])){

            $amount = $this->admin_model->fil_num($this->input->post("amount"));

            // $recycle = $this->input->post("recycle");
            $recycle = "1";

            // echo $amount;
            // exit();
            
            $date = date("Y-m-d H:i:s");
            $release_date = date('Y-m-d H:i:s', strtotime($date. ' + 5 days'));
            $returns = ((60/100) * $amount) + $amount;

            // check empty
            if(empty($amount)){
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                        <strong>ERROR: </strong> Fill the empty fields.
                    </div>";
                    header("Location: $url"."dashboard");
                    exit();
            }

            // check pending transactions
            if($this->admin_model->does_user_have_pending_ph($this->username)){
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                        <strong>ERROR: </strong> Unable to donate, you have pending transactions
                    </div>";
                    header("Location: $url"."dashboard");
                    exit();
            }

            // if($recycle == "1"){
            	$lst = $this->admin_model->get_user($this->username)->package;
	            if($amount < $lst){
	                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
	                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
	                        <strong>ERROR: </strong> Unable to donate, your recycle is lower than your last donation.
	                    </div>";
	                    header("Location: $url"."dashboard");
	                    exit();
	            }
            // }
            // increase ph counter
            $ph_counter = $this->admin_model->get_user($this->username)->ph_count + 1;
            $this->db->query("UPDATE users SET ph_count='$ph_counter', package='$amount' WHERE username='$this->username'");

            // insert PH
            $trans_num = strtoupper($this->admin_model->gen_token());
            $this->db->insert('ph', ['username'=>$this->username, 'amount'=>$amount, 'returns'=>$returns, 'trans_num'=>$trans_num, 'is_recycle'=>$recycle, 'date_created'=>$date, 'release_date'=>$release_date]);


            $_SESSION['notification'] = "<div class='alert alert-callout alert-info alert-dismissable' role='alert'>
                            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                            <strong>You have successfully made a recycle of (₦ $amount) wait patiently to be assigned a sponsor.</strong>.
                        </div>";
                header("Location: $url"."dashboard");
                exit();

            
        }

	    if(isset($_POST['reg_pop'])){
	    	$merge_id = $this->input->post('merge_id');
	    	$trans_num= $this->input->post('trans_num');
			if(empty($trans_num) || empty($merge_id)){
			    $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
				    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
				    <strong>ERROR: </strong> Fill thse empty fields
				  </div>";
				header("Location: $url"."dashboard");
			   	exit();
			}   
			$config['upload_path'] = 'public/assets/pop';
			$config['allowed_types'] = 'gif|jpg|png|jpeg';
			$config['max_size'] = 10000;
			$config['file_name'] = $merge_id;
			$config['overwrite'] = TRUE;
			$this->load->library('upload', $config);
			if (!$this->upload->do_upload('receipt')){
				$_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
					    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
					    <strong>ERROR: </strong> Upload failed
					  </div>";
				// echo $this->upload->display_errors();
			    header("Location: $url"."dashboard");
			    exit();
			}
			else{
		        $u = $this->upload->data();
		        $pop_name = $u['file_name'];
		        $date = date("Y-m-d H:i:s");
		        $this->db->query("UPDATE merge SET receipt='$pop_name', date_paid='$date' WHERE id='$merge_id'");
		        $_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
					    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
					    <strong>SUCCESS: </strong> Upload Successful
					  </div>";
		    	header("Location: $url"."dashboard");
		      	exit();
			} 
	    }
	    if(isset($_POST['reg_report'])){
	    	$merge_id = $this->input->post('merge_id');
	    	$reason = $this->input->post('reason');
			if(empty($reason)){
			    $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
				    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
				    <strong>ERROR: </strong> Fill thse empty fields
				  </div>";
				header("Location: $url"."dashboard");
			   	exit();
			}   
			if($this->db->insert('reports', ['username'=>$this->username, 'reason'=>$reason, 'merge_id'=>$merge_id])){
				$this->db->query("UPDATE merge SET is_report='1' WHERE id='$merge_id'");
				$_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
				    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
				    <strong>REPORT ACCEPTED: </strong> We will work on it.
				  </div>";
				header("Location: $url"."dashboard");
			   	exit();
			}
			else{
				$_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
				    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
				    <strong>ERROR: </strong> Request Failed.
				  </div>";
				header("Location: $url"."dashboard");
			   	exit();
			}
			
	    }
	    if(isset($_POST['reg_testimony'])){
	    	$text = $this->admin_model->fil_string($this->input->post('text'));
	    	 
			if(empty($text)){
			    $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
				    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
				    <strong>ERROR: </strong> Fill thse empty fields
				  </div>";
				header("Location: $url"."dashboard");
			   	exit();
			} 
			if($this->db->insert('testimony', ['text'=>$text, 'username'=>$this->username])){
				$_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
					    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
					    <strong>SUCCESS: </strong> Thank You for sharing this testimony
					  </div>";
		    	header("Location: $url"."dashboard");
		      	exit();
			}
			else{
				$_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
					    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
					    <strong>SUCCESS: </strong> Request Failed
					  </div>";
		    	header("Location: $url"."dashboard");
		      	exit();
			}   
	    }
		$h_data['page_title'] = "My Dashboard";
		$c_data = [];
        // $q = $this->db->query("SELECT * FROM users WHERE email='$this->email'");
        // foreach ($q->result() as $r) {
        // 	$c_data['fullname'] = strtoupper($r->fullname);	
        // }
		$this->load->view('users/header',$h_data);
		$this->load->view('users/dashboard',$c_data);
		$this->load->view('footer');
		unset($_SESSION['notification']);
	}
}
