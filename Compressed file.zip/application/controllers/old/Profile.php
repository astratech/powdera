<?php

defined('BASEPATH') OR exit('No direct script access allowed');



class Profile extends CI_Controller {



	public function __construct(){



        parent::__construct(); 

        $url = $this->config->base_url();

        if($this->admin_model->get_option("repair")->value == 1){

        	header("Location: $url"."maintenance");

        	exit();

        }



		if(!isset($_SESSION['vervefunds_logged'])){

       	 	header("Location: $url"."login");

            	exit();

		}

		else{

			$this->username = $_SESSION['vervefunds_logged']['username'];



			//is user verified

			if(!$this->admin_model->is_user_verified($this->username)){

				header("Location: $url"."verify");

            	exit();

			}

			if(!$this->admin_model->is_user_activated($this->username)){

                header("Location: $url"."activate");

                exit();

            }



			//is user blocked

			if($this->admin_model->is_user_blocked($this->username)){

				$_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>

                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

                                <strong>ACCOUNT BLOCKED: </strong> Hello $this->username, you account is blocked, contact the support team.

                            </div>";

           	 	header("Location: $url"."login");

            	exit();

			}

		}



   	}



	public function index(){

		$url = $this->config->base_url();	



		//Ajax

	    if($this->input->is_ajax_request()){



	    }



	    if(isset($_POST['edit_password'])){

	    	$password = $this->input->post('password');

	    	$rpassword = $this->input->post('rpassword');



	    	if(empty($password) || empty($rpassword)) {

		            $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>

								<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

								<strong>ERROR: </strong> Fill the empty fields

							</div>";



           	 		header("Location: $url"."profile");

               		exit();

            }

		    

	    	//check password

		    if($password != $rpassword){

		    	$_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>

								<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

								<strong>ERROR: </strong> Password Mismatch

							</div>";



       	 		header("Location: $url"."profile");

           		exit();

		    }



		    $password = $this->admin_model->encode_password($password);



		    if($this->db->query("UPDATE users SET password='$password' WHERE username='$this->username'")){

		    	$_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>

								<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

								<strong>SUCCESS: </strong> Password Changed

							</div>";



       	 		header("Location: $url"."profile");

           		exit();

		    }

		    else{

		    	$_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>

								<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

								<strong>ERROR: </strong> Request Failed

							</div>";



       	 		header("Location: $url"."profile");

           		exit();

		    }

	    }



	    if(isset($_POST['edit_bank'])){

	    	$bank_id = $this->input->post("bank_id");

        	$account_type = $this->input->post("account_type");

        	$account_name = $this->input->post("account_name");

        	$account_number = $this->input->post("account_number");



        	//check for empty fields

		    foreach ($_POST as $key => $val) {

		        if (empty($val)) {

		            $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>

								<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

								<strong>ERROR: </strong> Fill the empty fields

							</div>";



           	 		header("Location: $url"."profile");

               		exit();

		        }

		    }



		    if($this->db->query("UPDATE users SET bank_id='$bank_id', account_type='$account_type', account_name='$account_name', account_number='$account_number' WHERE username='$this->username'")){

		    	$_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>

								<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

								<strong>SUCCESS: </strong> Bank Details Updated.

							</div>";



           	 	header("Location: $url"."profile");

               	exit();

		    }

		    else{

		    	$_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>

								<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

								<strong>ERROR: </strong> Operation Failed.

							</div>";



           	 	header("Location: $url"."profile");

               	exit();

		    }

	    }



		$h_data['page_title'] = "My Profile";

		$c_data = [];

		$this->load->view('users/header',$h_data);

		$this->load->view('users/profile',$c_data);

		unset($_SESSION['notification']);

	}



}



