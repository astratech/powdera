<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Loga extends CI_Controller {
	public function __construct(){
        parent::__construct(); 
   	}
	public function index(){
        
		$url = $this->config->base_url();	
        // header("Location: $url"."home");
        // exit();
		if(isset($_POST['login'])){
			$username = $this->admin_model->fil_string($this->input->post("username"));
            $password = $this->admin_model->fil_string($this->input->post("password"));
            $r = $this->input->post("g-recaptcha-response");
            
            if(empty($r)){
                //set notification session
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> No Captcha.
                            </div>";
                header("Location: $url"."loga");
                exit();
            }

            $g_url = "https://www.google.com/recaptcha/api/siteverify?secret=6LekTCAUAAAAAJ0m2lS5Ik3xJX8_QlmUi-esXMR4&response=".$r;
            $send = file_get_contents($g_url);
            $send = json_decode($send);

            if($send->success != 1){
                //set notification session
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong>Invalid Captcha.
                            </div>";
                header("Location: $url"."loga");
                exit();
            }

            if(empty($username) || empty($password)){
                //set notification session
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Fill the empty fields
                            </div>";
                header("Location: $url"."loga");
                exit();
            }

            $password = $this->admin_model->encode_password($password);
            
            $q = "SELECT * FROM users WHERE username='$username' AND password='$password'";
            $r = $this->db->query($q);
            if($r->num_rows() > 0){
                $url = $this->config->base_url();
                foreach ($r->result() as $row) {
                    $_SESSION['vervefunds_logged']['username'] = $username;
                    $_SESSION['vervefunds_logged']['email'] = $row->email;
                }
                $d = date("Y-m-d H:i:s");
                $this->db->query("UPDATE users SET last_login='$d' WHERE username='$username'");
                
                header("Location: $url"."dashboard");
                exit();
            }
            else{
                
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Invalid Login
                            </div>";
                header("Location: $url"."loga");
                exit();
            }
		}
		$data['page_title'] = "Login";
        $this->load->view('header',$data);
        $this->load->view('loga',$data);
		$this->load->view('footer',$data);
		unset($_SESSION['notification']);
	}
}
