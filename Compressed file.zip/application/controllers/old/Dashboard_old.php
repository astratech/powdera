<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	public function __construct(){
        parent::__construct(); 
        $url = $this->config->base_url();
        
        if($this->admin_model->get_option("repair")->value == 1){
        	header("Location: $url"."maintenance");
        	exit();
        }
		if(!isset($_SESSION['vervefunds_logged'])){
       	 	header("Location: $url");
            exit();
		}
		else{
			$this->username = $_SESSION['vervefunds_logged']['username'];
			//is user verified
			if(!$this->admin_model->is_user_verified($this->username)){
				header("Location: $url"."verify");
            	exit();
			}
			//is user blocked
			if($this->admin_model->is_user_blocked($this->username)){
				$_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ACCOUNT BLOCKED: </strong> Hello $this->username, you account is blocked, contact the support team.
                            </div>";
           	 	header("Location: $url"."login");
            	exit();
			}
		}
   	}

	public function index(){
		$url = $this->config->base_url();

		//Ajax
	    if($this->input->is_ajax_request()){
			if(isset($_POST['action']) AND $_POST['action'] == "confirm_payment") {
	            $merge_id = $_POST['merge_id'];
	            $ph_id = $this->admin_model->get_merge($merge_id)->ph_id;
	            $gh_id = $this->admin_model->get_merge($merge_id)->gh_id;
	            $ph_amount = $this->admin_model->get_ph($ph_id)->amount;
	            $ph_username = $this->admin_model->get_ph($ph_id)->username;
	            $ph_trans_num = $this->admin_model->get_ph($ph_id)->trans_num;
	            $ph_recycle = $this->admin_model->get_ph($ph_id)->is_recycle;

	            // update ph
	            $this->db->query("UPDATE ph SET is_confirmed='1' WHERE id='$ph_id'");

	            // update gh
	            $this->db->query("UPDATE gh SET is_confirmed='1' WHERE id='$gh_id'");

	            // update merge
	            $this->db->query("UPDATE merge SET is_confirmed='1' WHERE id='$merge_id'");

	            // unlock all gh
	            $this->db->query("UPDATE gh SET locked='0' WHERE username='$ph_username'");

	           	if(!$this->admin_model->has_user_gh($ph_id)){
	           		$a = 0.1 * $ph_amount;
	           		$b = 0.5 * $ph_amount;
	           		$c = 0.5 * $ph_amount;

	           		// insert gh A
	           		$trans_num = $this->admin_model->gen_trans_num();
                    $this->db->insert('gh', ['username'=>$ph_username, 'amount'=>$ph_amount, 'ph_id'=>$ph_id, 'trans_num'=>$trans_num, 'type'=>'normal']); 

                    // insert gh B
	           		$trans_num = $this->admin_model->gen_trans_num();
                    $this->db->insert('gh', ['username'=>$ph_username, 'amount'=>$b, 'ph_id'=>$ph_id, 'trans_num'=>$trans_num, 'type'=>'normal']);  

                    // insert gh C
	           		$trans_num = $this->admin_model->gen_trans_num();
                    $this->db->insert('gh', ['username'=>$ph_username, 'amount'=>$c, 'ph_id'=>$ph_id, 'trans_num'=>$trans_num, 'type'=>'normal', 'locked'=>'1']);                                                     
	            	
                    // update ph is_gh
                    $this->db->query("UPDATE ph SET is_gh='1' WHERE id='$ph_id'");
                }

                // if($this->admin_model->gv_ref($ph_username)){
				// 	$ref_username = $this->admin_model->get_user($ph_username)->ref;
				// 	$btrans_num = $this->admin_model->gen_trans_num();

				// 	// insert bonus
				// 	$this->db->insert('bonus', ['username'=>$ref_username, 'amount'=>'500', 'trans_num'=>$btrans_num, 'type'=>'ref bonus']);
					

				// }	

				if($ph_recycle == '1'){
					$btrans_num = $this->admin_model->gen_trans_num();

					// insert bonus
					$this->db->insert('bonus', ['username'=>$ph_username, 'amount'=>'2000', 'trans_num'=>$btrans_num, 'type'=>'recycle bonus']);
					

				}

                echo "1";
				exit();
	        }
	        elseif(isset($_POST['action']) AND $_POST['action'] == "cancel_payment") {
	            $merge_id = $_POST['merge_id'];
	            $ph_id = $this->admin_model->get_merge($merge_id)->ph_id;
	            $gh_id = $this->admin_model->get_merge($merge_id)->gh_id;
	            $ban_username = $this->admin_model->get_ph($ph_id)->username;
	            //delete merge
	            $this->db->query("DELETE FROM merge WHERE id='$merge_id'");
	            //delete ph
	            $this->db->query("DELETE FROM ph WHERE id='$ph_id'");
	            //unmerge gh
	            $this->db->query("UPDATE gh SET is_merge='0' WHERE id='$gh_id'");
	            // block user
                // $this->db->query("UPDATE users SET is_blocked='1' WHERE username='$ban_username'");
                echo "1";
                exit();	                
	        }
	        elseif(isset($_POST['action']) AND $_POST['action'] == "purge") {
	            $merge_id = $_POST['merge_id'];
	            $ph_id = $this->admin_model->get_merge($merge_id)->ph_id;
	            $gh_id = $this->admin_model->get_merge($merge_id)->gh_id;
	            // $ban_username = $this->admin_model->get_ph($ph_id)->username;
	            //delete merge
	            $this->db->query("DELETE FROM merge WHERE id='$merge_id'");
	            //delete ph
	            $this->db->query("DELETE FROM ph WHERE id='$ph_id'");
	            //unmerge gh
	            $this->db->query("UPDATE gh SET is_merge='0' WHERE id='$gh_id'");
	            // block user
                // $this->db->query("UPDATE users SET is_blocked='1' WHERE username='$this->username'");
                echo "1";
                exit();	                
	        }
	        elseif(isset($_POST['action']) AND $_POST['action'] == "cashout_bonus") {
	            $amount = "10000";
	            $trans_num = $this->admin_model->gen_trans_num();

	            // insert gh
                $this->db->insert('gh', ['username'=>$this->username, 'amount'=>$amount, 'ph_id'=>"0", 'trans_num'=>$trans_num, 'type'=>'bonus']);

	            // update bonus
	            $this->db->query("UPDATE bonus SET is_paid='1' WHERE username='$this->username'");
	            
                echo "1";
				exit();
	        }
	        else{
	        	echo "0";
	        	exit();
	        }
	    }

	    if(isset($_POST['donate'])){
	    	$amount = $this->input->post("amount");
	    	$recycle = $this->input->post("recycle");
            $trans_num = $this->admin_model->gen_trans_num();
            $Date = date("Y-m-d H:i:s");
            $returns = $amount * 2;

            // checking pending transaction
            if(!$this->admin_model->does_user_have_pending_ph($this->username)){

            	// insert PH
	            if($this->db->insert('ph', ['username'=>$this->username, 'amount'=>$amount, 'returns'=>$returns, 'trans_num'=>$trans_num, 'release_date'=>$Date, 'is_recycle'=>$recycle])){
	            	// increase user ph count
	            	$ph_counter = $this->admin_model->get_user($this->username)->ph_count + 1;
                	$this->db->query("UPDATE users SET ph_count='$ph_counter' WHERE username='$this->username'");
                	
	            	if($this->admin_model->get_option("auto_merge")->value == 1){

	            			// get match for 5k
	            			$5k_recipent_gh_id = $this->admin_model->get_match_to_pay($amount);

	            			//if there is a merge
	            			if(!is_null($5k_recipent_gh_id)){
	            				//get  info
	            				$ph_id = $this->admin_model->get_ph_id_by_trans_num($trans_num);
	            				// merge them
	            				$this->db->insert('merge', ["ph_id"=>$ph_id, "gh_id"=>$recipent_gh_id, "amount"=>$amount, "days"=>"12"]);
	            				// update gh merged
		            			$this->db->query("UPDATE gh SET is_merge='1' WHERE id='$recipent_gh_id'");
		            			//update ph merged
		            			$this->db->query("UPDATE ph SET is_merge='1' WHERE id='$ph_id'");
	                            header("Location: $url"."dashboard");
		        				exit();
	            			}
	            			else{
	            				// get match for 10k
	            				$5k_recipent_gh_id = $this->admin_model->get_match_to_pay($amount);
	            				
	            			}
	            			else{
	            				$_SESSION['notification'] = "<div class='alert alert-callout alert-info alert-dismissable' role='alert'>
	                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
	                                <strong>DONATION SUCCESSFUL: </strong> Wait Patiently till you are merged.
	                            </div>";
	                            header("Location: $url"."transactions");
		        				exit();
	            			}
	        		}
	        		else{
	        			$_SESSION['notification'] = "<div class='alert alert-callout alert-info alert-dismissable' role='alert'>
	                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
	                                <strong>DONATION SUCCESSFUL: </strong> Wait Patiently till you are merged.
	                            </div>";
	                            header("Location: $url"."transactions");
		        				exit();
	        		}
	            }
	            else{
	            	$_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
	                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
	                                <strong>ERROR: </strong> Unable to donate
	                            </div>";
	                            header("Location: $url"."dashboard");
		        				exit();
	            }
            }
            else{
            	$_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
	                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
	                                <strong>ERROR: </strong> Unable to donate, you have pending transactions
	                            </div>";
	                            header("Location: $url"."dashboard");
		        				exit();
            }
            
	    }
	    if(isset($_POST['reg_pop'])){
	    	$merge_id = $this->input->post('merge_id');
	    	$trans_num= $this->input->post('trans_num');
			if(empty($trans_num) || empty($merge_id)){
			    $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
				    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
				    <strong>ERROR: </strong> Fill thse empty fields
				  </div>";
				header("Location: $url"."dashboard");
			   	exit();
			}   
			$config['upload_path'] = 'public/assets/pop';
			$config['allowed_types'] = 'gif|jpg|png|jpeg';
			$config['max_size'] = 10000;
			$config['file_name'] = $trans_num;
			$config['overwrite'] = TRUE;
			$this->load->library('upload', $config);
			if (!$this->upload->do_upload('receipt')){
				$_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
					    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
					    <strong>ERROR: </strong> Upload failed
					  </div>";
				// echo $this->upload->display_errors();
			    header("Location: $url"."dashboard");
			    exit();
			}
			else{
		        $u = $this->upload->data();
		        $pop_name = $u['file_name'];
		        $date = date("Y-m-d H:i:s");
		        $this->db->query("UPDATE merge SET receipt='$pop_name', date_paid='$date' WHERE id='$merge_id'");
		        $_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
					    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
					    <strong>SUCCESS: </strong> Upload Successful
					  </div>";
		    	header("Location: $url"."dashboard");
		      	exit();
			} 
	    }
	    if(isset($_POST['reg_report'])){
	    	$merge_id = $this->input->post('merge_id');
	    	$reason = $this->input->post('reason');
			if(empty($reason)){
			    $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
				    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
				    <strong>ERROR: </strong> Fill thse empty fields
				  </div>";
				header("Location: $url"."dashboard");
			   	exit();
			}   
			if($this->db->insert('reports', ['username'=>$this->username, 'reason'=>$reason, 'merge_id'=>$merge_id])){
				$this->db->query("UPDATE merge SET is_report='1' WHERE id='$merge_id'");
				$_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
				    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
				    <strong>REPORT ACCEPTED: </strong> We will work on it.
				  </div>";
				header("Location: $url"."dashboard");
			   	exit();
			}
			else{
				$_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
				    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
				    <strong>ERROR: </strong> Request Failed.
				  </div>";
				header("Location: $url"."dashboard");
			   	exit();
			}
			
	    }
	    if(isset($_POST['reg_testimony'])){
	    	$text = $this->input->post('text');
			if(empty($text)){
			    $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
				    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
				    <strong>ERROR: </strong> Fill thse empty fields
				  </div>";
				header("Location: $url"."dashboard");
			   	exit();
			} 
			if($this->db->insert('testimony', ['text'=>$text, 'username'=>$this->username])){
				$_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
					    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
					    <strong>SUCCESS: </strong> Thank You for sharing this testimony
					  </div>";
		    	header("Location: $url"."dashboard");
		      	exit();
			}
			else{
				$_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
					    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
					    <strong>SUCCESS: </strong> Request Failed
					  </div>";
		    	header("Location: $url"."dashboard");
		      	exit();
			}   
	    }
		$h_data['page_title'] = "My Dashboard";
		$c_data = [];
        // $q = $this->db->query("SELECT * FROM users WHERE email='$this->email'");
        // foreach ($q->result() as $r) {
        // 	$c_data['fullname'] = strtoupper($r->fullname);	
        // }
		$this->load->view('users/header',$h_data);
		$this->load->view('users/dashboard',$c_data);
		$this->load->view('footer');
		unset($_SESSION['notification']);
	}
}
