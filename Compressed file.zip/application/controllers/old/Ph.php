<?php



defined('BASEPATH') OR exit('No direct script access allowed');

class Ph extends CI_Controller {


	public function __construct(){

        parent::__construct(); 

        $url = $this->config->base_url();

        if($this->admin_model->get_option("repair")->value == 1){

        	header("Location: $url"."maintenance");

        	exit();

        }



		if(!isset($_SESSION['vervefunds_logged'])){



       	 	header("Location: $url");



            exit();



		}



		else{



			$this->username = $_SESSION['vervefunds_logged']['username'];


			//is user verified
			if(!$this->admin_model->is_user_verified($this->username)){



				header("Location: $url"."verify");



            	exit();



			}







			//is user blocked



			if($this->admin_model->is_user_blocked($this->username)){



				$_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>



                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>



                                <strong>ACCOUNT BLOCKED: </strong> Hello $this->username, you account is blocked, contact the support team.



                            </div>";



           	 	header("Location: $url"."login");



            	exit();



			}



		}



   	}







	public function index(){

	    



		$url = $this->config->base_url();	



		//Ajax

	    if($this->input->is_ajax_request()){

			if(isset($_POST['action']) AND $_POST['action'] == "cancel_payment") {

	            $ph_id = $_POST['ph_id'];



		        $date = date("Y-m-d H:m:i");

		        // delete PH

		        $this->db->query("DELETE FROM ph WHERE id='$ph_id'");



                echo "1";

				exit();

	        }

	        elseif(isset($_POST['action']) AND $_POST['action'] == "make_gh") {

	            $ph_id = $_POST['ph_id'];

	            $ph_trans_num = $this->admin_model->get_ph($ph_id)->trans_num;

	            $returns = $this->admin_model->get_ph($ph_id)->returns;

	            $ph_is_gh = $this->admin_model->get_ph($ph_id)->is_gh;

	            $ph_is_confirmed = $this->admin_model->get_ph($ph_id)->is_confirmed;



		        $date = date("Y-m-d H:m:i");

		        if($ph_is_gh == '0' AND  $ph_is_confirmed == '1'){

		        	$a = (70/100) * $returns;
		        	$b = $returns - $a;


		        	$trans_num = strtoupper($this->admin_model->gen_token());
		        	// insert GH
		        	$this->db->insert('gh', ['username'=>$this->username, 'amount'=>$a, 'trans_num'=>$trans_num, 'date_created'=>$date, 'ph_id'=>$ph_id]);

		        	$trans_num = strtoupper($this->admin_model->gen_token());
		        	// insert GH
		        	$this->db->insert('gh', ['username'=>$this->username, 'amount'=>$b, 'trans_num'=>$trans_num, 'date_created'=>$date, 'ph_id'=>$ph_id, 'locked'=>'1']);



		        	//update is gh

		        	$this->db->query("UPDATE ph SET is_gh='1' WHERE id='$ph_id'");

		        }

		        



                echo "1";

				exit();

	        }
	        else{

	        	echo "0";

	        	exit();

	        }

	    }

	    if(isset($_POST['cashout'])){
			if(!$this->admin_model->does_user_have_pending_ph($this->username)){
				$_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
					    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
					    <strong>Cash out Failed: </strong> You must have active PH before you can cash out.
					  </div>";
		    	header("Location: $url"."dashboard");
		      	exit();
			}

			$amount = $this->admin_model->get_user_bonus_balance($this->username);
            $trans_num = $this->admin_model->gen_token();
            $date = date("Y-m-d H:m:i");

            // insert gh
            $this->db->insert('gh', ['username'=>$this->username, 'amount'=>$amount, 'ph_id'=>"0", 'trans_num'=>$trans_num, 'type'=>'bonus', 'date_created'=>$date]);

            // update bonus
            $this->db->query("UPDATE bonus SET is_paid='1' WHERE username='$this->username'");

			$_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
					    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
					    <strong>SUCCESS: </strong> Bonus Cash Out.
					  </div>";
	    	header("Location: $url"."transactions");
	      	exit();
		}


		if(isset($_POST['recommit'])){

            $amount = $this->admin_model->fil_num($this->input->post("ph_amount"));

	    	$ph_id = $this->input->post("ph_id");

	    	$ph_trans_num = $this->admin_model->get_ph($ph_id)->trans_num;

            $old_ph_amount = $this->admin_model->get_ph($ph_id)->amount;
            $old_ph_returns = $this->admin_model->get_ph($ph_id)->returns;
            $old_ph_release_date = $this->admin_model->get_ph($ph_id)->release_date;

	    	// $recycle = $this->input->post("recycle");
	    	$recycle = "1";

	    	// echo $amount;
	    	// exit();
            
            $date = date("Y-m-d H:i:s");
            $release_date = date('Y-m-d H:i:s', strtotime($date. ' + 8 days'));
            $returns = $amount * 2;

            // check empty
            if(empty($amount)){
            	$_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                        <strong>ERROR: </strong> Fill the empty fields.
                    </div>";
                    header("Location: $url"."ph");
    				exit();
            }

            // check range
            if($amount > "100000" || $amount < "10000"){
            	$_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                        <strong>ERROR: </strong> Amount must be MIN of ₦10,000 and MAXIMUM of ₦50,000
                    </div>";
                    header("Location: $url"."ph");
    				exit();
            }

            // check pending transactions
            if($this->admin_model->does_user_have_pending_ph($this->username)){
            	$_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                        <strong>ERROR: </strong> Unable to donate, you have pending transactions
                    </div>";
                    header("Location: $url"."ph");
    				exit();
			}

            $lst = $this->admin_model->get_user_last_ph($this->username);

            if($amount < $lst){
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                        <strong>ERROR: </strong> Unable to donate, your recommitment is lower than your last donation.
                    </div>";
                    header("Location: $url"."ph");
                    exit();
            }
            
			// increase ph counter
			$ph_counter = $this->admin_model->get_user($this->username)->ph_count + 1;
            $this->db->query("UPDATE users SET ph_count='$ph_counter',package='$amount' WHERE username='$this->username'");

			// insert PH
			$new_trans_num = strtoupper($this->admin_model->gen_token());
			$this->db->insert('ph', ['username'=>$this->username, 'amount'=>$amount, 'returns'=>$returns, 'trans_num'=>$new_trans_num, 'is_recycle'=>'1', 'date_created'=>$date, 'release_date'=>$date]);


			$trans_num = strtoupper($this->admin_model->gen_token());
            $days = $this->admin_model->get_date_diff($old_ph_release_date, date('Y-m-d H:i:s'))->days;

            if($days < 0 OR $days > 8){
                $day = 8;
                $gp = $day * 12.5;
                $gmoney = (($gp/100) * $old_ph_amount) + $old_ph_amount;
            }
            elseif($days == 0){
                $day = $days + 1;
                $gp = $day * 12.5;
                $gmoney = (($gp/100) * $old_ph_amount) + $old_ph_amount;
            }
            else{
                $day = 8 - $days;
                $gp = $day * 12.5;
                $gmoney = (($gp/100) * $old_ph_amount) + $old_ph_amount;
            }

        	// insert GH
        	$this->db->insert('gh', ['username'=>$this->username, 'amount'=>$gmoney, 'trans_num'=>$trans_num, 'date_created'=>$date, 'ph_id'=>$ph_id, 'locked'=>'1']);

        	//update is gh
		    $this->db->query("UPDATE ph SET is_gh='1',date_gh='$date' WHERE id='$ph_id'");

		    $ph_20_percent = (50/100) * $amount;

			if($this->admin_model->get_option("auto_merge")->value == 1){

                // get recipent
                $recipent = $this->admin_model->get_real_recipent($ph_20_percent, $this->username);
                if(is_null($recipent)){
                	$_SESSION['notification'] = "<div class='alert alert-callout alert-info alert-dismissable' role='alert'>

                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

                        <strong>DONATION SUCCESSFUL: </strong>Wait Patiently till you are merged.

	                    </div>";

	                    header("Location: $url"."ph");

    					exit();
                }
                else{
                    // do merging
                    $gh_id = $recipent;
                    $ph_id = $this->admin_model->get_ph_id_by_trans_num($new_trans_num);

                    // merge them
                    $this->db->insert('merge', ["ph_id"=>$ph_id, "gh_id"=>$gh_id, "amount"=>$ph_20_percent, "days"=>"24", "date_created"=>$date]);

                    // update gh merged
                    $this->db->query("UPDATE gh SET is_merge='1' WHERE id='$gh_id'");

                    //update ph merged
                    $this->db->query("UPDATE ph SET is_merge='1',merged_20='1' WHERE id='$ph_id'");
                    $_SESSION['notification'] = "<div class='alert alert-callout alert-info alert-dismissable' role='alert'>

                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

                        <strong>SUCCESSFUL: </strong>50% of your Recommitment has been merged.

	                    </div>";

	                    header("Location: $url"."dashboard");

    					exit();
                }
            }
            else{
            	$_SESSION['notification'] = "<div class='alert alert-callout alert-info alert-dismissable' role='alert'>

                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

                        <strong>DONATION SUCCESSFUL: </strong>Wait Patiently till you are merged.
                        <p>Your GH will be released when your Recommitment is confirmed.</p>

	                    </div>";

	                    header("Location: $url"."gh");

    					exit();
            }

            
	    }


        if(isset($_POST['donate'])){

            $amount = $this->admin_model->fil_num($this->input->post("amount"));

            $recycle = $this->input->post("recycle");

            // echo $amount;
            // exit();
            
            $date = date("Y-m-d H:i:s");
            $release_date = date('Y-m-d H:i:s', strtotime($date. ' + 8 days'));
            $returns = $amount * 2;

            // check empty
            if(empty($amount)){
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                        <strong>ERROR: </strong> Fill the empty fields.
                    </div>";
                    header("Location: $url"."ph");
                    exit();
            }

            // check multiples
    

            // check range
            if($amount > "200000" || $amount < "10000"){
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                        <strong>ERROR: </strong> Amount must be MIN of ₦5,000 and MAXIMUM of ₦100,000
                    </div>";
                    header("Location: $url"."ph");
                    exit();
            }

            // check pending transactions
            if($this->admin_model->does_user_have_pending_ph($this->username)){
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                        <strong>ERROR: </strong> Unable to donate, you have pending transactions
                    </div>";
                    header("Location: $url"."ph");
                    exit();
            }

            // increase ph counter
            $ph_counter = $this->admin_model->get_user($this->username)->ph_count + 1;
            $this->db->query("UPDATE users SET ph_count='$ph_counter', package='$amount' WHERE username='$this->username'");

            // insert PH
            $trans_num = strtoupper($this->admin_model->gen_token());
            $this->db->insert('ph', ['username'=>$this->username, 'amount'=>$amount, 'returns'=>$returns, 'trans_num'=>$trans_num, 'is_recycle'=>$recycle, 'date_created'=>$date, 'release_date'=>$release_date]);

            $ph_20_percent = (20/100) * $amount;

            // if($this->admin_model->get_option("auto_merge")->value == 1){

            //     // get recipent
            //     $recipent = $this->admin_model->get_real_recipent($ph_20_percent, $username);
            //     if(is_null($recipent)){
            //         $_SESSION['notification'] = "<div class='alert alert-callout alert-info alert-dismissable' role='alert'>
            //             <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

            //             <strong>DONATION SUCCESSFUL: </strong>Wait Patiently till you are merged.

            //             </div>";

            //             header("Location: $url"."ph");

            //             exit();
            //     }
            //     else{
            //         // do merging
            //         $gh_id = $recipent;
            //         $ph_id = $this->admin_model->get_ph_id_by_trans_num($trans_num);

            //         // merge them
            //         $this->db->insert('merge', ["ph_id"=>$ph_id, "gh_id"=>$gh_id, "amount"=>$ph_20_percent, "days"=>"5", "date_created"=>$date]);

            //         // update gh merged
            //         $this->db->query("UPDATE gh SET is_merge='1' WHERE id='$gh_id'");

            //         //update ph merged
            //         $this->db->query("UPDATE ph SET is_merge='1' WHERE id='$ph_id'");
            //         $_SESSION['notification'] = "<div class='alert alert-callout alert-info alert-dismissable' role='alert'>

            //             <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

            //             <strong>SUCCESSFUL: </strong>20% of your Input Donation has been merged.

            //             </div>";

            //             header("Location: $url"."dashboard");

            //             exit();
            //     }
            // }
            // else{
            //     $_SESSION['notification'] = "<div class='alert alert-callout alert-info alert-dismissable' role='alert'>

            //             <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

            //             <strong>DONATION SUCCESSFUL: </strong>Wait Patiently till you are merged.

            //             </div>";

            //             header("Location: $url"."ph");

            //             exit();
            // }

            $_SESSION['notification'] = "<div class='alert alert-callout alert-info alert-dismissable' role='alert'>

                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

                        <strong>DONATION SUCCESSFUL: </strong>20% of your donation will be merged in 0 - 4 days.

                        </div>";

                        header("Location: $url"."ph");

                        exit();

            
            
        }








        $c_data['ph_list'] = $this->db->query("SELECT * FROM ph WHERE username='$this->username' ORDER BY id DESC");



        $c_data['gh_list'] = $this->db->query("SELECT * FROM gh WHERE username='$this->username' ORDER BY id DESC");



   



        $h_data['page_title'] = 'Donation History';



		$this->load->view('users/header',$h_data);



		$this->load->view('users/ph',$c_data);



		$this->load->view('footer');



		unset($_SESSION['notification']);



	}







}



