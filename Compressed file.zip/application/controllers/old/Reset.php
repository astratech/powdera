<?php

defined('BASEPATH') OR exit('No direct script access allowed');



class Reset extends CI_Controller {



	public function __construct(){

        parent::__construct();

        $url = $this->config->base_url();

   	}



   	public function user_logout(){

   		if(isset($_POST['user_logout'])){

	   		unset($_SESSION['vervefunds_logged']);

	   		$url = $this->config->base_url();

	   	 	header("Location: $url");

        exit();

	    }

   	}



    public function admin_logout(){

      if(isset($_POST['admin_logout'])){

        unset($_SESSION['vervefunds_admin_logged']);

        $url = $this->config->base_url();

        header("Location: $url"."admin/login");

        exit();

      }

    }

    public function back_logout(){

      if(isset($_POST['admin_logout'])){

        unset($_SESSION['vervefunds_admin_logged']);

        $url = $this->config->base_url();

        header("Location: $url"."back/login");

        exit();

      }

    }



   	public function all(){

   		session_destroy();

   		$url = $this->config->base_url();

   	 	header("Location: $url"."login");

        exit();

   	}

}

