<?php



defined('BASEPATH') OR exit('No direct script access allowed');







class Bonus extends CI_Controller {


	public function __construct(){

        parent::__construct(); 

        $url = $this->config->base_url();

        if($this->admin_model->get_option("repair")->value == 1){

        	header("Location: $url"."maintenance");

        	exit();

        }



		if(!isset($_SESSION['vervefunds_logged'])){



       	 	header("Location: $url");



            exit();



		}



		else{



			$this->username = $_SESSION['vervefunds_logged']['username'];







			//is user verified



			if(!$this->admin_model->is_user_verified($this->username)){



				header("Location: $url"."verify");



            	exit();



			}


			if(!$this->admin_model->is_user_activated($this->username)){

                header("Location: $url"."activate");

                exit();

            }







			//is user blocked



			if($this->admin_model->is_user_blocked($this->username)){



				$_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>



                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>



                                <strong>ACCOUNT BLOCKED: </strong> Hello $this->username, you account is blocked, contact the support team.



                            </div>";



           	 	header("Location: $url"."login");



            	exit();



			}



		}



   	}







	public function index(){

	    



		$url = $this->config->base_url();	



		//Ajax

	    if($this->input->is_ajax_request()){

			if(isset($_POST['action']) AND $_POST['action'] == "cancel_payment") {

	            $ph_id = $_POST['ph_id'];



		        $date = date("Y-m-d H:m:i");

		        // delete PH

		        $this->db->query("DELETE FROM ph WHERE id='$ph_id'");



                echo "1";

				exit();

	        }

	        elseif(isset($_POST['action']) AND $_POST['action'] == "make_gh") {

	            $ph_id = $_POST['ph_id'];

	            $ph_trans_num = $this->admin_model->get_ph($ph_id)->trans_num;

	            $returns = $this->admin_model->get_ph($ph_id)->returns;

	            $ph_is_gh = $this->admin_model->get_ph($ph_id)->is_gh;

	            $ph_is_confirmed = $this->admin_model->get_ph($ph_id)->is_confirmed;



		        $date = date("Y-m-d H:m:i");

		        if($ph_is_gh == '0' AND  $ph_is_confirmed == '1'){

		        	// insert GH

		        	$this->db->insert('gh', ['username'=>$this->username, 'amount'=>$returns, 'trans_num'=>$ph_trans_num, 'date_created'=>$date]);



		        	//update is gh

		        	$this->db->query("UPDATE ph SET is_gh='1' WHERE id='$ph_id'");

		        }

		        



                echo "1";

				exit();

	        }
	        else{

	        	echo "0";

	        	exit();

	        }

	    }

	    if(isset($_POST['cashout'])){
			if(!$this->admin_model->has_user_transact_before($this->username)){
				$_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
					    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
					    <strong>Cash out Failed: </strong> You must have made a transaction before you can cash out.
					  </div>";
		    	header("Location: $url"."bonus");
		      	exit();
			}

			$amount = $this->admin_model->get_user_bonus_balance($this->username);
            $trans_num = $this->admin_model->gen_token();
            $date = date("Y-m-d H:m:i");

            // insert gh
            $this->db->insert('gh', ['username'=>$this->username, 'amount'=>$amount, 'ph_id'=>"0", 'trans_num'=>$trans_num, 'type'=>'bonus', 'date_created'=>$date]);

            // update bonus
            $this->db->query("UPDATE bonus SET is_paid='1' WHERE username='$this->username'");

			$_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
					    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
					    <strong>SUCCESS: </strong> Bonus Cash Out.
					  </div>";
	    	header("Location: $url"."gh");
	      	exit();
		}








        $c_data['ph_list'] = $this->db->query("SELECT * FROM ph WHERE username='$this->username' ORDER BY id DESC");



        $c_data['gh_list'] = $this->db->query("SELECT * FROM gh WHERE username='$this->username' ORDER BY id DESC");



   



        $h_data['page_title'] = 'Bonus';



		$this->load->view('users/header',$h_data);



		$this->load->view('users/bonus',$c_data);



		$this->load->view('footer');



		unset($_SESSION['notification']);



	}







}



