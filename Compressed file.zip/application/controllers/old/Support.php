<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Support extends CI_Controller {

	public function __construct(){
        parent::__construct(); 
        $url = $this->config->base_url();
        
        if($this->admin_model->get_option("repair")->value == 1){
        	header("Location: $url"."maintenance");
        	exit();
        }
		if(!isset($_SESSION['vervefunds_logged'])){
       	 	header("Location: $url");
            exit();
		}
		else{
			$this->username = $_SESSION['vervefunds_logged']['username'];
			//is user verified
			if(!$this->admin_model->is_user_verified($this->username)){
				header("Location: $url"."verify");
            	exit();
			}
			//is user blocked
			if($this->admin_model->is_user_blocked($this->username)){
				$_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ACCOUNT BLOCKED: </strong> Hello $this->username, you account is blocked, contact the support team.
                            </div>";
           	 	header("Location: $url"."login");
            	exit();
			}
		}
   	}

	public function index(){

		
		//Ajax
	    if($this->input->is_ajax_request()){

	    }

		$h_data['page_title'] = "Support";
		$c_data = [];
 
		$this->load->view('users/header',$h_data);
		$this->load->view('users/support',$c_data);
		$this->load->view('footer');
		unset($_SESSION['notification']);
	}
}
