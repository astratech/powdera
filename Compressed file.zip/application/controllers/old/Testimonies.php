<?php



defined('BASEPATH') OR exit('No direct script access allowed');







class Testimonies extends CI_Controller {







	public function __construct(){



        parent::__construct(); 



        $url = $this->config->base_url();



        if($this->admin_model->get_option("repair")->value == 1){



        	header("Location: $url"."maintenance");



        	exit();



        }







        if(isset($_SESSION['vervefunds_logged'])){



       	 	$this->username = $_SESSION['vervefunds_logged']['username'];



		}



   	}







	public function index(){



	    



		$url = $this->config->base_url();







        $c_data['list'] = $this->db->query("SELECT * FROM testimony WHERE is_published='1' ORDER BY id DESC LIMIT 0,50");



   



        $h_data['page_title'] = 'Testimony';



        if(isset($_SESSION['vervefunds_logged'])){



			$this->load->view('users/header',$h_data);



		}



		else{



			$this->load->view('header',$h_data);



		}







		$this->load->view('users/testimony',$c_data);

		$this->load->view('footer');



		unset($_SESSION['notification']);



	}







}



