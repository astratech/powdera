<?php



defined('BASEPATH') OR exit('No direct script access allowed');







class Verify extends CI_Controller {



	public function __construct(){



        parent::__construct(); 

        if($this->admin_model->get_option("repair")->value == 1){

            header("Location: $url"."maintenance");

            exit();

        }



        if(!isset($_SESSION['vervefunds_logged'])){

            header("Location: $url"."login");

            exit();

        }

        else{

            $this->username = $_SESSION['vervefunds_logged']['username'];



            //is user verified

            if($this->admin_model->is_user_verified($this->username)){

                header("Location: $url"."dashboard");

                exit();

            }



            //is user blocked

            if($this->admin_model->is_user_blocked($this->username)){

                header("Location: $url"."login");

                exit();

            }

        }



   	}



	public function index(){



		$url = $this->config->base_url();



		if(isset($_POST['reset_code'])){

            $ver_code = rand(100000,999999);

            $this->db->query("UPDATE users SET verification_code='$ver_code' WHERE username='$this->username'");

            $m = "Your New verification code is ".$ver_code;



            $mobile = $this->admin_model->get_user($this->username)->mobile;

            $this->admin_model->send_sms($m, $mobile);



            $_SESSION['notification'] = "<div class='alert alert-callout alert-info alert-dismissable' role='alert'>

                            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

                            <strong></strong> New Verification Code has been sent to your Phone

                        </div>";



            header("Location: $url"."verify");

            exit();

        }



        if(isset($_POST['verify_user'])){

            $ver_code = $this->input->post("ver_code");



            if(empty($ver_code)){

                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>

                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

                                <strong>ERROR: </strong> Fill the empty fields

                            </div>";



                header("Location: $url"."verify");

                exit();

            }



            $r = $this->db->query("SELECT * FROM users WHERE username='$this->username' AND verification_code='$ver_code'");

            if($r->num_rows() > 0){
                // verify User
                $this->db->query("UPDATE users SET is_verified='1' WHERE username='$this->username'");


                $_SESSION['notification'] = "<div class='alert alert-callout alert-info alert-dismissable' role='alert'>

                            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

                            <strong></strong> Verification Successful, make a pledge.

                        </div>";

                header("Location: $url"."dashboard");

                exit();



            }

            else{

                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>

                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>

                                <strong>ERROR: </strong> Invalid Verification Code

                            </div>";



                header("Location: $url"."verify");

                exit();

            }

        }



		$data['page_title'] = "Verify";



        $this->load->view('users/header',$data);



        $this->load->view('verify',$data);


		unset($_SESSION['notification']);



	}



}



