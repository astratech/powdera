<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller {
	public function __construct(){
        parent::__construct();
        // if(isset($_SESSION['vervefunds_logged'])){
        //     header("Location: $url"."dashboard");
        //     exit();
        // } 
   	}
	public function index(){
        
		$url = $this->config->base_url();	
        // header("Location: $url"."home");
        // exit();
        
		if(isset($_POST['login'])){
			$username = $this->admin_model->fil_string($this->input->post("username"));
            $password = $this->admin_model->fil_string($this->input->post("password"));
            // $capt_text = $this->admin_model->fil_num($this->input->post("capt_text"));
            // $capt_ans = $this->admin_model->fil_num($this->input->post("capt_ans"));
            
            // if($capt_ans != $capt_text){
            //     //set notification session
            //     $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
            //                     <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
            //                     <strong>ERROR: </strong>Invalid Captcha.
            //                 </div>";
            //     header("Location: $url"."login");
            //     exit();
            // }

            if(empty($username) || empty($password)){
                //set notification session
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Fill the empty fields
                            </div>";
                header("Location: $url"."login");
                exit();
            }

            $password = $this->admin_model->encode_password($password);
            
            $q = "SELECT * FROM users WHERE username='$username' AND password='$password'";
            $r = $this->db->query($q);
            if($r->num_rows() > 0){
                $url = $this->config->base_url();
                foreach ($r->result() as $row) {
                    $_SESSION['vervefunds_logged']['username'] = $username;
                    $_SESSION['vervefunds_logged']['email'] = $row->email;
                }
                $d = date("Y-m-d H:i:s");
                $this->db->query("UPDATE users SET last_login='$d' WHERE username='$username'");
                
                header("Location: $url"."dashboard");
                exit();
            }
            else{
                
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Invalid Login
                            </div>";
                header("Location: $url"."login");
                exit();
            }
		}
		$data['page_title'] = "Login";
        $this->load->view('header',$data);
        $this->load->view('login',$data);
		$this->load->view('footer',$data);
		unset($_SESSION['notification']);
	}
}
