<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class F extends CI_Controller {
	public function __construct(){
        parent::__construct();
        if(isset($_SESSION['vervefunds_logged'])){
            header("Location: $url"."dashboard");
            exit();
        } 
   	}
	public function index(){
        
		$url = $this->config->base_url();	
        // header("Location: $url"."home");
        // exit();
    
    if(isset($_POST['recover'])){
      $email = $this->admin_model->fil_email($this->input->post("email"));
      
      if(empty($email)){
          //set notification session
          $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                          <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                          <strong>ERROR: </strong> Fill the empty fields
                      </div>";
          header("Location: $url"."f");
          exit();
      }
      
      if(!$this->admin_model->email_exist($email)){
         $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                          <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                          <strong>ERROR: </strong>Invalid Email Address.
                      </div>";
          header("Location: $url"."f");
          exit();
      }
      
      $name = $this->admin_model->get_user_by_email($email)->fullname;
      $username = $this->admin_model->get_user_by_email($email)->username;
      $password = $this->admin_model->decode_password($this->admin_model->get_user_by_email($email)->password);
      
      // send token to email
      $t = $this->admin_model->gen_token();
      $txt = "<h1>SourceNaira Support</h1><br/><br/>";
      $txt .= "<p>Hello $name, Below are your login details<p>";
      $txt .= "<h3>Username: $username<h3>";
      $txt .= "<h3>Password: $password<h3>";
      
      $this->load->library('email', ['mailtype' => 'html'], 're');
      $this->re->from('support@sourcenaira.com', 'SourceNaira Support');
      $this->re->to($email);
      $this->re->subject('Password Recovery');
      $this->re->message($txt);
      $this->re->send();
      
     $header = "From:support@sourcenaira.com \r\n";
     $header .= "MIME-Version: 1.0\r\n";
     $header .= "Content-type: text/html\r\n";

     $retval = mail ("sangosanyasegun@yahoo.com","Password Recovery",$txt,$header);
      
      if( $retval == true ) {
            echo "Message sent successfully...";
         }else {
            echo "Message could not be sent...";
         }
//       echo $url."f/recover?token=$t";
      exit();
      
    }
		
		$data['page_title'] = "Forgot Password";
        // $this->load->view('header',$data);
        $this->load->view('forgot',$data);
		// $this->load->view('footer',$data);
		unset($_SESSION['notification']);
	}
}
