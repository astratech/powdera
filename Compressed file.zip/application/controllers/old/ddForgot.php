<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Forgot extends CI_Controller {
	public function __construct(){
        parent::__construct();
        // if(isset($_SESSION['vervefunds_logged'])){
        //     header("Location: $url"."dashboard");
        //     exit();
        // } 
   	}
	public function index(){
        
		$url = $this->config->base_url();	
        // header("Location: $url"."home");
        // exit();
        
		if(isset($_POST['forgot'])){
			$email = $this->admin_model->fil_email($this->input->post("email"));

            if(empty($email)){
                //set notification session
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Fill the empty fields
                            </div>";
                header("Location: $url"."forgot");
                exit();
            }
            
            $q = "SELECT * FROM users WHERE email='$email'";
            $r = $this->db->query($q);
            if($r->num_rows() > 0){
                $url = $this->config->base_url();
                foreach ($r->result() as $row) {
                   $password = $this->admin_model->decode_password($row->password);
                   $username = $row->username;
                }
               
                $msg = "<h3>Flex10ng</h3>";
                $msg .= "<h3>Hello $username, your password is $password</h3>";

                $to = $email;
                $subject = "Account Password";


                // Always set content-type when sending HTML email
                $headers = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

                // More headers
                $headers .= 'From: <support@Flex10ng.com>' . "\r\n";

                mail($email,$subject,$msg,$headers);

                $_SESSION['notification'] = "<div class='alert alert-callout alert-success alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>SUCCESS: </strong> Your Password has been sent to your email. <br> $email
                            </div>";
                header("Location: $url"."forgot");
                exit();
            }
            else{
                
                $_SESSION['notification'] = "<div class='alert alert-callout alert-danger alert-dismissable' role='alert'>
                                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>x</button>
                                <strong>ERROR: </strong> Email does not exist.
                            </div>";
                header("Location: $url"."forgot");
                exit();
            }
		}
		$data['page_title'] = "Forgot";
        // $this->load->view('header',$data);
        $this->load->view('forgot',$data);
		// $this->load->view('footer',$data);
		unset($_SESSION['notification']);
	}
}
